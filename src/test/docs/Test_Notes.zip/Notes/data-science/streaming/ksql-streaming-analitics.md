# KSQL for streaming analytics

