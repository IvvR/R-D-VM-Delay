# TensorFlow + MQTT + Apache Kafka

a use case with connected cars and real-time streaming analytics using deep learning
and Apache Kafka as a scalable central nervous system.

[Detection of MQTT IoT Sensor Data](https://github.com/kaiwaehner/ksql-udf-deep-learning-mqtt-iot)