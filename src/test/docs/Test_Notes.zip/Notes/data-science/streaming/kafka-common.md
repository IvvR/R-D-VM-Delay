# Kafka

- distributed publish-subscribe messaging system
- particularly useful for working with real-time data of enormous message stream

## The Benefits of Using Kafka vs. AMQP or JMS

- Scalable
- Durable
- Reliable
- Offers High Performance

### Reliable

Kafka replicates data and is able to support multiple subscribers. it automatically balances consumers in the event of failure.


## JMS vs Kafka

[JMS vs Kafka in specific conditions]
(https://stackoverflow.com/questions/42664894/jms-vs-kafka-in-specific-conditions)

 Kafka guarantees ordered delivery only within a single partition. Period. 

In JMS, you have a queue and you have a topic. With queues, when first consumer consumes a message, others cannot take it anymore. With topics, multiple consumers receive each message but it is much harder to scale.

Consumer group from Kafka is a generalization of these two concepts - it allows scaling between members of the same consumer group, but it also allows broadcasting the same message between many different consumer groups.

### JMS specifics

[Apache Kafka differences from JMS]
(http://blog.hampisoftware.com/index.php/2016/01/20/apache-kafka-differences-from-jms/)

1. Order of Messages.
Kafka ensures that the messages are received in the order in which they were sent at the partition level. JMS does not have any such contracts.

2. Filters
Kafka does not have any concept of filters at the brokers that can ensure – messages that are being picked up by a consumer matches some criteria. The filtering has to happen at the consumers (or applications).

In the case of JMS – if your messaging application needs to filter the messages it receives, you can use a JMS API message selector, which allows a message consumer to specify the messages it is interested in. Message selectors assign the work of filtering messages to the JMS provider rather than to the application.

3. Persistence of Messages
Kafka brokers store the messages for a specified period of time irrespective of whether the message has been picked up by the consumers or not.
JMS providers typically provide either in memory or disk based storage of messages.

4. Push vs Pull of Messages
In JMS, the provider can push the JMS message to topics and queues.
In Kafka, consumers pull the message from the broker.