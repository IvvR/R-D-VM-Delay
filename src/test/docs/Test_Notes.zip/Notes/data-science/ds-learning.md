
# Courses for Data Science

## BC IT 


[MATH 1060 - Statistics for Data Analysis]()

This hands-on course introduces descriptive statistics, basic inferential statistics, linear regression, and probability concepts and calculations. Emphasis throughout the course will be placed on using statistical methods for the exploration and analysis of data sets. This introduction will enable students to use statistics for data analysis, will prepare them for “Data Analytics/Mining,” and covers topics appropriate for anyone seeking a first statistics course. Labs and exercises employ standard graphical methods to represent statistical data. Hypothesis tests, including ANOVA, are used to test for significant differences between multiple groups. Students will be introduced to the open source R Programming language, a statistical analysis tool used to extract meaningful information from a variety of scientific, industrial and commercial data sets. Upon successful completion, students will be able to carry out calculations, perform statistical decision making and solve problems with involving collected data. This course prepares the student to move on to MATH 3060 and is a required course for the Applied Data Analytics Certificate offered by BCIT Computing.

$631.18

