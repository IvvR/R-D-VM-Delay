
# Data science

the skills to solve problems are a mix of computer programming, mathematics, and business savvy.

Data science means doing analytics work that requires a substantial amount of software engineering skills.

a statistician or business analyst might not provide.

It’s very hard to find people who can construct good statistical models, hack
quality software, and relate this all in a meaningful way to business problems.

It’s just a question of acquiring the particular balance of skills required.

## 1.1­  Aren’t Data Scientists Just Overpaid Statisticians?

Data scientists spend most of their time getting data into a form where statistical methods could even be applied.

As a note of advice, it is much better to be proficient in one language, to the
point where you can reliably churn out code that is of high quality, than to be
mediocre at several.

> leg-up, a small up leg, give a leg up  - a little help

## The Stuff You’ll Always Use


