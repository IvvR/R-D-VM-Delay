# Schema-on-Read

[Schema-on-Read]
(https://www.marklogic.com/blog/schema-on-read-vs-schema-on-write/)

For decades now the database world has been oriented towards the schema-on-write approach. First you define your schema, then you write your data, then you read your data and it comes back in the schema you defined up-front. 

Schema on read follows a different sequence – just load the data as-is and apply your own lens to the data when you read it back out.

- With schema-on-read, you’re not tied to a predetermined structure so you can present the data back in a schema that is most relevant to the task at hand.
- One of the places where projects often go off the rails is when multiple datasets are being consolidated. With schema-on-write, you have to do an extensive data modeling job and develop and über-schema that covers all of the datasets that you care about. Then you have to think about whether your schema will handle the new datasets that you’ll inevitably want to add later. 
- Using a schema-on-read approach means you can load your data as-is and start to get value from it right away. This is important when dealing with structured data, but even more important when dealing with semi-structured, poly-structured, and unstructured data which is the vast majority by volume.

[Build a Schema-On-Read Analytics Pipeline Using Amazon Athena](https://aws.amazon.com/blogs/big-data/build-a-schema-on-read-analytics-pipeline-using-amazon-athena/)

Schema-on-read is a unique approach for storing and querying datasets. It reverses the order of things when compared to schema-on-write in that the data can be stored as is and you apply a schema at the time that you read it. This approach has changed the time to value for analytical projects

analytical platforms criteria:

- Help ingest data easily from multiple sources
- Analyze it for completeness and accuracy
- Use it for metrics computations
- Store the data assets and scale as they grow rapidly without causing disruptions
- Adapt to changes as they happen
- Have a relatively short development cycle that is repeatable and easy to implement.

## The data integration challenge

This is usually done as a series of Extract Transform Load (ETL) jobs that pull data from multiple varied sources and integrate them into a central repository. The multiple steps of ETL can be viewed as a pipeline where raw data is fed in one end and integrated data accumulates at the other. 

[Data governance and the death of schema on read](https://www.oreilly.com/ideas/data-governance-and-the-death-of-schema-on-read)

The same data, and aggregations of the same data, are often present redundantly—often many times redundant, as the same interesting data set is saved to the data lake by multiple teams, unknown to each other. Further, data scientists seeking to integrate data from multiple silos are unable to identify where the data resides in the lake. 
Data scientists spend 70% of their time finding, interpreting, and cleaning data, and only 30% actually analyzing it. 
Data may be inscrutable, vacuous, or even misleading.

proactive data governance is saving the democratized data lake from itself.

## What is Schema On Read

The exploding growth of unstructured data and overhead of ETL for storing data in RDBMS is the main reason for shift to schema on read.

[ Thomas Henson: Schema On Read vs. Schema On Write Explained](https://www.thomashenson.com/schema-read-vs-schema-write-explained/)

we are still doing ETL on the data to fit into a schema but only when reading the data. Think of this as schema on demand!

[Schema-on-read in action]
(https://blog.cdap.io/2015/03/schema-on-read-in-action/)

Hadoop etc.
```bash
hdfs dfs -put /local/path/userdump /hdfs/path/data/users

create external table users (id int, first_name string, last_name string, age int) row format delimited fields terminated by ',' location '/hdfs/path/data/users';
```

[DB partitioning](https://stackoverflow.com/questions/20771435/database-sharding-vs-partitioning)
