
# Crossword task

I'm wondering the best approach to designing a database for storing crossword json data. As the website is at the moment, the frontend view just needs to be passed the whole object to render the crossword:  

```javascript
{
    grid: [15][15], // 2D array of letters
    clues: {
        across: { 
            clue_id: "here's an across clue" 
            ... 
        }, // Arbitrary number of clues
        down: {
            clue_id: "here's a down clue" 
            ... 
        } // Arbitrary number of clues
    }
}
```

[How to design a database](https://softwareengineering.stackexchange.com/questions/360759/how-to-design-a-database-that-stores-large-json-objects)  

