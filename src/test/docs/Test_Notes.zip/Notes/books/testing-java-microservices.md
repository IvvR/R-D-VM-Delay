# Testing Java Microservices
 
Chapter 1. An introduction to microservices 5
Chapter 2. Application under test 21
Chapter 3. Unit-­testing microservices 55
Chapter 4. Component­-testing microservices 84
Chapter 5. Integration­-testing microservices 132
Chapter 6. Contract tests 169
Chapter 7. End-­to-­end testing 210
Chapter 8. Docker and testing 241
Chapter 9. Service virtualization 
Chapter 10. Continuous delivery in microservices
Appendix. Masking multiple containers with Arquillian Chameleon