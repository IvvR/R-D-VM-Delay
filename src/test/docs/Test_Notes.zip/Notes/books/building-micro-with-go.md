# Building Microservices with GO

## simple web server

The place that APIs send requests and where the resource lives, is called an endpoint. An Endpoint is specified as a relative or absolute url that usually results in a response. That response is usually the result of a server-side process that, could, for instance, produce a JSON string.

### installing go-lang

https://tecadmin.net/install-go-on-ubuntu/  
https://medium.com/@patdhlk/how-to-install-go-1-9-1-on-ubuntu-16-04-ee64c073cd79

- sudo apt-get update & upgrade
- wget https://dl.google.com/go/go1.11.1.linux-amd64.tar.gz
- sudo tar -xvf go1.11.1.linux-amd64.tar.gz
- sudo mv go /usr/local

### Setup Go Environment

[!NOTE]
> BS really. the other source suggestion seems much better

- export GOROOT=/usr/local/go
- export GOPATH=$HOME/Projects/Proj1
- export PATH=$GOPATH/bin:$GOROOT/bin:$PATH

> I'm gonna try this way

- sudo nano ~/.profile
- export PATH=$PATH:/usr/local/go/bin   // add to the end of the file

The following commands can be added to ~/.profile

- export GOPATH=$HOME/GitProjects/golang
- export PATH=$GOPATH/bin:$GOROOT/bin:$PATH

### verification

- go version
- go env
