
# Content

HAPTER 1	 Hello, Android  1
CHAPTER 2	 Getting Started  13
CHAPTER 3	 Applications and Activities and Fragments, Oh My!   57
CHAPTER 4	 Defining the Android Manifest and Gradle Build Files, and Externalizing Resources    95
CHAPTER 5	 Building User Interfaces  129
CHAPTER 6	 Intents and Broadcast Receivers  177
CHAPTER 7	 Using Internet Resources  211
CHAPTER 8	 Files, Saving State, and User Preferences  245
CHAPTER 9	 Creating and Using Databases   281
CHAPTER 10	 Content Providers and Search 317
CHAPTER 11	 Working in the Background 377 // 403
CHAPTER 12	 Implementing the Android Design Philosophy  433
CHAPTER 13	 Implementing a Modern Android User Experience 463
CHAPTER 14	 Advanced Customization of Your User Interface  501
CHAPTER 15	 Location, Contextual Awareness, and Mapping  541
CHAPTER 16	 Hardware Sensors  619
CHAPTER 17	 Audio, Video, and Using the Camera  665
CHAPTER 18	 Communicating with Bluetooth, NFC, and Wi-Fi Peer-to-Peer  713
CHAPTER 19	 Invading the Home Screen   743
CHAPTER 20	 Advanced Android Development 787
CHAPTER 21	 Releasing, Distributing, and Monitoring Applications 825