# Git Eclipse

Git is a distributed repository. Unlike other source management systems, Git
maintains a complete local repository too. So you can perform activities such as
check-out and check-in in the local repository without connecting to any remote
repository. When you are ready to move your code to a remote repository, then
you can connect to it and push your files to the remote repository.

