# SSH generation

1. Check if some keys exists
   ls -al ~/.ssh
2. ssh-keygen -t rsa -b 4096 -C 'rakin.i.v@gmail.com'
3. run ssh agent : eval "\$(ssh-agent -s)"
4. ssh-add ~/.ssh/id_rsa
5. xclip -sel clip < ~/.ssh/id_rsa.pub
6. ssh -T git@github.com

create remote repo online and push existed code there
push an existing repository from the command line

1. git remote add origin https://github.com/IvvR/express-server.git
2. git push -u origin master

## Switching remote URLs from SSH to HTTPS

git remote -v
origin https://github.com/IvvR/express-server.git (fetch)
origin https://github.com/IvvR/express-server.git (push)

Change your remote's URL from HTTPS to SSH with the git remote set-url command.
git remote set-url origin git@github.com:USERNAME/REPOSITORY.git

git remote set-url origin git@github.com:IvvR/express-server.git
git remote -v
