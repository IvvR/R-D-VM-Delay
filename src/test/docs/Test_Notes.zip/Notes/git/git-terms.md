# Git Terminology

[Git vs SVN commands](https://backlog.com/git-tutorial/reference/commands/)

git clone 

git clone https://github.com/cucumber/cucumber-java-skeleton.git

svn checkout
