# My Git notes

- create a new repo
- connect a repo with VS Code
- connect a repo with Idea
- connect a repo with Eclipse

## create a new repo

with VS Code:
The button on the left. When pushed look at button top right.
next repos can be created withe the '+' button on the right-top

with a terminal:
git init

## check out /pull

check-in / pool out ?
VS Code with Git integration
[VS Code with Git integration](https://www.youtube.com/embed/AKNYgP0yEOY?rel=0&disablekb=0&modestbranding=1&showinfo=0)

[Adding an existing project to GitHub using the command line](https://help.github.com/articles/adding-an-existing-project-to-github-using-the-command-line/)

I assume you started to work in a directory and didn't use git there. The following should work with git bash:

cd "path to your repo"
git init
git add . # if you want to commit everything. Otherwise use .gitconfig files
git commit -m "initial commit" # If you change anything, you can add and commit again...

To add a remote, just do

git remote add origin https://...
git remote show origin # if everything is ok, you will see your remote
git push -u origin master # assuming your are on the master branch.

The -u sets an upstream reference and git knows from where to fetch/pull and where to push in the future.
from the terminal:
git remote add origin https://github.com/IvvR/neib-jam.git
git remote -v
ivan@ivr:~/GitProjects/neib-jam\$ git push origin master
Username for 'https://github.com': IvvR
Password for 'https://IvvR@github.com':

git status
git push -u origin master // it doesn't seem to wark as I think

[VS Code - Connect to remote GIT repository and PUSH local files to new remote repository](https://stackoverflow.com/questions/43364233/vs-code-connect-to-remote-git-repository-and-push-local-files-to-new-remote-re)

To commit into a remote repo from VS Code use "Push to" from the menu

[VS Code Git credential](https://stackoverflow.com/questions/34400272/visual-studio-code-always-asking-for-git-credentials)

### bitbucket

private repo
git clone https://ivan_rn@bitbucket.org/ivan_rn/hush-ghost.git

- Set up remote repository
  - Create project on GitHub
  - Import to Bitbucket
  - Clone the link
- Link the remote with local folder
  - Create local folder. !!! Not a clean way, It will create a repo with the same name inside this folder.
  - Initialize local repo using git "git init". // Well it was initialized earlier. Git said "Reinitialized existing Git repository in..."
  - Run "git remote add origin https://ivan_rn@bitbucket.org/ivan_rn/hush-ghost.git"
  - Copying all remote files to local repository. Run "git clone https://ivan_rn@bitbucket.org/ivan_rn/hush-ghost.git"
- Set global params
  - git config –global user.email “username@email.com”
  - git config –global user.name “bitbucket-username”
  - git config –global push.default simple
- Store login credential
  - git config credential.helper store
  - git push https://bitbucket.org/alexjoh/blogmarkdown.git

Well, it was not good.
Repo on GitHub was created with readme.md and local/remote repos were not happy
"Updates were rejected because the remote contains work that you do
hint: not have locally."

used "git push -f origin master". it worked, but VS Code doesn't see any changes.
"ivan@ivr:~/GitProjects/hush-ghost\$ git status
On branch master
nothing to commit, working tree clean"
and it looks OK on remote repo.

[!NOTE]

> clone in git managed folder  
> git clone https://github.com/YOUR-USERNAME/YOUR-REPOSITORY

OK, missed creating REDMI, LICENCE and .gitignore
so

- cloned an empty repo
- echo "# VM-Delay" >> README.md // file created
- git init // skipped
- git add README.md // added
- git commit -m "first commit" // commited
- git remote add origin https://github.com/IvvR/VM-Delay.git // skipped
- git remote -v // # Verify new remote
- git push -u origin master // skipped

doesn't work as expected. trying:

- git push -u origin master. // worked

## Commit

with bypassing editor

- git commit -m "Removed the the property type project"
- git push

## Git Credentional

[Strore Cred](https://stackoverflow.com/questions/35942754/how-to-save-username-and-password-in-git)

- git config credential.helper store
- git pull

# Get data from a remote repo: fetch vs pull

- fetch: retrieve
- pull: retrieve and merge

Strangely, fetch didn't get a new file from GitHub.
'pull' doe it.
git pull https://github.com/IvvR/R-D-VM-Delay.git

## how to delete

lol. it's complicated

to delete a local repo:
rm -rf drink-me-now

### Repository

Find somehow Repo Properties and in the very buttom there is a magic link

### a project

On GitHub, navigate to the main page of the repository.

## New Repo

https://github.com/IvvR/R-D-VM-Delay.git

- git add --all
- git add .
- git commit -m "Milestone features released"
- or git commit -am "<commit message>" // -am ?
- git push

## Clone project

Locally

Cloning the repository and depending on the modules locally is required when using some ExoPlayer extension modules. It's also a suitable approach if you want to make local changes to ExoPlayer, or if you want to use a development branch.

First, clone the repository into a local directory and checkout the desired branch:

```git
git clone https://github.com/google/ExoPlayer.git
git checkout release-v2
```

### pull and clone in git?

They're basically the same, except clone will setup additional remote tracking branches, not just master. check branches with: git branch -r

```git
git init
git remote add origin git://github.com/cmcculloh/repo.git
git fetch --all
git pull origin master
```

vs:

```git
git clone git://github.com/cmcculloh/repo.git
```

git checkout dev-v2-r2.9.1

git clone https://github.com/IvvR/drink-me-now.git

## Working with a progect

create a repo : git init  
check the status: git status
add files / folders to the repo:

git add package.json
git add server.js
git add public/

create .gitignore
touch .gitignore

git commit -m 'Initial commit'

## Rollback

[How to reset, revert, and return to previous states in Git](https://opensource.com/article/18/6/git-reset-revert-rebase-commands)

git log --oneline

b94495c (HEAD -> master, origin/master, heroku/master) fs logging commented for Heroku
ed34fe9 Setup start script and heroku port
49a0a20 Updateed name
2a83947 Initial commit

git reset ed34fe9
