
# Deployment

[!NOTE]  
> It was a pretty messy process
> Access through the console

Console. link:  

```html
 https://play.google.com/apps/publish/?account=7786035718888003231#https://play.google.com/apps/publish/?account=7786035718888003231#
```

TODO: write the notes for:

1. New app deployment
2. app update process


