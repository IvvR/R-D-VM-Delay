
# HAR sound project

Jamming. 
microphone data to regulate sound level

Extension: animals/pets emotion recognition


[Deep learning for sensor-based human activity recognition](https://becominghuman.ai/deep-learning-for-sensor-based-human-activity-recognition-970ff47c6b6b)

most of the  approaches used for HAR  rely on heuristic hand-crafted feature extraction methods, which hinders their generalization performance

> it hinders their generalization performance.  
> create difficulties for (someone or something), resulting in delay or obstruction.
> syn: hamper, obstruct, impede, inhibit, retard, balk, prevent, thwart, foil, curb, 

Decision tree, Support Vector Machine, Naive Bayes, Hidden Markov Models and K-Nearest Neighbors are the most used algorithms to tackle HAR problem. Models implementing these algorithms:

- Require hand-crafted feature generation
- Do not generalize
- Use Online APIs
- Are not optimized for low resource consumption

> algorithms mentioned above are irreproachable  
> irreproachable - beyond criticism; faultless

## Deep Learning approach

## Training the model


“Freeze” the model meta-graph and export it as a file (“.pb” format). 

## On-device prediction

TensorFlow on Android.  
from tensorflow.python.tools import freeze_graph

[android: Detect sound level](https://stackoverflow.com/questions/14181449/android-detect-sound-level)

[mic level to dB](https://stackoverflow.com/questions/10655703/what-does-androids-getmaxamplitude-function-for-the-mediarecorder-actually-gi)

