
# Whose 'splain

No No No !!!  
The right name is mansplain analyzer  

roles

- patriarch
- sjw

a combining form extracted from mansplain and meaning “to explain or comment on something in a condescending, overconfident, and often inaccurate or oversimplified manner, from the perspective of the group one identifies with,” as in ladysplain; whitesplain

Program analyses conversation from the point ov view of duration of each participant and marker words:

- mansplain
- sjw
- black brothers
- white supremacists
- prophets of the religion of love and peace

