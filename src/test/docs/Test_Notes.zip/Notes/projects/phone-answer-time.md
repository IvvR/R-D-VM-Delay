
# change answer time for a set of providers

Use service provider api to set up ringing time


## Koodo

How do I change the number of rings before going to voicemail

Dial *#61# Write down the number it pops up with.  
This is your voicemail access number then dial **61*1 number *11*xx# where xx is the time in seconds (not rings) you want to wait before going to voicemail. Minimum is 5 seconds and maximum is 30 seconds. Make sure 1 is infront of your access number. 

to check: *#61#

**61*1 voice_number *11*xx_secs# 


Changing the ring time before a call diverts to another phone number

# Ring Timer

[call divert](https://www.optus.com.au/shop/support/answer/how-to-change-the-ring-time-before-a-call-diverts-mobile-phone?requestType=NormalRequest&id=1424&typeId=5)

call divert

voice mail divert
**61*Number**XX# (then press 'Send' or 'Call')

life is not easy for kids
https://github.com/dialogs/android-dialer.git

.getExtras().getBoolean(EXTRA_ENABLE_POUND, true)

MY PHONE TRACKING NUM  
 LZ924875476CN

[Telus](https://forum.telus.com/t5/Mobility-Services/how-do-I-increase-my-phone-rings-to-5-30sec/td-p/787)

Dial *#61# from your phone. Tap Send.

You should see a new screen that displays a bunch of information about what's getting forwarded. You should see a line under "Voice Call Forwarding" that says "Forwards to +11234567890" (where 11234567890 is an eleven digit phone number, likely different from your phone number). Write down this number and End

Now, dial **61*+11234567890*11*XX# and hit Send, where 11234567890 is the number that you found in step two and XX is the number of seconds you want to wait until voicemail picks up. You can set it in increments of 5, where 30 seconds is the maximum.

After you hang up that call, you can have someone call your phone and see if it worked. On some phones, you can dial *#61# again and see how long it's delaying your calls.

[ATT & T-Mobile](https://lifehacker.com/5878635/change-how-long-your-phone-rings-before-sending-calls-to-voicemail)

### Rogers

### Bell Canada

[!NOTE] It seems to me 'Lucky Mobile' brand is a good choice

Mobile Shop. Metropolis at Metrotown. 604-434-6906 
 Province-Wide Calling Plan 35

