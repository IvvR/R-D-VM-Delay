# Connect a node to a gateway

A Proof of Concept (PoC); POC task, I was given a POC task.

## Paho lib

[Practical MQTT with Paho](https://www.infoq.com/articles/practical-mqtt-with-paho)

MQTT was originally created by IBM's Andy Stanford-Clark and Arlen Nipper of Arcom (taken over later by Eurotech) as a complement to enterprise messaging systems so that a wealth of data outside the enterprise could be safely and easily brought inside the enterprise. MQTT is a publish/subscribe messaging system that allows clients to publish messages without concerning themselves about their eventual destination; messages are sent to an MQTT broker where they may be retained.


## Node-RED: IoT 

[Node-RED: IoT data collection made easy](https://www.linkedin.com/pulse/node-red-iot-data-collection-made-easy-zainul-zain/)


## Azure Sample: MQTT and HTTP endpoints for Azure IoT Gateway in node.js using Mosca.

[Sample MQTT and HTTP Gateway modules](https://azure.microsoft.com/en-ca/resources/samples/iot-gateway-mqtt-http/)



## Arduino Ethernet Shield Tutorial

[Arduino Ethernet Shield Tutorial](https://www.instructables.com/id/Arduino-Ethernet-Shield-Tutorial/)

The Arduino Ethernet Shield allows you to easily connect your Arduino to the internet. This shield enables your Arduino to send and receive data from anywhere in the world with an internet connection.

One important thing to keep in mind is that you will have to enter your Arduino's IP address in both of the examples below in order for them to work.

```c
#include <SPI.h>
#include <Ethernet.h>

// Enter a MAC address and IP address for your controller below.
// The IP address will be dependent on your local network:
byte mac[] = { 0x00, 0xAA, 0xBB, 0xCC, 0xDA, 0x02 };
IPAddress ip(191,11,1,1); //<<< ENTER YOUR IP ADDRESS HERE!!!
```

[ESP8266: Connecting to MQTT broker](https://techtutorialsx.com/2017/04/09/esp8266-connecting-to-mqtt-broker/)

The ESP8266 is a low-cost Wi-Fi microchip with full TCP/IP stack and microcontroller capability produced by Shanghai-based Chinese manufacturer Espressif Systems. 

SewerVUE Technology

