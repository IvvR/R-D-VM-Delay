
# Linear regression

a linear regression model has the ability of finding linear relationships between an outcome variable and historical data.

In statistics, linear regression is a linear approach to modelling the relationship between a scalar response (or dependent variable) and one or more explanatory variables (or independent variables).