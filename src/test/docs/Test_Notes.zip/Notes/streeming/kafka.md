# KAfka

to start !!! // no sugar
bin/zookeeper-server-start.sh config/zookeeper.properties

[NOTE!] SoB can't find java location

docker pull spotify/kafka
