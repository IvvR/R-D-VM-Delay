
# I'm curious

Today we’re going to build an amazing Markdown editor using Visual Studio Code and Pandoc. This system will include real-time Markdown linting and the ability to generate html, docx, and pdf documents quickly with the potential to produce many other document formats as well.

- thesis 1
- thesis 2
- thesis 3

Markdown is a simple markup language that allows one to write documents using a text editor and transform those documents into many different formats.  Among other things, it works beautifully for documenting source code since the Markdown documents can be checked in and versioned with Git or your source control system of choice.

|name  |Value  |
|---------|---------|
|Row1     |    10     |
|Row2     |     20    |
|Row3     |    30     |

Pandoc is a highly capable “Swiss army knife” tool for converting documents between various formats.  It is not limited to Markdown as an input (source) format, but it is used extensively in this context.

1. Well
2. It seems
3. working

Finally, Visual Studio Code is a solid, lightweight code editor created by Microsoft.  It is based on the Electron framework, which facilitates the development of desktop GUI applications using the Node.js framework.  I’m a huge fan of VS Code, and have written previous articles about it including the Visual Studio Code Jumpstart for Node.js Developers.

If you are not familiar with the Markdown syntax, check out Adam Pritchard’s Markdown Cheatsheet which includes the standard Markdown syntax as well as the extended GFM (GitHub Flavored Markdown) that we will be utilizing in our editor.   Markdown is an easy syntax to learn and—as a bonus—you won’t have to wrestle with angle brackets, opening and closing tags, etc.
