# Heroku

## Tools installation

go to devcenter, take the script and run:
curl https://cli-assets.heroku.com/install-ubuntu.sh | sh

heroku login -i

add ssh keys
heroku keys:add
check the upload
heroku keys

test ssh connection
ssh -v git@heroku.com

heroku create
Creating app... done, ⬢ young-scrubland-45466
https://young-scrubland-45466.herokuapp.com/ | https://git.heroku.com/young-scrubland-45466.git
ivan@ivr:~/projects/node-servers/express-server\$

git push heroku
remote: -----> Launching...
remote: Released v3
remote: https://young-scrubland-45466.herokuapp.com/about deployed to Heroku

[!NOTE] no sugar.lol

> code=H10 desc="App crashed" method=GET path="/favicon.ico"

heroku restart

## heroku redeploy

git push heroku
