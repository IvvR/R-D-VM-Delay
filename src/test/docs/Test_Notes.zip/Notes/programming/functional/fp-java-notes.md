
# Java FP

## Composing functions

If you think about functions as methods, composing them seems simple:

```java

System.out.println(square.apply(triple.apply(2)));
36
```

But this isn’t function composition. In this example, you’re composing function appli-
cations. Function composition is a binary operation on functions, just as addition is a
binary operation on numbers.

```java
Function compose(final Function f1, final Function f2) {
return new Function() {
@Override
public int apply(int arg) {
return f1.apply(f2.apply(arg));
}
};
}
System.out.println(compose(triple, square).apply(3));
27
```
