# Spring - Netflix-OSS

## Zuul - API gateway

Zuul is a gateway service that provides dynamic routing, monitoring, resiliency, security, and more

## API Rate limiter

OSS lib implemented as a extension of Zuul Filters
[Rate Limiting in Spring Cloud Netflix Zuul](https://www.baeldung.com/spring-cloud-zuul-rate-limit)

When a limit is reached the API Gateway returns 429 Too Many Requests status code to the client
