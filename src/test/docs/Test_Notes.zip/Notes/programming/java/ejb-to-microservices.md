
# EJB monolith to microservices

[Refactoring to microservices, Part 1](https://www.ibm.com/developerworks/cloud/library/cl-refactor-microservices-bluemix-trs-1/index.html)

In the early 2000s we all started building ever-larger EAR files to contain our logical applications. We then deployed those EARs across every WebSphere® Application Server in our farm. The problem is that this tied each piece of code in that application to the same deployment schedules and the same physical servers. Changing anything meant retesting everything, and that made any changes too expensive to consider.

[Step by step examples](https://github.com/lasalazarr/guide-monolithic-to-microservices)


[ORM or a stored procedure](https://www.quora.com/Is-it-better-to-select-objects-in-a-database-via-an-ORM-or-a-stored-procedure)

There are performance advantages to a stored procedure over ORM for a couple of reasons.

- A stored procedure will be pre-compiled in the database engine
- The execution plans will be cached.

how/where to use them

- Your application requires data that needs to be transposed or aggregated from multiple queries or views. 
- Fine grain access control. You do not want some idiot running cartesian joins in your db, but you cannot just forbid people from executing arbitrary SQL statements just like that either. 

[Migrating to Microservices](https://thenewstack.io/migrating-to-microservices/)
Stored procedures should be made into microservices

[Right Database for Your Microservices](https://thenewstack.io/selecting-the-right-database-for-your-microservices/)


[Performance Testing of Event-Driven Microservices](https://medium.com/capital-one-developers/performance-testing-of-event-driven-microservices-f5de74305985)

[How to test an application's scalability, performance](https://searchsoftwarequality.techtarget.com/answer/How-to-test-an-applications-scalability-performance)

[Performance & Reliability Engineering](https://www.linkedin.com/pulse/performance-reliability-engineering-monolithic-vs-application-khan)

[The Hows, Whys and Whats of Monitoring Microservices](https://thenewstack.io/the-hows-whys-and-whats-of-monitoring-microservices/)

[why SOA goes bad](https://www.cio.com/article/2434865/service-oriented-architecture/top-10-reasons-why-people-are-making-soa-fail.html)


[The fate of the ESB](https://www.ibm.com/developerworks/cloud/library/cl-lightweight-integration-1/index.html)

[Enterprise Service Bus vs Traditional SOA](https://blogs.mulesoft.com/dev/connectivity-dev/esb-vs-soa/)

A different way to approach the problems SOA was meant to solve is with a standalone enterprise service bus (ESB) or integration platform as a service (iPaaS) instead of a full proprietary stack. ESBs can power the creation and orchestration of services without requiring an application server or other infrastructure component, eliminating the high upfront costs of implementing SOA. Instead of a years-long rollout period, an ESB can be implemented and deployed in a very short period. This enables developers to build reusable interfaces with APIs while also establishing a core framework for integrating a governance model for the future.

