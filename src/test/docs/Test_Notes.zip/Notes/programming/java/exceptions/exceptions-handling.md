# Exceptions handling

## requiredNotNull

Static method of Objects.requiredNotNull(E e, Supplier<String> s)