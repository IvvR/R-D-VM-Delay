# Annotations

## Javadoc Tags @apiNote, @implSpec and @implNote

[Javadoc Tags @apiNote, @implSpec and @implNote](https://blog.codefx.org/java/new-javadoc-tags/)

