# IDE tuning

## Eclipse fonts

[Change Project Explorer tree view font size in Eclipse Oxygen](https://stackoverflow.com/questions/47731327/change-project-explorer-tree-view-font-size-in-eclipse-oxygen?rq=1)

To increase eclipse tree panel font

- e4-dark.css
- add to the end of the file

```css
.MPart Tree {
    font-family: Consolas;
    font-size: 12;
}
```