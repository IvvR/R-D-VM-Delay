# Java - jSON notes
 
"JSON de/serialization is boring. It’s this annoying thing that you have to do in order to get your application to talk to another computerized system..I have never met a developer who told me how much pleasure they derived from turning classes into JSON strings and back.

I have, however, met more than one developer that has run into trouble getting library X to cover one of the simple use-cases outlined above. Believe me, there is nothing more frustrating than having to spend time on the annoying task of setting up JSON de/serialization in order to do the boring thing of tossing strings back and forth the network. That’s time you will never get back.
".
[Manuel Bernhardt.](https://manuel.bernhardt.io/)

[How to Parse JSON in Java](https://explainjava.com/parse-json-java/)
by Volodymyr Kuznietsov

JSON types / actually JS types. 
seven value types: string, number, object, array, true, false, and null.

two data structures

Q: Is json going to update to new JS structures - maps, sets ? 
or  how to map Javascript   maps, sets.
A:  well, there is the answer for JS.  
[Converting ES6 Maps to and from JSON](http://2ality.com/2015/08/es6-map-json.html)
Let's look for java.

JSON Parsers in Java.
- object (memory hogs)
- streaming

The Java API for JSON Processing (JSON-P) is described in JSR 353.


