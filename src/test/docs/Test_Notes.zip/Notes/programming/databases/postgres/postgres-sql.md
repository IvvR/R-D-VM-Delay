# postgres sql

## ORDER BY

select first_name, last_name, email from customer
order by last_name ASC;

[!NOTE] POSTgress pgAdmin case sensitive. it doesn't understend asc but OK witH ASC / DESC

> DOSN'T sort properly on lower cases. 'psql' terminal is good

SELECT last_name, first_name, email FROM customer ORDER BY last_name;
SELECT last_name, first_name, email FROM customer ORDER BY last_name DESC;
SELECT last_name, first_name, email FROM customer ORDER BY first_name ASC, last_name DESC;

task: cust ID of top 10 highest amount

SELECT _ FROM cust limit 1;
//top 10 - LIMIT 10;
SELECT _ FROM cust limit 10;
top - ORDER BY amount DESC
SELECT \* FROM cust ORDER BY amount DESC limit 10;

SELECT customer_id, amount FROM payment ORDER BY amount DESC limit 10;

task : get titles of the movies with film id 1 to 5;

to discover the table structure
SELECT \* FROM film LIMIT 1;

SELECT title, film_id FROM film ORDER BY film_id ASC limit 5;

## BETWEEN / NOT BETWEEN

SELECT \* FROM payment WHERE amount BETWEEN 9 AND 10;
SELECT customer_id, amount FROM payment WHERE amount NOT BETWEEN 9 AND 10;

SELECT amount, payment_date FROM payment WHERE payment_date BETWEEN '2007-02-01' AND '2007-03-01';

## IN / NOT IN

customer_id FROM rental WHERE customer_id IN (SELECT customer_id FROM CUSTOMER WHERE customer_id BETWEEN 6 AND 10) ORDER BY return_date DESC;

## LIKE /NOT LIKE / ILIKE

SELECT LAST_NAME, FIRST_NAME, EMAIL FROM customer WHERE first_name LIKE 'Al%' ORDER BY last_name;

LIKE is case sensitive but ILIKE is not

### pattern mattiching

wild card characters

## Integr task

How many payment transactions were grater then \$5

SELECT COUNT(amount) FROM payment WHERE amount > 5;
SELECT COUNT(payment_id) FROM payment WHERE amount > 5;

How many actors have a name starts with letter 'P'

> ( ) are excessive
> SELECT COUNT(first_name) FROM actor WHERE first_name LIKE ('P%');

SELECT COUNT(first_name) FROM actor WHERE first_name LIKE 'P%';
SELECT COUNT(first_name) FROM actor WHERE first_name ILIKE 'p%';
SELECT COUNT(\*) FROM actor WHERE first_name ILIKE ('p%');

--
how many unique districts are our customers from

question store_id or address_id
SELECT DISTINCT address_id

[!NOTE] good hint, get more data - customer table and address is deceptive
SELECT COUNT (DISTINCT (district)) FROM address;

to find unique district names
SELECT DISTINCT (district) FROM address ORDER BY ASC;

without empty fields
SELECT DISTINCT (district) FROM address WHERE district <>'' ORDER BY district ASC;

how many films have rating R and a replacement cost betwee 5 and 15

SELECT COUNT (\*) FROM film WHERE rating='R' AND replacement_cost BETWEEN 5 AND 15;

how many films have the word Truman in the title
SELECT COUNT(\*) FROM film WHERE title ILIKE '%Truman%';

## GROUP BY

SELECT ROUND(AVG(amount), 2) av, c.last_name FROM payment p INNER JOIN customer c ON p.customer_id = c.customer_id GROUP BY p.customer_id, c,last_name ORDER BY av DESC;

SELECT ROUND(SUM(amount), 2) av, c.last_name FROM payment p INNER JOIN customer c ON p.customer_id = c.customer_id GROUP BY p.customer_id, c,last_name ORDER BY av DESC;
