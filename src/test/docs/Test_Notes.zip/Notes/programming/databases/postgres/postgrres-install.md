# Postgres install

[How To Install and Use PostgreSQL on Ubuntu 16.04 ](https://www.digitalocean.com/community/tutorials/how-to-install-and-use-postgresql-on-ubuntu-16-04)

https://hevodata.com/blog/install-postgresql-on-ubuntu/

The default role for PostgreSQL is called :
postgres
sudo -i -u postgres

This will ask for the user account password which is same as the login password.
[!NOTE] it didn't

terminal for postgreSQL:
psql

show databases
\l
\q - exit from \l

connect to database_name
\c testdb;
\c dvdrental;

## pgAdmin

to connect modify password for role postgres:

```bash
sudo -u postgres psql postgres
alter user postgres with password 'postgres';
```

## Start / stop / status

- service postgresql status
- sudo service postgresql stop
- sudo /etc/init.d/postgresql stop
- sudo /etc/init.d/postgresql start
