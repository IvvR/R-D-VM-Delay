# Postgres

[Docker Hub](https://hub.docker.com/_/postgres/)

poll from the Docker Hub:

- docker pull postgres

- docker run --name posgree-boot -e POSTGRES_PASSWORD=mysecretpassword -p 5432:5432

This image includes EXPOSE 5432 (the postgres port), so standard container linking will make it automatically available to the linked containers. The default postgres user and database are created in the entrypoint with initdb.

\$ docker run --name some-postgres -e POSTGRES_PASSWORD_FILE=/run/secrets/postgres-passwd -d postgres

## check opened ports

- nmap localhost

[!NOTE] 5432 is opened
