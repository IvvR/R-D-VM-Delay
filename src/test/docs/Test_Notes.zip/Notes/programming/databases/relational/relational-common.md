# Relational Databases. Common

Schema on write is defined as creating a schema for data before writing into the database. 

Data  in  a	 relational	 database is stored	 in relations,	which	are	perceived by the user as	tables.	Each relation is composed of tuples	(records or	rows) and	attributes (fields	or	columns).

Remember that the quality of the information	you	get	from	your	data	is	in	direct	proportion	to the	amount	of	time	you’ve	dedicated	to	ensuring	the	structural	integrity	and	data integrity of	the columns	themselves.

## Keys are special columns.

A	primary	key	consists	of	one	or	more	columns	that	uniquely	identify	each	row within	a	table.	(When	a	primary	key	is	composed	of	two	or	more	columns,	it	is known	as	a	composite	primary	key.) 
The	primary	key	is	the	most	important	for two	 reasons:	 Its	 value	 identifies	 a	 specific	 row	 throughout	 the	 entire	 database, and	its	column	identifies	a	 given	table	 throughout	 the	 entire	 database.	 Primary keys	also	enforce	table-level	integrity	and	help	establish	relationships	with	other tables.

the	 correct  way  to design a	relational	database is	to	break up your data so that you	have one	table per subject or event.

## Relationships

### One-to-One

a special type	of	relationship	because	in	nearly	all	cases	the foreign	key	also	acts as	the	primary	key	of	the	secondary	table.

### Many-to-Many

a linking table

## Database	Structure. logical design

for poorly designed database structure,	many of	the	SQL	statements 	at	best, difficult	to	implement or, at worst, relatively  useless.

poorly designed  database structures affect  integrity,  table	relationships,
and	 the  ability  to  retrieve	 accurate  information.

### Fine-Tuning	Columns

in tip-top shape.

- the name descriptive	and	meaningful
- the column  name  clear  and  unambiguous
- don't use acronym	 or	 abbreviation. it causes ambiguity
- use the	singular form	of	the	column	name

don’t use the same column name in several tables; add a short prefix.

logical tuning

- Make	sure the column	represents	a specific characteristic	of	the	subject	of	the table; the	column must	truly	belongs	in	the table.
- Make	certain	that the column	contains only a	single	value. Multivalued	 and	 multipart	 columns	 can	 wreak	 havoc  in your	database, especially when you try to edit, delete, or	sort the data.
- Make	 sure the column does not store	 the result	 of	 a calculation or concatenation. When	the value  of any  part of the  calculation  changes, the result  value	 stored	 in	 the column	 is not updated. !!! some dbs have calculated type
- Make	certain	the	column	appears	only once in the entire	database (to make data inconsistent)

#### Resolving	Multipart Columns

- Can I take the current value	 of	 this column and break it up into smaller,	more distinct	parts?
- Will	I	have	problems	extracting	a	specific	piece of	information	because	it	is	buried	in	a	column	containing	other	information? 

#### Resolving	Multivalued	Columns

linking	table

## Fine-Tuning Tables

- used	the plural form for table names

### Sound Structure

- Make sure the table represents a single subject. the subject represented by the table	can	be	an	object	or	event.
- Make	certain	each table	has	a	primary	key

### Identification	Is	the	Key

simple primary ke vs composite	primary	keys : s are more efficient

PK identification questions:

- uniquely	identify each row
- contain unique value
- could contain unknown values. // must not.
- could ever be	optional //  cannot
- a multipart column // should be eliminated
- could ever be modified // should never be changed

[!NOTE] ENGLISH
> who became known for his exceptional spirit of friendship toward the former Evil Empire’s 
> latest management.

 