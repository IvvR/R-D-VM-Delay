# SQL

## Select

Nearly	 any question	regarding	who,	what,	where,	when,	or	even	what	if	and	how	many	can be	answered	with	SELECT.	

The	 SELECT	 operation	 in	 SQL	 can	 be	 broken	 down	 into	 three	 smaller
operations:

- statement
- expression
- query

Each	 of	 these	 operations	 provides	 its	 own	 set	 of	 keywords	 and
clauses.

### The	SELECT	Statement

many RDBMS allow to	 save	 a	 SELECT	 statement	 as	 a	 query,	 view, function,	or	stored	procedure. to	query	the database means to	execute	some	sort	of	SELECT	statement.

extensions: Transact-SQL and Oracle’s PL/SQL.

brief	summary	of	the	clauses	in	a	SELECT	statement:

- SELECT — the primary clause to specify the columns in	the	result set	of a query
- FROM - to	specify	the	tables	or	views from which to	 draw the columns
- WHERE - use to filter	the	rows. WHERE	is a predicate.
- GROUP	BY - to	divide the information into distinct groups.
- HAVING - filters the result of aggregate functions in grouped information

aggregate	functions	in	the	SELECT	clause	to produce	summary	information

### Sorting information: ORDER BY clause

to	sort the rows	of	a	result	set the	 SELECT	 statement,	 the SELECT expression,	 and the SELECT	 query should be combined. To	sort the result	set	the	SELECT
statement have	to be embed within a	SELECT	query.

The	 ORDER	 BY	 clause	 allows to	 sort the result set by	 one or	 more columns by specifying	 an ascending or	descending	sort order	for each column.

#### Collating	Sequences

```sql
Select	<item>	from the <source> and order	by	<column(s)>
SELECT Category FROM Classes ORDER	BY	Category
SELECT	VendName,	VendZipCode FROM Vendors ORDER	BY	VendZipCode	DESC
SELECT	EmpLastName, EmpFirstName,EmpPhoneNumber, EmployeeID FROM Employees ORDER BY	EmpLastName	DESC, EmpFirstName ASC
```

the sort order is usually self-evident. ORDER BY can specify a different sort order for each column.

the first SELECT doesn't work as a table name is case sensitive. Next one is good !

```sql
SELECT VendName, VendCit, VendState, VendZipCode, VendPhoneNumber FROM VENDORS ORDER  BY VendCit ACS
SELECT VendName, VendCity, VendState, VendZipCode, VendPhoneNumber FROM Vendors ORDER  BY VendCity;
-- SELECT VendName, VendCity, VendState, VendZipCode, VendPhoneNumber FROM Vendors GROUP BY VendState 
-- ORDER  BY VendCity; // NO LUCK.
SELECT VendState, COUNT(*) FROM Vendors GROUP BY VendState;
SELECT ProductName, RetailPrice FROM Products
SHOW COLUMNS FROM Products

```

## Expressions

use	expressions	to “slice and dice” the plain-vanilla data in your columns to create more meaningful
results in your queries. 

### SQL Datatypes

