# Cassandra modeling

[Advanced Time Series Data Modelling](https://www.datastax.com/dev/blog/advanced-time-series-data-modelling)

## Credit card transaction app

```cql
create table if not exists latest_transactions(
 credit_card_no text,
 transaction_time timestamp,
 transaction_id text,
 user_id text,
 location text,
 items map<text, double>,
 merchant text,
 amount double,
 status text,
 notes text,
 PRIMARY KEY (credit_card_no, transaction_time)
) WITH CLUSTERING ORDER BY ( transaction_time desc);
```

