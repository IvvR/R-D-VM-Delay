# Cassandra use cases

[Cassandra Use Cases]
(https://blog.pythian.com/cassandra-use-cases/)

## Wrong Features

- Secondary indexes: They have their uses but not as an alternative access path into a table.
- Counters: They work most of the time, but they are very expensive and should not be used very often.
- Light weight transactions: They are not transactions nor are they light weight.
- Batches: Sending a bunch of operations to the server at one time is usually good, saves network time, right? Well in the case of Cassandra not so much.
- Materialized views: I got taken in on this one. It looked like it made so much sense. Because of course it does. But then you look at how it has to work, and you go…Oh no!
- CQL: Looks like SQL which confuses people into thinking it is SQL.

Using any of the above features the way you would expect them to work in a traditional database is certain to result in serious performance problems and in some cases a broken database.

# Wrong Use Cases for Cassandra

- Tables have multiple access paths. Example: lots of secondary indexes.
- The application depends on identifying rows with sequential values. MySQL autoincrement or Oracle sequences.
- Cassandra does not do ACID. LSD, Sulphuric or any other kind. If you think you need it go elsewhere. Many times people think they do need it when they don’t.
- Aggregates: Cassandra does not support aggregates, if you need to do a lot of them, think another database.
- Joins: You many be able to data model yourself out of this one, but take care.
- Locks: Honestly, Cassandra does not support locking. There is a good reason for this. Don’t try to implement them yourself. I have seen the end result of people trying to do locks using Cassandra and the results were not pretty.
- Updates: Cassandra is very good at writes, okay with reads. Updates and deletes are implemented as special cases of writes and that has consequences that are not immediately obvious.
- Transactions: CQL has no begin/commit transaction syntax. If you think you need it then Cassandra is a poor choice for you. Don’t try to simulate it. The results won’t be pretty.

## When you should think about using Cassandra

- Distributed: Runs on more than one server node.
- Scale linearly: By adding nodes, not more hardware on existing nodes.
- Work globally: A cluster may be geographically distributed.
- Favor writes over reads: Writes are an order of magnitude faster than reads.
- Democratic peer to peer architecture: No master/slave.
- Favor partition tolerance and availability over consistency: Eventually consistent (see the CAP theorem: https://en.wikipedia.org/wiki/CAP_theorem.)
- Support fast targeted reads by primary key: Focus on primary key reads alternative paths are very sub-optimal.
- Support data with a defined lifetime: All data in a Cassandra database has a defined lifetime no need to delete it after the lifetime expires the data goes away.

## Ideal Cassandra Use Cases

- Writes exceed reads by a large margin.
- Data is rarely updated and when updates are made they are idempotent.
- Read Access is by a known primary key.
- Data can be partitioned via a key that allows the database to be spread evenly across multiple nodes.
- There is no need for joins or aggregates.

Some of my favorite examples of good use cases for Cassandra are:

- Transaction logging: Purchases, test scores, movies watched and movie latest location.
- Storing time series data (as long as you do your own aggregates).
- Tracking pretty much anything including order status, packages etc.
- Storing health tracker data.
- Weather service history.
- Internet of things status and event history.
- Telematics: IOT for cars and trucks.
- Email envelopes—not the contents.

by John Schulz, Pricipal Consultant  
John has 40 of years experience working with data. Data in files and in Databases from flat files through ISAM to relational databases and, most recently, NoSQL. For the last 15 year he's worked on a variety of Open source technologies including MySQL, PostgreSQL, Cassandra, Riak, Hadoop, and Hbase. As a Chief Database Architect at AOL he brought MySQL in to replace Sybase and has worked hands on with MySQL databases holding hundreds of billions of rows and running millions of transactions per second. For the last three years he has been working for Pythian to help their customers improve their existing databases and select new ones for new applications. 

Datascape podcast. In this episode, I discuss the NoSQL database, Cassandra with industry expert, John Schulz. We explore what it is, key differences from a Relational Database, use cases and tips. 
[Episode 30 - Learning about Streaming](https://www.stitcher.com/podcast/chris-presley/the-datascape-podcast/e/49351013)

[!NOTE] English 
> catch wind
> don’t aspire to be
> a pinnacle  

Pfeil had caught wind that Ellis was going to be moving on from Rackspace to found a company around Apache Cassandra and was determined to talk him into staying.   
I am not an expert in Cassandra internals and don’t aspire to be if I can avoid it.

## Usage

The question to ask is what kind of queries you are going to run and what query performance you are expecting. Depending on your query patterns it would be possible to predict performance compared to relational database systems. 

We use day to day Cassandra for High Frequency data - about 250k*100*4 =100 millions rows every day 

## When should Cassandra be used?

 - In activity-tracking and monitoring applications: Numerous entertainment and media organisations use Cassandra to monitor user activity based on movies, music, albums, artists or other parameters.
 - In heavy write systems or in time-series-based applications: Cassandra is perfect for very heavy write systems  for example, in Web analytics where the data is logged for each request based on hits, by type of browser, traffic sources, location, behaviour, technology, devices, etc.

