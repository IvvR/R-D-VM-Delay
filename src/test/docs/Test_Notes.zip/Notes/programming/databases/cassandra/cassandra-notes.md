
# Cassandra notes

Why Cassandra

- good for event sourcing model: fast, excellent partitioning
- easy to learn

[JSON ](https://stackoverflow.com/questions/36342531/efficient-way-to-store-a-json-string-in-a-cassandra-column)

Store it as a text type. Cassandra's Binary Protocol support transport compression. Use LZ4 algorithm  since it's the fastest algo implemented.

However, streaming on Cherrypy isn’t for the faint of heart. 

## Installation

[Installation for Ubuntu 16.04](https://www.vultr.com/docs/how-to-install-apache-cassandra-3-11-x-on-ubuntu-16-04-lts)
Add	the	repository	to	the	 /etc/apt/sources.list.d/cassandra.sources.list :

echo "deb http://debian.datastax.com/community stable main"| sudo tee -a /etc/apt/sources.list.d/cassandra.sources.list

Add	the	DataStax	repository	key	to	your	aptitude	trusted	keys:
curl -L https://debian.datastax.com/debian/repo_key	| sudo apt-key add -

Use the newly added apt repo to install Apache Cassandra:
sudo apt-get install cassandra

## Start the service

```bash
sudo systemctl start cassandra.service
sudo systemctl stop cassandra.service
sudo systemctl enable cassandra.service
sudo systemctl disable cassandra.service
sudo systemctl restart cassandra.service

systemctl start cassandra.service

systemctl is-active cassandra.service
systemctl is-enabled cassandra.service
```

[!NOTE]
> looks good after restart

```log
systemctl status cassandra.service
● cassandra.service - LSB: distributed storage system for structured data
   Loaded: loaded (/etc/init.d/cassandra; bad; vendor preset: enabled)
   Active: active (exited) since Thu 2018-11-08 04:01:42 PST; 2min 2s ago
     Docs: man:systemd-sysv-generator(8)
  Process: 29685 ExecStop=/etc/init.d/cassandra stop (code=exited, status=0/SUCCESS)
  Process: 29731 ExecStart=/etc/init.d/cassandra start (code=exited, status=0/SUCCESS)

Nov 08 04:01:42 ivr systemd[1]: Starting LSB: distributed storage system for structured data...
Nov 08 04:01:42 ivr systemd[1]: Started LSB: distributed storage system for structured data.
```

## Network status

[!NOTE]
> life's tough for kids
> let's try with Docker

[Getting Started with Cassandra on Docker](https://medium.com/@michaeljpr/five-minute-guide-getting-started-with-cassandra-on-docker-4ef69c710d84)

- Stop the local installation
- sudo docker run -e DS_LICENSE=accept --memory 4g --name my-dse -d datastax/dse-server -g -s -k
- sudo docker run -e DS_LICENSE=accept --link my-dse -p 9091:9091 --memory 1g --name my-studio -d datastax/dse-studio
- sudo docker stop my-dse
- sudo docker container ls
- sudo docker remove my-dse // sucks - rm


[How to Remove Docker Images and Containers](https://tecadmin.net/remove-docker-images-and-containers/)  
Remove Docker Containers  
    docker rm my-dse
Check the result  
    sudo docker ps -a

docker inspect my-dse | grep IPAddress   // 172.17.0.2
docker exec -it my-dse cqlsh [IPAddress]

sudo docker exec -it my-dse cqlsh 172.17.0.2

[!NOTE]
> Yeah. Some sugar for today

```bash
ivan@ivr:~$ sudo docker exec -it my-dse cqlsh 172.17.0.2
Connected to Test Cluster at 172.17.0.2:9042.
[cqlsh 5.0.1 | DSE 6.0.4 | CQL spec 3.4.5 | DSE protocol v2]
Use HELP for help.
cqlsh>
```

## Local cassandra

ok next try

[Connection refused (Cassandra)](ttps://www.liquidweb.com/kb/error-failed-to-connect-to-127-0-0-17199-connection-refused-cassandra-solved/)

sudo gedit /etc/cassandra/cassandra-env.sh

```sh
# add this if you’re having trouble connecting:
# JVM_OPTS=”$JVM_OPTS -Djava.rmi.server.hostname=<public name>”
```

Uncomment the second line, and add the hostname of your server, or the IP address which you’re connecting to/from. In this case, replacing <public name> with 127.0.0.1 resolved the issue, because I am connecting to/from that IP address.

cqlsh 127.0.0.1

// no sugar

sudo systemctl is-enabled cassandra
sudo systemctl stop cassandra.service
sudo systemctl enable cassandra.service
sudo systemctl start cassandra.service

### Uninstall completely

[reinstall a cassandra on ubuntu?](https://stackoverflow.com/questions/13390775/how-can-i-reinstall-a-cassandra-on-ubuntu)

- sudo apt-get remove cassandra
- rm -rf /var/lib/cassandra  // empty 
- rm -rf /var/log/cassandra  // empty 
- sudo rm -rf /etc/cassandra

find / -name 'cassandra' 

/etc/default/cassandra
/etc/init.d/cassandra

cd /etc/default/
rm cassandra
sudo rm -rf /run/cassandra

Check the permissions on each of those directories. In my installs of Cassandra 1.1.6 on Ubuntu 10.04, /etc/cassandra is owned by root, and /var/lib/cassandra and /var/log/cassandra are owned by the cassandra user and group.

### 

Apache Cassandra requires Python 2.7 rather than Python 3. If you operate Apache Cassandra in a Python 3 environment, you may have trouble launching the cqlsh shell of Apache Cassandra.

### Python dev

let's start with REPL

python --version

#### conda

create environment:  

- conda env list
- conda create --name cassandra_env
- source activate cassandra_env

```bash
conda update --all
conda install -c conda-forge cassandra-driver
```

### VSCode environment

To select an specific environment, use the Python: Select Interpreter command from the Command Palette (Ctrl+Shift+P).

```python
from cassandra.cluster import Cluster
cluster = Cluster(['172.17.0.2', '172.17.0.2'])
cluster = Cluster(['172.17.0.2'])
session = cluster.connect()
session.execute('USE system')
session.execute('USE "HiveMetaStore"')

rows = session.execute('SELECT key, entity FROM  "HiveMetaStore".sparkmetastore')
for m_store in rows:
    print m_store.key, m_store.entity
```

> find all tabs and replaced by 4 spaces in notepad ++ .It worked.


USE "HiveMetaStore";
DESC tables;
SELECT key, entity FROM  "HiveMetaStore".sparkmetastore;
SELECT * FROM  "HiveMetaStore".sparkmetastore;
