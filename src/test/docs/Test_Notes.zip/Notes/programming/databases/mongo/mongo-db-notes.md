
# Mongo DB notes

## Installation

installation for Ubuntu 16.04
[digital ocean](https://www.digitalocean.com/community/tutorials/how-to-install-mongodb-on-ubuntu-16-04)  

> [!NOTE]
> How to know Ubuntu repository version of an app  
> apt-cache policy mongodb-server  
> Version table:  
>     1:2.6.10-0ubuntu1 500  

Yeah, default stuff is really old.  
lets's follow '[digital ocean' instructions
mongod --version  

> [!CAUTION]
> Shit! Key is old, just v 3.2  
> sudo apt-key del EA312927  
> update for v 4.0 from official Mongo site  

[Install MongoDB Community Edition on Ubuntu](https://docs.mongodb.com/manual/tutorial/install-mongodb-on-ubuntu/)

Procedure is pretty clear. Check the status after installation.  
sudo systemctl status mongodb  

> [!NOTE]
> ok. not active. lets's start  
> sudo service mongod start  // it seems it's not gonna happen ) bitch !  
> lololol !!  
> checked the log : /var/log/mongodb/mongod.log  
> apparently it's working.  
> try again : sudo systemctl status mongodb  
>   Memory: 45.5M  
> It's not especially big

Ok. I need the way how to know 'mongo' is working. 

> [!IMPORTANT]
> command 'sudo systemctl status mongodb' is deceptive
> log : '/var/log/mongodb/mongod.log' works but with the long time lag.

Secure access.
sudo ufw status. good. ufw  works.
well what is my address
sudo ufw allow from 69.172.165.226/32 to any port 27017  
The /32 references the explicit IP address you've given  

## Begin using MongoDB

Start a mongo shell on the same host machine as the mongod. Use the --host command line option to specify the localhost address (in this case 127.0.0.1) and port that the mongod listens on:  
mongo --host 127.0.0.1:27017

# Mongo Compass

Graphic UI, comunity edition  
sudo dpkg -i mongodb-compass_1.15.1_amd64.deb  

