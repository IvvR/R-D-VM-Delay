# MySQL work

connect to the container
    docker exec -it study mysql -uroot -p

MySQL stores the user information in its own database with name 'mysql'.

SHOW DATABASES;
SELECT User, Host, authentication_string FROM mysql.user;

[Install MySQL Server on Ubuntu](https://support.rackspace.com/how-to/installing-mysql-server-on-ubuntu/)


run shell : mysqlsh

    \quit
    \sql
    \status or \s   //connected or not


[MySQL Shell Commands](https://dev.mysql.com/doc/mysql-shell/8.0/en/mysql-shell-commands.html)

\connect [--mx|--mysqlx|--mc|--mysql] <URI>
\connect --mysqlx  -u root -h localhost -P 33065 // nope
\connect --mysqlx  localhost 

[!NOTE]
> progress...

```shell
MySQL  SQL > \connect --mysqlx  localhost
Creating an X protocol session to 'ivan@localhost'
Please provide the password for 'ivan@localhost': *****
MySQL Error 2002: Connection refused connecting to localhost:33060
```

TODO: create a user and give him privilidges with 

- connect to mysql container as a root
docker exec -it study mysql -uroot -p
- add a user // no sugar again!!!
INSERT INTO mysql.user (User,Host,authentication_string,ssl_cipher,x509_issuer,x509_subject)
VALUES('ivan','localhost',PASSWORD('test'),'','','');

ok. the right way
[6.3.2 Adding User Accounts](https://dev.mysql.com/doc/refman/8.0/en/adding-users.html)

Creating local user with admin acct
    CREATE USER 'ivan'@'localhost' IDENTIFIED BY 'test';
    GRANT ALL PRIVILEGES ON *.* TO 'ivan'@'localhost' WITH GRANT OPTION;

MySQL Error 2002: Connection refused connecting to localhost:33060

trying FLUSH
FLUSH PRIVILEGES;

[!NOTE]
> containerized mysql wants probably remote user

mysql> CREATE USER 'ivan'@'%' IDENTIFIED BY 'test';
mysql> GRANT ALL PRIVILEGES ON *.* TO 'ivan'@'%' WITH GRANT OPTION;
mysql> FLUSH PRIVILEGES;

ok, let's check the ports
> bloody docker kept them closed
> opened with -p option

mysqlsh \connect --mysql  localhost

[Chapter 19 MySQL Shell User Guide]
(http://www.dba86.com/docs/mysql/8.0/mysql-shell.html)

[!NOTE] FINNALY, I've got it !!!

    mysqlsh --mysqlx -u ivan -h localhost -P 33060

```mysql
MySQL  localhost:33060+ ssl  SQL > \s
MySQL Shell version 8.0.13

Session type:                 X
Connection Id:                12
Default schema:               
Current schema:               
Current user:                 ivan@172.17.0.1
SSL:                          Cipher in use: ECDHE-RSA-AES128-GCM-SHA256 TLSv1.2
Using delimiter:              ;
Server version:               8.0.13 MySQL Community Server - GPL
Protocol version:             X protocol
Client library:               8.0.13
Connection:                   localhost via TCP/IP
TCP port:                     33060
Server characterset:          utf8mb4
Schema characterset:          utf8mb4
Client characterset:          utf8mb4
Conn. characterset:           utf8mb4
Uptime:                       1 hour 13 min 40.0000 sec
```

### MySQL command tool & shell.

[!NOTE] 
> OK. Load db to a docker container

home dir
mysqlsh --mysql -u ivan -h localhost -P 3306