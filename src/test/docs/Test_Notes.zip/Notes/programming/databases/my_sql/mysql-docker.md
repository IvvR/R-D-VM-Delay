# MySQL Docker

- pull. 
docker pull mysql/mysql-server:latest
- check. 
docker image ls.
got mysql latest, mysql5
- container deployment
docker run --name=mortals -d mysql:latest

To start a container in detached mode, you use -d=true or just -d option. 

check working instances
docker run --name=mortals -d mysql:latest

docker status: exited
Q: What is the difference between dead and exited containers?

// they seem the same to me
docker container ls -a
docker ps -a

The MySQL password
docker logs study

[!NOTE]
> ok , the correct launch command is the following:

docker run --name some-mysql -e MYSQL_ROOT_PASSWORD=my-secret-pw -d mysql:tag

> more correct launch
 docker run --name mysql -p 3306:3306 -e MYSQL_ROOT_PASSWORD=password -d mysql/mysql-server:latest


-e can pull in the value from the current environment if you just give it without the =:
    sudo PASSWORD='foo' docker run  [...] -e PASSWORD [...]
with env params: docker run my-awesome-image -e VAR_FROM_ENV -e "MYVAR=2"

    docker run --name=study -e MYSQL_ROOT_PASSWORD=test -d mysql:latest

    docker run --name=study  -p 3306:3306 -p 33060:33060 -e MYSQL_ROOT_PASSWORD=test -d mysql:latest


// no sugar
docker start mortals -e MYSQL_ROOT_PASSWORD=mortal
// killed the container and started the ny one. looks good
    docker logs study
// let's do it again

[!NOTE] IT SEEMS TO ME i've got some sugar finally

- docker stop study
- docker rm study
- docker run --name=study  -p 3306:3306 -p 33060:33060 -e MYSQL_ROOT_PASSWORD=test -d mysql:latest
- docker container ls -a
- docker logs study

from the container log

```log
port: 3306  MySQL Community Server - GPL.
[System] [MY-011323] [Server] X Plugin ready for connections. Socket: '/var/run/mysqld/mysqlx.sock' bind-address: '::' port: 33060
```

Logging into the MySQL Server
    docker exec -it study mysql -uroot -p
where
--interactive , -i 	false 	Keep STDIN open even if not attached
--tty , -t 	false 	Allocate a pseudo-TTY
--user , -u 		Username or UID (format: <name|uid>[:<group|gid>])

[docker container exec](http://docs.docker.oeynet.com/edge/engine/reference/commandline/container_exec/#description)

## start after reboot

docker start my_container

```bash
docker container ls -a

ade011d31521  mysql:latest "docker-entrypoint.s…"   2 weeks ago  Exited (0) 8 days ago

docker start ade011d31521
```