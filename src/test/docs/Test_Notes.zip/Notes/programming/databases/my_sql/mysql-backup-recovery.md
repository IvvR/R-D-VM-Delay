# MySQL Backup Recovery

[MySQL Backup and Restore in Docker]
(https://medium.com/@tomsowerby/mysql-backup-and-restore-in-docker-fcc07137c757)

[create dump](https://devopsheaven.com/mysql/mysqldump/databases/docker/backup/2017/09/17/backup-mysql-database-using-docker.html)

[restore](https://devopsheaven.com/mysql/databases/docker/backup/restore/2017/09/17/restore-mysql-database-using-docker.html)

Same commands:
[for MaryaDB](https://www.elliotjreed.com/backup-and-restore-mysql-mariadb-database-from-docker-container/)

## Import sql

You can import database afterwards:

docker exec -i mysql-container mysql -uuser -ppassword name_db < data.sql

ivan'@'%' IDENTIFIED BY 'test';

docker exec -i study mysql -uivan -ptest SalesOrdersModify < Sales.SQL

> no luck. ERROR 1049 (42000): Unknown database

suggestion: 
If dump file contains:
CREATE DATABASE mydatabasename;
USE mydatabasename; 
You may just use in CLI:
mysql -uroot –pmypassword < mydatabase.sql

docker exec -i study mysql -uivan -ptest < Sales.SQL

[!NOTE]
> Wow. My lucky day.
> rats !! need to import data too

docker exec -i study mysql -uivan -ptest < data.SQL

