# MySQL java



[8.1.2 Error Handling](https://dev.mysql.com/doc/x-devapi-userguide/en/error-handling.html)