# MySQL notes

[by digitalocean](https://www.digitalocean.com/community/tutorials/how-to-install-the-latest-mysql-on-ubuntu-16-04)

Default Ubuntu version is 5.7.23  
I need v.8 wit JSON type

So, let's go for it.  
Specific is that old MySql is working. let see if MySQL installer resolves it properly.

## I. Step 1 — Adding the MySQL Software Repository

1. Get link from NS repo:  
   https://dev.mysql.com/downloads/repo/apt/  
   https://dev.mysql.com/get/mysql-apt-config_0.8.10-1_all.deb
2. Download with curl:  
   curl -OL https://dev.mysql.com/get/mysql-apt-config_0.8.10-1_all.deb
3. install  
   sudo dpkg -i mysql-apt-config_0.8.10-1_all.deb
4. use 'Enter" to chose options from the installer

> actually it was just 'Step 1' that configure the repo. LOL !

## II. Step 2 — Installing MySQL

> not sugar for today.lol. not work as 5.7 is the best

sudo apt-get install mysql-server

> will try to update first. apt-get update && upgrade
> The following packages have been kept back: Distrib 5.7.23
> will try tu uninstall the old version first

old shit: well, but works.

> ok. not exactly, need to remove 'd'

- service mysqld status /sudo service mysql status
- sudo service mysqld stop
- sudo service mysqld start / sudo service mysql start

OK. Will try to reinstall.  
[Uninstall or Completely remove mysql from ubuntu 16-04](https://linuxscriptshub.com/uninstall-completely-remove-mysql-ubuntu-16-04/)

sudo apt-get remove --purge mysql*  
sudo apt-get purge mysql*  
sudo apt-get autoremove  
sudo apt-get autoclean  
sudo apt-get remove dbconfig-mysql  
sudo apt-get dist-upgrade

> good news, nothing happened. will reboot before starting it again
> sudo apt-get install mysql-server // as finall, i'll try to install 8 instead.

well, reboot & upgrade helped
msq from MsSQL Workbench: Incompatible/nonstandard server version or connection protocol detected (8.0.12).

[Stack suggestion](https://stackoverflow.com/questions/35376109/mysql-workbench-incompatible-nonstandard-server)

All you need to do is, after opening MySQL Workbench, and instead of setting up a new connection, Press CTRL+R or click on DATABASE tab in the top menu. Select Reverse Engineer and provide necessary information. You are good to go now.

The MySql workbench wont crash or show any compatibility issue now.

```mysql
service mysql stop
mysqld_safe --skip-grant-tables &
mysql -u root

mysql> use mysql;
mysql> update user set authentication_string=PASSWORD("YOUR-NEW-ROOT-PASSWORD") where User='root';
mysql> flush privileges;
mysql> quit

- sudo service mysql stop
- sudo service mysql start
$ mysql -u root -p
```

## bootstart

sudo systemctl enable mysql

> it's pretty annoying
> how could I remove it ?

sudo systemctl disable mysql

## new tricks for MySQL

[dig ocean](https://www.digitalocean.com/community/tutorials/how-to-install-mysql-on-ubuntu-18-04)

- systemctl status mysql.service
- connecting to the database using the mysqladmin tool, which is a client that lets you run administrative commands: 'sudo mysqladmin -p -u root version'
- adjusting User Authentication and Privileges

## MySQL Workbench

Bloody MySQL Workbench doesn't work. Uninstall completely and insytall v.8:

- sudo apt-get remove --auto-remove mysql-workbench
- curl -OL https://dev.mysql.com/get/Downloads/MySQLGUITools/mysql-workbench-community_8.0.12-1ubuntu18.04_amd64.deb
- sudo dpkg -i mysql-workbench-community_8.0.12-1ubuntu18.04_amd64.deb
- sudo apt-get install mysql-workbench

> i'm done with that bustard. need smth better.

## VSCode MySQL Management tool extension

it's pretty good, maybe not as polished as Workbench, but light and works.

## Dockerized MySQL

[!NOTE]

> MySQL 8 is very very heavy
> will try to use 5 & 8 on Docker

[How to deploy and use a MySQL Docker container](https://www.techrepublic.com/article/how-to-deploy-and-use-a-mysql-docker-container/)

[!NOTE]

> MySQL container has been installed and deployed

## MySQL shell installation

```bash
sudo dpkg -i mysql-shell_8.0.13-1ubuntu16.04_amd64.deb
sudo apt-get install -f
```

sudo apt-get install -f command tries to fix this broken package by installing the missing dependency.

to check
mysqlsh \?
