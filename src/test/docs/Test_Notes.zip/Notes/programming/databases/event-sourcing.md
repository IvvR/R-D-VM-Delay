
# Event sourcing

[Event Sourcing Basics](https://github.com/eventstore/eventstore/wiki/Event-Sourcing-Basics)

## Domain Event

An event is something that has happened in the past.

All events should be represented as verbs in the past tense such as CustomerRelocated, CargoShipped, or InventoryLossageRecorded.

# Events as a storage mechanism

structural vs transactional viewpoints

 