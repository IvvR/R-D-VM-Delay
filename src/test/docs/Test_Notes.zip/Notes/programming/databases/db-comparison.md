# DB comparison

## DB2 docker

https://hub.docker.com/r/ibmcom/db2express-c/

## Oracle docker

[oracle DB repo on git](https://github.com/oracle/docker-images/tree/master/OracleDatabase/SingleInstance)



[docker-oracle-xe-11g](https://github.com/wnameless/docker-oracle-xe-11g)

[Implement Oracle Database XE as Docker Containers](https://blogs.oracle.com/oraclewebcentersuite/implement-oracle-database-xe-as-docker-containers)


## JSON operations

[Jsonb: few more stories about the performance](http://erthalion.info/2017/12/21/advanced-json-benchmarks/)

