
# Database Primary key

[UUID or GUID as Primary Keys? Be Careful!](https://tomharrisonjr.com/uuid-or-guid-as-primary-keys-be-careful-7b2aa3dcb439)

takeaway:

- never expose PK. generate some additional  ID as UUID 
- use int ot bigint for autoincremented PK

Best of Both? Integers Internal, UUIDs External.

Internally, let the database manage data relationships with small, efficient, numeric sequential keys, whether int or bigint.

Then add a column populated with a UUID (perhaps as a trigger on insert). Within the scope of the database itself, relationships can be managed using the usual PKs and FKs.

But when a reference to the data needs to be exposed to the outside world, even when “outside” means another internal system, they must rely only on the UUID.

Use integers because they are efficient. Use the database implementation of UUIDs in addition for any external reference to obfuscate.

## MySQL UUID

[MySQL UUID Smackdown: UUID vs. INT for Primary Key](ttp://www.mysqltutorial.org/mysql-uuid/)

```sql
CREATE TABLE customers (
    id BINARY(16) PRIMARY KEY,
    name VARCHAR(255)
);

INSERT INTO customers(id, name)
VALUES(UUID_TO_BIN(UUID()),'John Doe'),
      (UUID_TO_BIN(UUID()),'Will Smith'),
      (UUID_TO_BIN(UUID()),'Mary Jane');

SELECT 
    BIN_TO_UUID(id) id, 
    name
FROM
    customers;   
```
