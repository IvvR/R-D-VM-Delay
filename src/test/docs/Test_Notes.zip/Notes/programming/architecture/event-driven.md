
# Event driven

An event can be defined as “a significant change in state.” For example, when a consumer purchases a car, the car’s state changes from “for sale” to “sold.” From a
formal perspective, what is produced, published, propagated, detected, or consumed is a (typically asynchronous) message called the event notification, and not the event itself, which is the state change that triggered the message emission. Events do not travel; they just occur.

