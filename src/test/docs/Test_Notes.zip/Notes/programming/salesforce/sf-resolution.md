# SF Resolution

CF platform is outdated and cannot be significantly improved.

The best way is to migrate to Amazon or Google clouds.
Heroku connectors could be used as a solution to coexist CF & something modern.

[!NOTE] Consulting service for migration
