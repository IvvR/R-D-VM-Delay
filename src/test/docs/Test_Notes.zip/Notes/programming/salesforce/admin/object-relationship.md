# Objects-relationship

[Object Relationships](https://trailhead.salesforce.com/content/learn/modules/data_modeling/object_relationships?trail_id=force_com_admin_beginner)

There are two main types of object relationships: lookup and master-detail.

## lookup


## master-detail

## Many to many

[Create a Many-to-Many Relationship](https://help.salesforce.com/articleView?id=relationships_manytomany.htm&type=5)

Creating the many-to-many relationship consists of:

- Creating the junction object.
- Creating the two master-detail relationships.
- Customizing the related lists on the page layouts of the two master objects.
- Customizing reports to maximize the effectiveness of the many-to-many relationship.

### Junction Object

A custom object with two master-detail relationships. Using a custom junction object, you can model a “many-to-many” relationship between two objects. For example, you create a custom object called “Bug” that relates to the standard case object such that a bug could be related to multiple cases and a case could also be related to multiple bugs.
