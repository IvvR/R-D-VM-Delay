# Tools installation

1. Create VSCode workspace. See 'VSCode Workspace notes'
2. Install 'Salesforce Extension pack'

rakin.i.v@brave-otter-1k8100.com
rakin.i.v@brave-otter-1k8100.com
brave-otter-1k8100-dev-ed.my.salesforce.com

## Schema builder

https://resourceful-shark-zefoy-dev-ed.lightning.force.com/lightning/setup/SchemaBuilder/home

