
# VSCode notes

What is 'a workspace' for VSCode and how to manage it.  
[VSCode Workspace notes](vscode-workspace-notes.md)

Python Anaconda interpretor
 
[from stackoverflow](https://stackoverflow.com/questions/43351596/activating-anaconda-environment-in-vscode)

The best option I found is to set the python.venvPath parameter in vscode settings to your anaconda envs folder.

"python.venvPath": "/Users/[...]/Anaconda3/envs"

Then if you bring up the command palette (ctl + shift + P on windows/linux, cmd + shift + P on mac) and type Python: Select Workspace Interpreter all your envs will show up and you can select which env to use. 

let's try  
"python.venvPath": "home/ivan/anaconda3/envs/py370env"  
the question is, "Where exactly in 'Workspace' 

ok. it helped:  
	"settings": {  
		"python.venvPath": "home/ivan/anaconda3/envs/py370env",  
		"python.pythonPath": "/home/ivan/anaconda3/envs/py370env/bin/python"  
	}  

probably, my string is useless. yeah !!! should be "/home...". lol.  
removed.  but it was not a bad idea )

ok. now launch.json  
[how it works from MS tutorial](https://code.visualstudio.com/docs/python/python-tutorial)

Select the settings icon on the debug toolbar (or use the Debug > Open configurations menu command):

The command opens a menu of available debuggers, which shows Python and Python Experimental. Select Python. The Python extension then creates a launch.json file that contains a number of configurations, which appear in the configurations drop-down:

