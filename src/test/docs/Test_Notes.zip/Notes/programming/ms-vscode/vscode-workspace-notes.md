
# VSCode Workspace notes

[from stackoverflow](https://stackoverflow.com/questions/44629890/what-is-the-definition-of-a-workspace-in-vs-code)

by Robert Schindehette:  
A workspace is just a text file with a (.code-workspace) extension. You can look at it by opening it with a text editor. I too was frustrated by the idea of a workspace and how it is implemented in VS Code. I found a method that suits me.

Start with a single "project" folder.

Open VSCode and close any open workspaces or files or folders. You should see only "OPEN EDITORS" and "NO FOLDER OPENED" in the EXPLORER. From the Menu Bar --> File --> Open Folder... Navigate to where you want to put your folder and right click to open a new folder. Name it whatever you want, then click on "Select Folder". It will appear in the VS Code EXPLORER.

Now from the Menu Bar --> File --> Save Workspace As... Name the workspace and save it wherever you want to keep all your workspace's, (not necessarily where your project folders are). I put all mine in a folder called "vscode-workspace".

It will be saved as a (.code-workspace) file and is just an index to all the files and folders it contains (or points to) wherever they may be on your hard drive. You can look at it by opening it with a text editor. Close the folder you created and close VS Code.

Now find your workspace "file" and double click on it. This will open VS Code with the folder you created in your workspace. Or you can open VS Code and use "Open Workspace".

Any folders you create from within your VS Code workspace will be inside your first folder. If you want to add any more top level folders, create them first wherever you want them and then use "Add To Workspace.." from VS Code.
