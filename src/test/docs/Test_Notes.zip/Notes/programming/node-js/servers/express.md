# Express

## Installation

- npm init
- npm install express@4.16.4
- npm install nodemon --save-dev
- nodemon server.js // doesn't work. see the note below

[!NOTE] add 'start' prop to a package.json file

```javascript
 "scripts": {
    "start": "nodemon server.js",
    "test": "echo \"Error: no test specified\" && exit 1"
  },
```

npm start
