
# Netty notes

[Netty](https://github.com/netty/netty)  

Netty is used in a vast amount of project and company and some of them are big, for example netty is used in “thrift” from facebook for process inter communication (remote procedure call) and for their mobile device data servicing.  
Twitter has spread netty all over their code.

[Armeria](https://github.com/line/armeria)  
Armeria is an open-source asynchronous RPC/API client/server library built on top of Java 8, Netty 4.1, HTTP/2, Thrift and gRPC. Its primary goal is to help engineers build high-performance asynchronous microservices that use HTTP/2 as a session layer protocol.

