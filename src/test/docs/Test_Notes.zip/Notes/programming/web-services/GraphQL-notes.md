
# GraphQL notes

[How to Build GraphQL Services in Java with Spring Boot](https://dev.to/sambenskin/howto-build-graphql-services-in-java-with-spring-boot---part-1-38b2)  
I've seen so many APIs that returned huge amounts of data when all the user needed was a set of identifiers to loop through and query a second endpoint for some other data related to those identifiers, which highlights the second issue.

two big reasons  to   switch:

- the ability to easily include in your request the structure of the data you want to receive
- the ability to combine what would have been multiple REST requests into a single GraphQL query

Both are huge improvements over REST. Sure, you could try and write your REST endpoints this way, but then they really wouldn't be REST anymore and GraphQL is built to work this way.