
# JAX-RS notes

[7 Reasons I Do Not Use JAX-RS](https://dzone.com/articles/7-reasons-i-do-not-use-jax-rs-in-spring-boot-web-a)  

I've even created some custom in-house JAX-RS add-ons  
Spring MVC is just easier to work with than JAX-RS.  

- I suggest we go with RESTEasy."
- "RESTEasy's latest stable release only supports JAX-RS 2.0. 

Spring MVC uses nomenclature from the MVC pattern, instead (not surprisingly). This means I am free to implement more of a JSON RPC-style API without hypermedia links in my JSON responses if I so choose and Spring MVC will not judge me.

Apart from the customizable banners and aforementioned spring-boot-dependencies POM, another great Spring Boot feature is the Actuator. By merely adding the actuator starter dependency to my POM, my application gains a number of useful monitoring and informational production-ready endpoints...except if I'm using JAX-RS.

[Creating a RESTful web service](https://openliberty.io/guides/rest-intro.html)  
JAX-RS has two key concepts for creating REST APIs.  

- The most obvious is the resource itself, which is modelled as a class. 
- The second is a JAX-RS application, which groups all exposed resources under a common path.  

You can think of the JAX-RS application as a wrapper for all your resources. Having a single JAX-RS application is common, although multiple are possible.

We're going to build a simple barebones GraphQL API in Java using Spring Boot.
