# HTTP API notes

REST , XML-RPC, SOAP and JSON-RPC, GraphQL

[Understanding RPC Vs REST For HTTP APIs](https://www.smashingmagazine.com/2016/09/understanding-rest-and-rpc-for-http-apis/)

## REST

REST is all about a client-server relationship, where server-side data are made available through representations of data in simple formats, often JSON and XML. These representations for resources, or collections of resources, which are then potentially modifiable, with actions and relationships being made discoverable via a method known as hypermedia. Hypermedia is fundamental to REST, and is essentially just the concept of providing links to other resources.

! so it's all about data, not action like calculation, or SLACK. 
but SLACK conversation history, isn't it REST ? !

Beyond hypermedia there are a few other constraints, such as:

- REST must be stateless: not persisting sessions between requests.
- Responses should declare cacheablility: helps your API scale if clients respect the rules.
- REST focuses on uniformity: if you’re using HTTP you should utilize HTTP features whenever possible, instead of inventing conventions.

! looks like I've got it ! LOL  - not so fast. See next !!

 Triggering actions can be done with either approach; but, in REST, that trigger can be thought of more like an aftereffect. For example, if you want to “Send a message” to a user, RPC would be this:

POST /users/501/messages HTTP/1.1
Host: api.example.com
Content-Type: application/json

{"message": "Hello!"}

REST is not only CRUD, but things are done through mainly CRUD-based operations. REST will use HTTP methods such as GET, POST, PUT, DELETE, OPTIONS and, hopefully, PATCH to provide semantic meaning for the intention of the action being taken.

REST. We are creating a message resource in the user’s messages collection. We can see a history of these easily by doing a GET on the same URL, and the message will be sent in the background.

In a REST API, you already have GET /trips and POST /trips, so a lot of people would try to use endpoints that look a bit like sub-resources for these actions:

- POST /trips/123/start
- POST /trips/123/finish
- POST /trips/123/cancel

This is basically jamming RPC-style endpoints into a REST API, which is certainly a popular solution but is technically not REST. This crossover is a sign of how hard it can be to put actions into REST. 

## “RPC” - “remote procedure call”  

it’s essentially the same as calling a function in JavaScript, PHP, Python and so on, taking a method name and arguments.

[JSON-RPC 2.0 Specification](https://www.jsonrpc.org/specification)

RPC-based APIs are great for actions (that is, procedures or commands).

The biggest difference in my opinion is in how actions are handled. In RPC, you just have POST /doWhateverThingNow, and that’s rather clear. 

RPC. We are sending a message, and that might end up storing something in the database to keep a history, which might be another RPC call with possibly the same field names — who knows?

if you want to “Send a message” to a user, RPC would be this:

POST /SendUserMessage HTTP/1.1
Host: api.example.com
Content-Type: application/json

{"userId": 501, "message": "Hello!"}

An RPC API might be a great alternative, or it could be a new service to complement an existing REST API. Slack uses an RPC-based Web API, because what it’s working on just would not fit into REST nicely. Imagine trying to offer “kick,” “ban” or “leave” options for users to leave or be removed from a single channel or from the whole Slack team.

[Creating a RESTful web service](https://openliberty.io/guides/rest-intro.html)  
When you create a new REST application the design of the API is important. The JAX-RS APIs could be used to create JSON-RPC, or XML-RPC APIs, but wouldn’t be a RESTful service. A good RESTful service is designed around the resources that are exposed, and how to create, read, update, and delete the resources.

## Rule of thumb  

One simple rule of thumb is this:

- If an API is mostly actions, maybe it should be RPC.
- If an API is mostly CRUD and is manipulating related data, maybe it should be REST.

# Use Both REST And RPC

An application could very easily have multiple APIs or additional services that are not considered the “main” API. With any API or service that exposes HTTP endpoints, you have the choice between following the rules of REST or RPC, and maybe you would have one REST API and a few RPC services.  

[Is it time to replace REST with RPC?](https://medium.com/@tlhunter/is-it-time-to-replace-rest-with-rpc-1304379456a2)

READ/ UPDATE/ DELETE  
/employers/{employerId}  
employees/{employeeId}  
for representation of parent/child relationships  
 READ/ UPDATE/ DELETE  
 /employers/{employerId}/employees/{employeeId}

> [!NOTE]
> Mail example is good !

How do we RESTfully represent sending an email to a user? 

> [!NOTE]
> I would try to model mail process as FSM - final state machine
> create mail, update mail, delete mail, forward mail

> distribute by other means - different ways

