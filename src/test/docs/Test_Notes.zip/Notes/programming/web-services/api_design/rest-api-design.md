# REST API Design

REST API Design Rulebook.
Mark Massé, 2012

## Identifier Design with URIs

URI = scheme "://" authority "/" path [ "?" query ][ "#" fragment ]

repository_search_url  
"https://api.github.com/search/repositories?q={query}{&page,per_page,sort,order}"

code_search_url  
"https://api.github.com/search/code?q={query}{&page,per_page,sort,order}"

commit_search_url  
"https://api.github.com/search/commits?q={query}{&page,per_page,sort,order}"

organization_repositories_url  
"https://api.github.com/orgs/{org}/repos{?type,page,per_page,sort}"

## Resource Modeling

The URI path conveys a REST API’s resource model, with each forward slash separated path segment corresponding to a unique resource within the model’s hierarchy.

For example, this URI design:

http://api.soccer.restapi.org/leagues/seattle/teams/trebuchet

indicates that each of these URIs should also identify an addressable resource:

- http://api.soccer.restapi.org/leagues/seattle/teams
- http://api.soccer.restapi.org/leagues/seattle
- http://api.soccer.restapi.org/leagues
- http://api.soccer.restapi.org

Resource modeling is an exercise that establishes your API’s key concepts. This process
is similar to the data modeling for a relational database schema or the classical modeling
of an object-oriented system.

### Variable path segments may be substituted with identity-based values

Some URI path segments are static; meaning they have fixed names that may be chosen
by the REST API’s designer. Other URI path segments are variable, which means that
they are automatically filled in with some identifier that may help provide the URI with
its uniqueness. The URI Template syntax ‡ allows designers to clearly name both the
static and variable segments.

[URI Template. IETF. Internet Standards Track document](https://tools.ietf.org/html/rfc6570)

## Mapping API calls

Book: Flask. Building Python Web Services.
Chapter 7.

Mapping API calls to the resource segregation:

- GET /products/1 : This gets the product with ID 1
- GET /products : This gets the list of products
- POST /products : This creates a new product
- PUT /products/1 : This updates the product with ID 1
- PATCH /products/1 : This partially updates the product with ID 1
- DELETE /products/1 : This deletes the product with ID 1
