# Endpoints

Build APIs You Won’t Hate. Phil Sturgeon

An endpoint is simply a URL. When you go to http://example.com/foo/bar that is an endpoint and
you can simply call it /foo/bar because the domain will be the same for all of them.

## Planning endpoints

Try thinking of everything your API will need to handle. This will initially be a list of CRUD (create, read, update, delete) endpoints for your resources.

When you have a relatively extensive list the next step is to make a simple list of “actions”. You first write up pseudo-code referencing the classes and methods like they exist, right? TDD (Test Driven Development)?

Example - Check-in app: Places

- Create
- Read
- Update
- Delete
- List (lat, lon, distance or box)

The API will need to offer the ability to search places by location too, but that is not a brand new endpoint. Just remember that not every single action requires its own endpoint.

[Campaigns & Opportunities](https://powerofus.force.com/articles/Best_Practice_Business_Process/What-are-Campaigns-and-How-Do-They-Work)

[Lead & Opportunity](https://www.apptivo.com/blog/difference-between-leads-opportunities/)

### Endpoint Theory

Turning this action plan into actual endpoints requires knowing a little theory on RESTful APIs and best practices for naming conventions.

GET Resources:

- GET /resources - Some paginated list of stuff, in some logical default order, for that specific data.
- GET /resources/X - Just entity X. That can be an ID, hash, slug, username, etc., as long as it’s unique to one “resource”.
- GET /resources/X,Y,Z - The client wants multiple things, so give them multiple things.

It can be hard to pick between subresource URLs or embedded data. Embedded data can be rather difficult to pull off.

This is how subresources look:

- GET /places/X/checkins - Find all the checkins for a specific place.
- GET /users/X/checkins - Find all the checkins for a specific user.
- GET /users/X/checkins/Y - Find a specific checkin for a specific user.

The latter is questionable and not something I have ever personally done. At that point, I would prefer to simply use /checkins/X.

[!NOTE] definition
> Idempotent is a fancy word for “can do it over and over again without causing different 
> results”.

## Endpoint Testing

With an API, there are a few things to test, but the most basic idea is, “when I request this URL, I want to see a foo resource”, and “when I throw this JSON at the API, it should 

- a) accept it or
- b) freak out.”

if you have over 50 endpoints and want to do multiple checks per endpoint, you end up with a mess of code which can become hard to maintain. The more code you have in your tests, the higher the chances of your tests being rubbish, which means you won’t run them.

