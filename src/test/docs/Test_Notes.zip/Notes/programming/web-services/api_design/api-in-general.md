# API

Building Enterprise JavaScript Applications.
Daniel Li, 2018


## Designing our API

But to have a "good" API, this contract must also be consistent, intuitive, and simple.

### Consistency

The four levels of consistency in API design:

- Common: Being consistent with the world
- Local: Being consistent within the same API
- Transversal: Being consistent across different APIs by the same organization
- Domain: Being consistent with a specific domain
- perennial consistency—or being consistency across time

### Naming convention

- Use kebab-case for URLs
- Use camelCase for parameters in the query string, for example, /users/12?fields=name,coverImage,avatar
- For nested resources, structure them like so: /resource/id/sub-resource/id, for example, /users/21/article/583

For our non-CRUD endpoints, the URL naming convention should follow a /verb-noun structure: we should use /search-articles instead of /articles-search.

## Documenting Our API

While our test suite is the most accurate and best form of documentation, providers of all major APIs also maintain browser-based API documentation for the following reasons:

- It may require a lot of time and effort to understand the test suite.
- Not all APIs are open-sourced, so developers may not always have access to the tests.
- Tests lack context—you know how to call an endpoint, but you will have to figure out for yourself how it fits into the workflow of an application.
- It is language- and framework-specific—the browser-based documentation describes the interface of the API, not the implementation.

## POST vs PUT

[So, which one should be used to create a resource? Or one needs to support both?](https://stackoverflow.com/questions/630453/put-vs-post-in-rest)

Both PUT and POST can be used for creating. 

PUT is idempotent, so if you PUT an object twice, it has no effect. This is a nice property, so I would use PUT when possible.

[!NOTE] As persistent object id is unknown before creating a record in a database it would be
> a violation od the idempotent rule

By this argument, PUT is for creating when you know the URL of the thing you will create. POST can be used to create when you know the URL of the "factory" or manager for the category of things you want to create.

```http
POST /expense-report
PUT  /expense-report/10929
```


better use POST with the mapping

[Building REST services with Spring](https://spring.io/guides/tutorials/bookmarks/)

```java
@PostMapping("/employees")
	Employee newEmployee(@RequestBody Employee newEmployee) {
		return repository.save(newEmployee);
```
