# PHP FPM

The PHP Fast Process Manager is a FastCGI handler for PHP scripts and applications. It’s commonly paired with web servers to serve applications which require a PHP framework, such as web forums or login gateways, while the web server returns HTML, JavaScript, and other non-PHP content.

[Serve PHP with PHP-FPM and NGINX](https://www.linode.com/docs/web-servers/nginx/serve-php-php-fpm-and-nginx/)

- systemctl status php7.3-fpm.service
- sudo systemctl restart nginx.service
- sudo systemctl restart php7.3-fpm

sudo apt-get install php-xdebug

## Nginx + fpm

[!NOTE] it looks like working article. it works indeed

new one:
(http://geekyplatypus.com/making-your-dockerised-php-application-even-better/)

good old:
http://geekyplatypus.com/dockerise-your-php-application-with-nginx-and-php7-fpm/

192.168.48.3 - 21/Feb/2019:11:35:38 +0000 "GET /index.php" 404
