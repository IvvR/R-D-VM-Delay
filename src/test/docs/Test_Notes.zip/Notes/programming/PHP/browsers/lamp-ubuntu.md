# LAMP-UBUNTU

1. install apache2
   sudo apt install apache2
2. Checking your Web Server
   sudo systemctl status apache2

3. Instal php 7 to ubuntu
   [!NOTE] The default PHP version for Ubuntu 16.04 is 7.0.
   sudo apt-get install php

4. Restart apache
   sudo /etc/init.d/apache2 restart

5. Test PHP io

   - sudo nano /var/www/html/test.php
   - <?php echo 'Images Storeront'; ?>

6. PHP engine doesn't run

   - sudo apt-get install apache2 php7.0 libapache2-mod-php7.0
   - [!NOTE] done

7. Install mysql server

   - sudo apt-get install mysql-server
   - sudo systemctl status mysql
   - mysql -u root -p
   - mysqladmin -u root password front
   - [!NOTE] error: 'Access denied for user 'root'@'localhost' (using password: NO)'
   - sudo service mysql stop
   - mkdir -p /var/run/mysqld
   - chown mysql:mysql /var/run/mysqld
   - mysqld_safe --skip-grant-tables &
   - SET PASSWORD FOR root@'localhost' = PASSWORD('front');
   - mysql -u root -p
   - [!NOTE] done

8. create template database

   - create database template; // mysql shell
   - -CTRL + D

9. install php-admin

   - sudo apt-get install phpmyadmin

10. uncomment extension

    - sudo nano /etc/php/7.0/apache2/php.ini
    - or // sudo gedit /etc/php/7.0/apache2/php.ini
    - extension=msql.so
    - sudo nano /etc/apache2/apache2.conf
    - add the line to the end of the file: Include /etc/phpmyadmin/apache.conf
    - sudo /etc/init.d/apache2 restart
    - [!NOTE] done

    uncomment controluser : [!NOTE] useless

    - sudo nano /etc/phpmyadmin/config.inc.php
    - \$cfg['Servers'][1]['pmadb'] = 'phpmyadmin';
    - \$cfg['Servers'][1]['controluser'] = 'pma';
    - \$cfg['Servers'][1]['controlpass'] = 'pmapass';

11. Apache virtual host configuration

    - mkdir template
    - sudo nano /etc/apache2/sites-available/000-default.conf
    - add the following config

    ```xml
    <VirtualHost *:80>
        # other VirtualHost directives

        Alias /template /home/ivan/projects/PHP/template
        <Directory /home/ivan/projects/PHP/template>
            Require all granted
        </Directory>
    </VirtualHost>
    ```

    - sudo systemctl restart apache2.service
    - create test.php in the VS Code and run it
    - [!NOTE] done

sudo nano /etc/apache2/conf-available/templateAlias.conf
sudo a2enmod rewrite && sudo service apache2 restart

```xml
<VirtualHost *:80>
#        ServerAdmin admin@front.com
        ServerName front.com
#        ServerAlias www.front.com

        DocumentRoot  /home/ivan/projects/PHP/template/public
#        ErrorLog ${APACHE_LOG_DIR}/error.log
#        CustomLog ${APACHE_LOG_DIR}/access.log combined

        <Directory /home/ivan/projects/PHP/template/public>
#           AllowOverride All
           AllowOverride all
           Require all granted
        </Directory>

         ErrorLog ${APACHE_LOG_DIR}/template-error.log

</VirtualHost>
```

12. API routing tune for Apache server

- sudo a2enconf templateAlias && sudo systemctl restart apache2.service
- http://localhost/api/template/index.php/api/template/123
- sudo nano /etc/hosts

13. www-data permission for writing/reading to the folder

- ls -ld log
- sudo chgrp www-data /home/ivan/projects/PHP/template/public/log
- sudo chmod g+rwxs /home/ivan/projects/PHP/template/public/log

- mkdir image
- ls -ld image
- sudo chgrp www-data /home/ivan/projects/PHP/template/public/image
- sudo chmod g+rwxs /home/ivan/projects/PHP/template/public/image

[!NOTE] done

INSERT INTO image (name, template_id) VALUES ("some.img", 9)

14, swithing php runtime

- sudo a2dismod php7.0
- sudo a2enmod php7.2

15 php 7.2 upgrade

[!NOTE] 500. internal server

- sudo apt-get install php-mysql
- sudo systemctl restart apache2.service

- sudo update-alternatives --set php /usr/bin/php7.2
- sudo update-alternatives --set phar /usr/bin/phar7.2
- sudo update-alternatives --set phar.phar /usr/bin/phar.phar7.2

- sudo apt install php7.2-dev
- sudo update-alternatives --set phpize /usr/bin/phpize7.2
- sudo update-alternatives --set php-config /usr/bin/php-config7.2

sudo apt install mysql-server php7.2-mysql

sudo gedit /etc/php/7.2/apache2/php.ini
uncomment: extension=mysqli

- sudo systemctl restart mysql.service
- sudo systemctl restart apache2.service

[!NOTE] FTF ???!!!:

> /etc/php/7.0/mod-available/ has got mysqli.ini, mysqlnd.ini
> /etc/php/7.2/mod-available/ has also got mysqli.ini, mysqlnd.ini

ok . next try
sudo apt-get install php7.3-mysql

sudo apt install php7.3-mysql

sudo update-alternatives --set php /usr/bin/php7.3
sudo update-alternatives --set phar /usr/bin/phar7.3
sudo update-alternatives --set phar.phar /usr/bin/phar.phar7.3
sudo update-alternatives --set phpize /usr/bin/phpize7.3
sudo update-alternatives --set php-config /usr/bin/php-config7.3

- sudo a2dismod php7.2
- sudo a2enmod php7.3

WTF ?! ERROR: Module php7.3 does not exist!

https://thishosting.rocks/install-php-on-ubuntu/

- sudo apt-get install libapache2-mod-php7.3

## Get rid of ppa

https://serverfault.com/questions/776173/white-screen-php-7-on-ubuntu-16-04-fails-to-render-scripts

Get rid of this, get rid of the ppa, and use the officially supported php 7.0 from the Ubuntu Main respository.

sudo add-apt-repository --remove ppa:ondrej/php

sudo rm -r /etc/apache2/
sudo rm /usr/sbin/apache2
sudo rm -r /usr/lib/apache2
sudo rm /usr/
// sudo rm /usr/share/man/man8/apache2.8.gz

sudo apt-get install apache2
