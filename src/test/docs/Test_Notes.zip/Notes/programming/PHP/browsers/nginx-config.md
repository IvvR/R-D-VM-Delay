# Nginx configuration

pwd - show full path

## Nginx installation

[How To Install Linux, Nginx, MySQL, PHP (LEMP stack) in Ubuntu 16.04 ](https://www.digitalocean.com/community/tutorials/how-to-install-linux-nginx-mysql-php-lemp-stack-in-ubuntu-16-04)

sudo apt-get update
sudo apt-get install nginx

looks like it has a conflict with apache

- sudo /etc/init.d/apache2 stop
- systemctl list-units --type service // To find out all services that have been run at startup

systemctl is-active apache2
sudo systemctl disable apache2

systemctl is-active vboxdrv.service
sudo systemctl disable vboxautostart-service

--
sudo service nginx start
systemctl is-active nginx
sudo systemctl enable nginx
--
service nginx stop
systemctl stop nginx

---

[!NOTE] funny. rename index.html at /var/www/html
To fix it, you can edit or remove the default site... Or alter the files in /var/www/ to better suit your needs. If you want rid of the default, you can delete /etc/nginx/sites-available/default. It's just a symlink so if you want to restore it, you can with:

https://askubuntu.com/questions/642238/why-do-i-still-see-an-apache-site-on-nginx

### create virtual host

sudo nano /etc/nginx/sites-available/default

sudo gedit /etc/nginx/sites-available/default

```bash virtual server
server {
	listen 8080;
	listen [::]:8080;

	server_name storm-app;

	root /home/ivan/projects/PHP/storm-app;
	index index.php index.html;

 	location / {
 		try_files $uri $uri/ =404;
 	}
 }
```

Test your configuration file for syntax errors by typing:

- sudo nginx -t
- sudo systemctl reload nginx

  [!NOTE] done. www-data needs access to the dir

- chmod -R 755 /home/ivan/projects/PHP/storm-app // probably doesn't work
- sudo chgrp www-data /home/ivan/projects/PHP/storm-app
- sudo chmod g+rwxs /home/ivan/projects/PHP/storm-app
- nginx -s reload

- sudo chgrp www-data /var/log/nginx/error.log
- sudo chmod g+rwxs /var/log/nginx/error.log
- nginx -s reload

- I ran into this exact problem, which had me stumped for a while. The problem is that nginx needs to execute as root and let the user directive in the /etc/nginx/nginx.conf handle running everything as the correct user. For me, I had the sytemd job defining the user to run nginx as.

### new way

https://www.techrepublic.com/article/how-to-add-virtual-hosts-to-nginx/

with new file:storm-app

- sudo touch /etc/nginx/sites-available/storm-app
- sudo gedit /etc/nginx/sites-available/storm-app
- add virtual host config to 'storm-app' file

sudo ln -s /etc/nginx/sites-available/storm-app /etc/nginx/sites-enabled/storm-app

### new way 2.. it works

https://www.techrepublic.com/article/how-to-add-virtual-hosts-to-nginx/

#### Step 1

sudo mkdir /var/www/testing

#### Step 2

Next, change the ownership to the new folder with the command
sudo chown -R www-data:www-data /var/www/testing

We'll change the permissions of the folder with the command
sudo chmod 755 /var/www/testing

#### Step 2

- sudo touch /var/www/testing/index.html
- sudo gedit /var/www/testing/index.htm
- sudo nano /var/www/testing/index.htm

#### Step 3

Now we must create the virtual host file. NGINX makes this easy (as it copies a bit from Apache2). Issue the command

- sudo touch /etc/nginx/sites-available/testing
- sudo gedit /etc/nginx/sites-available/testing

and then add the following contents to that file.

#### Step 4

You must create a symbolic link from sites-available to sites-enabled with the command

- sudo ln -s /etc/nginx/sites-available/testing /etc/nginx/sites-enabled/testing.

Restart NGINX with the command

- sudo nginx -t
- sudo service nginx restart.

#### Step 5

- sudo nano /etc/hosts
- sudo /etc/init.d/networking restart
-

## Splain

- mkdir splain
- /home/ivan/projects/PHP/splain

- sudo chown -R www-data:www-data /home/ivan/projects/PHP/splain
- sudo chmod 755 /home/ivan/projects/PHP/splain

[!NOTE] check as an aternative to chown

- sudo chgrp www-data /home/ivan/projects/PHP/template/public/image
- sudo chmod g+rwxs /home/ivan/projects/PHP/template/public/image

- touch /home/ivan/projects/PHP/splain/index.html
  [!NOTE] permission deny
- sudo touch /home/ivan/projects/PHP/splain/index.html
- sudo gedit /home/ivan/projects/PHP/splain/index.html
- sudo nano /home/ivan/projects/PHP/splain/index.html

getent group www-data
ls -l

- sudo touch /etc/nginx/sites-available/splain
- sudo gedit /etc/nginx/sites-available/splain

- sudo ln -s /etc/nginx/sites-available/splain /etc/nginx/sites-enabled/splain
- sudo nginx -t
- sudo service nginx restart

- sudo nano /etc/hosts
- sudo /etc/init.d/networking restart

[!NOTE] no sugar
regain ownership
sudo chown -R ivan:ivan /home/ivan/projects/PHP/splain
sudo chmod 755 /home/ivan/projects/PHP/splain

- sudo chgrp www-data /home/ivan/projects/PHP/splain
- sudo chmod g+rwxs /home/ivan/projects/PHP/splain

[!NOTE] OK. I'll return to nginx later.
Shutdown it

systemctl is-active nginx
systemctl is-active php7.0-fpm
sudo service nginx stop
sudo service php7.0-fpm stop
sudo systemctl disable nginx
sudo systemctl disable php7.0-fpm
[!NOTE] done

- sudo /etc/init.d/apache2 stop
- systemctl list-units --type service // To find out all services that have been run at startup

systemctl is-active apache2
sudo service apache2 start
sudo systemctl enable apache2

## Linux opened ports

netstat -vatn
lsof -i

[!NOTE] what's funny, 9000 is opened but not 9000 as
