# NGINX config

[!NOTE] worked with php 7.0 but mnt wit 7.3

[Getting Started with NGINX](https://www.linode.com/docs/web-servers/nginx/nginx-installation-and-basic-setup/)

However, many guides and blog posts for NGINX recommend this same configuration. As you could expect, this has led to some confusion, and the assumption that NGINX regularly uses the ../sites-available/ and ../sites-enabled/ directories, and the www-data user. It does not.

Do not force Apache configurations onto NGINX.

Instead, multiple site configuration files should be stored in /etc/nginx/conf.d/ as example.com.conf, or example.com.disabled. Do not add server blocks directly to /etc/nginx/nginx.conf either, even if your configuration is relatively simple. This file is for configuring the server process, not individual websites.

## reserve the default nginx.conf

sudo cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.backup-original

sudo gedit /etc/nginx/nginx.conf

Fix the previous unsuccessful attempt

- sudo mv /etc/nginx/sites-available/splain /etc/nginx/conf.d
- sudo rm /etc/nginx/sites-enabled/splain
- sudo nginx -t
- nginx -s reload

- sudo gedit /etc/nginx/conf.d/splain

[!NOTE] OMG ! Done

sudo systemctl enable nginx

sudo cp /etc/nginx/conf.d/splain /etc/nginx/sites-available/splain
sudo cp /etc/nginx/conf.d/splain /etc/nginx/sites-enabled/splain

sudo mv /etc/nginx/sites-available/splain /home/ivan/TMP/3/
sudo mv /etc/nginx/sites-enabled/splain /home/ivan/TMP/3/
sudo mv /etc/nginx/conf.d/splain /etc/nginx/sites-available/

sudo cp /etc/nginx/sites-available/splain /etc/nginx/sites-enabled/

sudo gedit /etc/nginx/sites-available/splain

sudo chown -R ivan:ivan /home/ivan/projects/PHP/splain
sudo chmod 755 /home/ivan/projects/PHP/splain

- sudo chgrp www-data /home/ivan/projects/PHP/splain
- sudo chmod g+rwxs /home/ivan/projects/PHP/splain

sudo chown -R www-data:www-data /home/ivan/projects/PHP/splain
sudo chmod 755 /home/ivan/projects/PHP/splain

sudo systemctl start php-fpm

systemctl is-active php7.3-fpm
sudo service php7.3-fpm stop
sudo systemctl disable php7.3-fpm

$ sudo service php7.0-fpm restart # <- restart it
$ sudo service php7.0-fpm reload # <- reload it

sudo systemctl restart php7.0-fpm.service

## Working confiog

[!NOTE] DONE !!!

The most important string is

- fastcgi_pass unix:/var/run/php/php7.0-fpm.sock;

[Setup Nginx Web Servers with PHP Support on Ubuntu Servers](https://websiteforstudents.com/setup-nginx-web-servers-with-php-support-on-ubuntu-servers/)

```bash
server {
    listen 80;
    listen [::]:80;
    root /var/www/html;
    index  index.php index.html index.htm;
    server_name  example.com www.example.com;

    location / {
        try_files $uri $uri/ =404;
    }


     # pass PHP scripts to FastCGI server
        #
        location ~ \.php$ {
               include snippets/fastcgi-php.conf;
        #
        #       # With php-fpm (or other unix sockets):
               fastcgi_pass unix:/var/run/php/php7.0-fpm.sock;
        #       # With php-cgi (or other tcp sockets):
        #       fastcgi_pass 127.0.0.1:9000;
        }
}
```

### Nginx block config

[!NOTE] OK.Welcome back. lol.

sudo cp /home/ivan/TMP/3/splain /etc/nginx/conf.d/

sudo nginx -t
sudo service nginx restart
sudo systemctl restart php7.0-fpm.service

sudo gedit /etc/nginx/conf.d/testing.conf
[!NOTE] works

### ownership woodo

sudo rm /etc/nginx/conf.d/splain
sudo cp /home/ivan/TMP/3/splain.conf /etc/nginx/conf.d/

sudo gedit /etc/nginx/conf.d/splain.conf

- sudo chown -R www-data:www-data /home/ivan/projects/PHP/splain
- sudo chmod 755 /home/ivan/projects/PHP/splain
  [!NOTE] Works with www-data:www-data, but not with php

sudo cp /home/ivan/projects/PHP/template/public/test.php /home/ivan/projects/PHP/splain/
sudo cp /home/ivan/projects/PHP/template/public/test.php /var/www/testing/

[!NOTE] php support

sudo gedit /etc/nginx/conf.d/splain.conf

```bush
     # pass PHP scripts to FastCGI server
        #
        location ~ \.php$ {
               include snippets/fastcgi-php.conf;
               fastcgi_pass unix:/var/run/php/php7.0-fpm.sock;

        }

        #  to suppress annoying log entries
	location = /favicon.ico {
  		log_not_found off;
	}
```

- sudo nginx -t
- sudo service nginx restart
- sudo systemctl restart php7.0-fpm.service

#### get ownership back

- sudo chown -R ivan:ivan /home/ivan/projects/PHP/splain
- sudo chmod 755 /home/ivan/projects/PHP/splain

[!NOTE] nginx still works.

> restart services
> ls -l
> Sheere miracle
