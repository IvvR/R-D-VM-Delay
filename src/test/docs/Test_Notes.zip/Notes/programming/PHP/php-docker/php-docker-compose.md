# PHP Docker

[The ups and downs of docker-compose — how to run multi-container applications](https://medium.freecodecamp.org/the-ups-and-downs-of-docker-compose-how-to-run-multi-container-applications-bf7a8e33017e)

Defining your applications in a docker-compose.yml and running them with the up and down commands gives you control over multi-container applications.

- docker-compose up to create and start a container. In “detached” mode ( -d ), Compose exits after starting the containers, but the containers continue to run in the background. docker-compose up -d rabbit-mq
- docker-compose down — Stop and remove containers, networks, images, and volumes, eg docker-compose down -v.
  - -v, --volumes. Remove named volumes declared in the `volumes` section of the Compose file and anonymous volumes attached to containers.
  - --remove-orphans. Remove containers for services not defined in the Compose file

[How to Use Docker Compose](https://www.linode.com/docs/applications/containers/how-to-use-docker-compose/)

clean-up containers /images

- docker ps -a
- docker images -a
- docker update --restart=no 69d99b056de8
- docker rm 69d99b056de8 // remove container with id
- docker image rmi 6bb891430fb6 // remove image with id

## YML

use SF yaml as a base

## REmote Debug wit VSCode

it is possible to use different yml configs

- docker-compose -f docker-compose-xdebug.yml up
