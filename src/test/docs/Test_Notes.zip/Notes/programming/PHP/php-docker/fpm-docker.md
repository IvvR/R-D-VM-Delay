# FPM- docker

[PHP-FPM Docker Image](https://github.com/nanoninja/php-fpm)

- sudo docker pull nanoninja/php-fpm

sudo docker run -it --name phpfpm -v /path/to/your/app:/var/www/html nanoninja/php-fpm php index.php

## log in to the system

- docker exec -it php bash
