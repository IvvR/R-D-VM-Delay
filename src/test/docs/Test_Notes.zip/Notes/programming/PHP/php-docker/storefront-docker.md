# Store Docker

## Build & Run

1. go to the folder with a Dockerfile
2. docker-compose up

## Define services in a Compose file

[Get started with Docker Compose](https://docs.docker.com/compose/gettingstarted/)

Two services have defined

```yml
version: '3'
services:
  web:
    build: .
    ports:
      - '5000:5000'
  redis:
    image: 'redis:alpine'
```

## Error log

mysql | 2019-02-08T13:16:55.243924Z 1 [Warning] 'tables_priv' entry 'sys_config mysql.sys@localhost' ignored in --skip-name-resolve mode.
node |
node | > template-test@0.0.1 test /home/node/app
node | > node template-test.js
node |
php | 172.18.0.5 - template@storefront.com 08/Feb/2019:13:16:55 +0000 "POST /index.php" 404
web | 2019/02/08 13:16:55 [error] 6#6: \*1 FastCGI sent in stderr: "Primary script unknown" while reading response header from upstream, client: 172.18.0.6, server: localhost, request: "POST /api/template HTTP/1.1", upstream: "fastcgi://172.18.0.2:9000", host: "web"
node | undefined:1
node | File not found.
node | ^
node |
node | SyntaxError: Unexpected token F in JSON at position 0
node | at JSON.parse (<anonymous>)
node | at Request.request.post [as \_callback](/home/node/app/template-test.js:46:26)
node | at Request.self.callback (/home/node/app/node_modules/request/request.js:185:22)
node | at emitTwo (events.js:126:13)
node | at Request.emit (events.js:214:7)
node | at Request.<anonymous> (/home/node/app/node_modules/request/request.js:1161:10)
node | at emitOne (events.js:116:13)
node | at Request.emit (events.js:211:7)
node | at IncomingMessage.<anonymous> (/home/node/app/node_modules/request/request.js:1083:12)
node | at Object.onceWrapper (events.js:313:30)
web | 172.18.0.6 - template@storefront.com [08/Feb/2019:13:16:55 +0000] "POST /api/template HTTP/1.1" 404 27 "-" "-"
node | npm ERR! code ELIFECYCLE
node | npm ERR! errno 1
node | npm ERR! template-test@0.0.1 test: `node template-test.js`
node | npm ERR! Exit status 1
node | npm ERR!
node | npm ERR! Failed at the template-test@0.0.1 test script.
node | npm ERR! This is probably not a problem with npm. There is likely additional logging output above.
node |
node | npm ERR! A complete log of this run can be found in:
node | npm ERR! /root/.npm/\_logs/2019-02-08T13_16_55_951Z-debug.log
node exited with code 1
