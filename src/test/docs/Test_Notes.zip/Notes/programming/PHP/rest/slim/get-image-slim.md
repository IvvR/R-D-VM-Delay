# Upload image with Slim

[Uploading files using POST forms](http://www.slimframework.com/docs/v3/cookbook/uploading-files.html)

[PSR-7 file uploads in Slim 3](https://akrabat.com/psr-7-file-uploads-in-slim-3/)

```php
$app->post('/upload', function ($request, $response, $args) {
    $files = $request->getUploadedFiles();
    if (empty($files['newfile'])) {
        throw new Exception('Expected a newfile');
    }

    $newfile = $files['newfile'];
    // do something with $newfile
});
```

image_1: fs.createReadStream(**dirname + '/background1.png'),
image_2: fs.createReadStream(**dirname + '/edge1.png')
