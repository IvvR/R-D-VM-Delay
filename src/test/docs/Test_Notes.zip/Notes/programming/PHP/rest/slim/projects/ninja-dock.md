# Ninja-doc

The base is

## Permission fix

To work 775 permision leve is needed for drwxrwxr-x 4

chmod 775
sudo chmod -R 775 ./
sudo chmod -R 775 web
sudo chmod -R 775 etc

## Add slim support

Update composer.json

composer require slim/slim "^3.12"

docker exec -it apache_server bash

## updating app with dockerized compozer

```bash
docker run --rm -v $(pwd)/web/app:/app composer update
```

### Installing package with composer

```sh
docker run --rm -v $(pwd)/web/app:/app composer require symfony/yaml
```

launch in a -d -detached mode

```sh
   sudo docker-compose up -d
```

Stop and clear services

```sh
  sudo docker-compose down -v
```

## funny funny stuff

Update autoloader from the root of a project

```sh [!NOTE] doesn't update autoload
docker run --rm -v $(pwd)/web/app:/app composer dump-autoload
```

[!NOTE] pls look at the following files. the trick to make some changes

> and launch composer update
> vendor/autoload.php
