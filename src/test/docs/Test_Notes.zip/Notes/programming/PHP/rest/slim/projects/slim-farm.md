# A Pen farm project

[Getting started with Slim PHP](https://dev.to/charliedevelops/getting-started-with-slim-php-framework-by-building-a-very-simple-mvcoop-app-4j2b)

Aim:
We are going to build a Slim application that creates a farm pen and outputs the noises that the cow & chicken inside the pen make.

Requirements:

- A pen can only contain a cow and a chicken (will help us practice with slim dependancy injection container)
- Must implement an MVC approach (help us understand how models, views and controllers work together)

[!NOTE] my model
Objects / Classes

- a Farm pen
- animals
  - chicken/s
  - cow/s
  - horse/s
  - duck/s
- an owner

## Skeleton creation

in a terminal window:

- mkdir slim-farm
- php -S localhost:8080 -t ./public/

in a browser

- localhost:8080/setFarmPen

## Container

Quite interesting thing. Like Spring Framework container

src/dependancies.php
\$container['penModel'] = new \Farm\Factories\PenModelFactory();
