# PHP rest

[PHP REST API From Scratch - 1](https://www.youtube.com/watch?v=OEWXbpUMODk)

db structure

id
category_id
title
description
cdn_link

```sql
CREATE TABLE 'image' (
  'id' int(11) NOT NULL AUTO_INCREMENT,
  'category_id' int(11) NOT NULL,
  'title' varchar(255) NOT NULL,
  'cdn_link' varchar(255) NOT NULL,
  'created_at' datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ('id')
);



http://www.slimframework.com/



│   ├── background1.png (uploaded in test)
│   ├── edge1.png (uploaded in test)


CloudFlare: Best Free CDN. When it comes to providing best CDN service free of cost then there is no better option than CloudFlare




Yes, you can store images in the database, but it's not advisable in my opinion, and it's not general practice.

A general practice is to store images in directories on the file system and store references to the images in the database. e.g. path to the image,the image name, etc.. Or alternatively, you may even store images on a content delivery network (CDN) or numerous hosts across some great expanse of physical territory, and store references to access those resources in the database.

Images can get quite large, greater than 1MB. And so storing images in a database can potentially put unnecessary load on your database and the network between your database and your web server if they're on different hosts.
```
