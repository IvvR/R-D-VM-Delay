# PHPUnit

## Composer installation

- composer require --dev phpunit/phpunit

## Composer run test

- composer test

## PHPUnit & Slim

[Controller unit test in slim3](https://stackoverflow.com/questions/36107883/controller-unit-test-in-slim3)

[!NOTE] Rob Allen suggestions

[Testing Slim Framework actions](https://akrabat.com/testing-slim-framework-actions/)

```php
class EchoActionTest extends \PHPUnit_Framework_TestCase
{
    public function testGetRequestReturnsEcho()
    {
        // instantiate action
        $action = new \App\Action\EchoAction();

        // We need a request and response object to invoke the action
        $environment = \Slim\Http\Environment::mock([
            'REQUEST_METHOD' => 'GET',
            'REQUEST_URI' => '/echo',
            'QUERY_STRING'=>'foo=bar']
        );
        $request = \Slim\Http\Request::createFromEnvironment($environment);
        $response = new \Slim\Http\Response();

        // run the controller action and test it
        $response = $action($request, $response, []);
        $this->assertSame((string)$response->getBody(), '{"foo":"bar"}');
    }
}
```
