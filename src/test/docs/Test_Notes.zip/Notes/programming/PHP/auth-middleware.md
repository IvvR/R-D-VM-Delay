# auth middleware

## Route middleware

It was/is tricky

I had no much luck with 'Invokable class middleware' and 'Closure middleware' despite to all my effort.Probably I missed some subtle details in conf.
I decided to give a shot 'Route middleware' it fired up in a moment.
The routing file became a bit overcrowded. I guess I could fix it with a dipper knowledge of Slim.

## Task

Add's a template to the database. Takes the form data as described and stores it in a database, should return a JSON object which returns a unique ID for the template (current implimentation assumes an integer, but it could be a UUID if desired). The authentication is kept simple (no tokens or anything) where it passes a Base64 encoded username and password
(User: template@storefront.com Pw: 1NA3S0OklKcCi6nQATXo). Do not store the password in plaintext in the database.

## slim middleware

[Middleware](http://www.slimframework.com/docs/v3/concepts/middleware.html)

## postman send request

User: template@storefront.com
Pw: 1NA3S0OklKcCi6nQATXo

## PSR-7 and PSR-15 HTTP Basic Authentication Middleware

[Basic Authentication Middleware](https://github.com/tuupola/slim-basic-auth)

(DB auth)(https://appelsiini.net/2014/slim-database-basic-authentication/)

http://www.9bitstudios.com/2013/06/basic-http-authentication-with-the-slim-php-framework-rest-api/

## Database

http://www.webstreaming.com.ar/articles/php-slim-token-authentication/

CREATE TABLE IF NOT EXISTS `user` (
`id` INT NOT NULL AUTO_INCREMENT,
`username` VARCHAR(45) NOT NULL,
`password` VARCHAR(45) NOT NULL,
`name` VARCHAR(45) NOT NULL,
`token` CHAR(16) NULL,
`token_expire` DATETIME NULL,
PRIMARY KEY (`id`),
UNIQUE INDEX `username_UNIQUE` (`username` ASC))
ENGINE = InnoDB

[Short Slim Video cources with auth](https://codecourse.com/watch/slim-3-authentication?part=155-getting-ready-to-change-password)

## Sign Up

- User sends a name & a pass
- bcrypt generates Salt
- hash the pass
- store in the database
- the hash and the salt ???

module.exports.hashPassword = async (password) => {
try {
const salt = await bcrypt.genSalt(10)
return await bcrypt.hash(password, salt)
} catch(error) {
throw new Error('Hashing failed', error)
}
}

## Crypt with php

[PHP Hash (bcrypt) Passwords]
http://www.gregboggs.com/php-blowfish-random-salted-passwords/

```sql
CREATE TABLE IF NOT EXISTS `users` (
`user_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
`email` varchar(30) NOT NULL,
`reg_date` date NOT NULL,
`fname` varchar(20) DEFAULT NULL,
`lname` varchar(20) DEFAULT NULL,
`salt` char(21) NOT NULL,
`password` char(60) NOT NULL,
PRIMARY KEY (`user_id`),
UNIQUE KEY `email` (`email`)
) ;

ALTER TABLE users MODIFY salt char(60);
DROP TABLE users;
```

```sql
CREATE TABLE IF NOT EXISTS `user` (
`user_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
`email` varchar(30) NOT NULL,
`salt` char(60) NOT NULL,
`password` char(60) NOT NULL,
PRIMARY KEY (`user_id`),
UNIQUE KEY `email` (`email`)
) ;
```

Storefront auth implementation differs from mine.

````sql
CREATE TABLE IF NOT EXISTS `user` (
`user_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
`email` varchar(30) NOT NULL,
`salt` char(60),
`password` char(60) NOT NULL,
PRIMARY KEY (`user_id`),
UNIQUE KEY `email` (`email`)
) ;


// Blowfish accepts these characters for salts.
$Allowed_Chars =
'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789./';
$Chars_Len = 63;
// 18 would be secure as well.
$Salt_Length = 21;
$mysql_date = date( 'Y-m-d' );
$salt = "";
for($i=0; $i&lt;$Salt_Length; $i++)
{
    $salt .= $Allowed_Chars[mt_rand(0,$Chars_Len)];
}
$bcrypt_salt = $Blowfish_Pre . $salt . $Blowfish_End;
$hashed_password = crypt($password, \$bcrypt_salt);

$sql = 'INSERT INTO users (reg_date, email, salt, password) ' .
"VALUES ('$mysql_date', '$email', '$salt', '\$hashed_password')";

## another impl

https://www.the-art-of-web.com/php/blowfish-crypt/

function b_crypt($input, $rounds = 7)
{
$salt = "";
    $salt_chars = array_merge(range('A','Z'), range('a','z'), range(0,9));
for($i=0; $i < 22; $i++) {
      $salt .= $salt_chars[array_rand($salt_chars)];
}
return crypt($input, sprintf('$2a$%02d$', $rounds) . $salt);
}

<?PHP
  $password_hash = better_crypt($password);
  $password_hash = better_crypt($password, 10); // will take longer
  $password_hash = better_crypt($password, 15); // will take a LOT longer
?>

to test against the hash

<?PHP
  if(crypt($password_entered, $password_hash) == $password_hash) {
    // password is correct
  }
?>

## signup test

http://localhost/api/signup
User: template@storefront.com
Pw: 1NA3S0OklKcCi6nQATXo

logger

```php
$logMsg = "Generated value: Salt : " . $salt . "password hash : " . $hashed_password . PHP_EOL;
file_put_contents('/home/ivan/projects/PHP/template/public/log/server.log', $logMsg, FILE_APPEND | LOCK_EX);
````

## Auth service / SLIM middleware

https://akrabat.com/writing-psr-7-middleware/

authorization: 'Basic dGVtcGxhdGVAc3RvcmVmcm9udC5jb206MU5BM1MwT2tsS2NDaTZuUUFUWG8='

### Removed stuff

// \$app = new \Slim\App();

// $app->add(function ($request, $response, $next) {
// $response->getBody()->write('BEFORE');
//     $response = $next($request, $response);
//     $response->getBody()->write('AFTER');

// return \$response;
// });

// $app->get('/', function ($request, $response, $args) {
// \$response->getBody()->write(' Hello ');

// return \$response;
// });

// \$app->add(new AuthService());

## Headers handling

ask:
$authHeader = $request->getHeader('Authorization');
return :
an array

check all hraders

```php
    foreach (getallheaders() as $name => $value) {
        $response->getBody()->write("$name: $value\n");
    }
```

return:

```headers
Connection: keep-alive
User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.96 Safari/537.36
Cache-Control: no-cache
DNT: 1
Authorization: Basic dGVtcGxhdGVAc3RvcmVmcm9udC5jb206MU5BM1MwT2tsS2NDaTZuUUFUWG8=
Accept: */*
Accept-Encoding: gzip, deflate, br
Accept-Language: en-GB,en-US;q=0.9,en;q=0.8,fr;q=0.7,ru;q=0.6
```

[!NOTE] !!! WTF !!!!
Slim creates headers from \$\_SERVER, and does not parse each header's value,.
so you can't fetch expected value with Request's getHeader method.

[array of single string instead of strings](https://github.com/slimphp/Slim/issues/1379)

    $headers = $request->getHeaders();
    foreach ($headers as $name => $values) {
        $response->getBody()->write(PHP_EOL);
        // $response->getBody()->write("$name: $value\n");
        $response->getBody()->write($name . ": " . implode(", ", $values));
        $response->getBody()->write(PHP_EOL);
        // echo $name . ": " . implode(", ", $values);
    }

## Testing

DELETE FROM `user` WHERE email = 'template@storefront.com';
INSERT INTO user (email, password) VALUES ('template@storefront.com','1NA3S0OklKcCi6nQATXo');

```php log
$logMsg = "Credentials. Mail : " . $savedUserMail . "password : " . $savedPass . PHP_EOL;
file_put_contents('/home/ivan/projects/PHP/template/public/log/server.log', $logMsg, FILE_APPEND | LOCK_EX);
```
