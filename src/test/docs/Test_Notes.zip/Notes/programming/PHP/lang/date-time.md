# DateTime

$dateTime = new DateTime('2016-01-01');
echo $dateTime->format('Y-m-d H:i:s');`
