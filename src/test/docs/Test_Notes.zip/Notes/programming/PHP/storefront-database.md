# Storefront database

// env

MYSQL_VERSION=5.7.22
MYSQL_HOST=mysql
MYSQL_DATABASE=template
MYSQL_ROOT_USER=root
MYSQL_ROOT_PASSWORD=root
MYSQL_USER=dev
MYSQL_PASSWORD=dev

dbname = template
user = dev
password = dev
user = root
password = root

tables:

## template

id : INT(11)
name : VARCHAR(255)
category_id: INT(11)
template_xml: TEXT NOT NULL
A CLOB column with a maximum length of 65,535 characters.
width INT(11)
height

```sql
CREATE TABLE `template`.`template` ( `id` INT(11) NOT NULL AUTO_INCREMENT , `name` VARCHAR(255) NOT NULL , `category` VARCHAR(255) NOT NULL , `template_xml` TEXT NOT NULL , `width` INT(11) , `heigh` INT(11) , PRIMARY KEY (`id`), UNIQUE(`name`), UNIQUE `name_idx` (`name`)) ENGINE = InnoDB;
```

some test data

````sql
INSERT INTO `template` (`id`, `name`, `category`, `template_xml`, `width`, `heigh`) VALUES (NULL, 'Greeting card 1', 'Birthday-Greeting-1', '<image_composition><canvas width="1800" height="1200" color="ffffff"><layer order="1" x="0" y="0" width="1800" height="1200"> ... </image_composition>', '1800', '1200'), (NULL, 'Greeting card 2', 'Birthday-Greeting-1', '<image_composition><canvas width="1800" height="1200" color="ffffff"><layer order="1" x="0" y="0" width="1800" height="1200"> ... </image_composition>', '1800', '1200')

ALTER TABLE template ADD COLUMN category_id INT(11);
ALTER TABLE template ADD FOREIGN KEY (category_id) REFERENCES category(id);

INSERT INTO `template` (`id`, `name`, `category_id`, `template_xml`, `width`, `heigh`) VALUES (NULL, 'Greeting card 1', 1, '<image_composition><canvas width="1800" height="1200" color="ffffff"><layer order="1" x="0" y="0" width="1800" height="1200"> ... </image_composition>', '1800', '1200'), (NULL, 'Greeting card 2', 5, '<image_composition><canvas width="1800" height="1200" color="ffffff"><layer order="1" x="0" y="0" width="1800" height="1200"> ... </image_composition>', '1800', '1200')


category
---------
id INT(11)
category : VARCHAR(255)
description` TEXT

```sql
CREATE TABLE `template`.`category` ( `id` INT(11) NOT NULL AUTO_INCREMENT , `name` VARCHAR(255) NOT NULL , `description` TEXT, PRIMARY KEY (`id`), UNIQUE(`name`), UNIQUE `name_idx` (`name`)) ENGINE = InnoDB;
````

INSERT INTO `category` (`id`, `name`, `description`) VALUES (NULL, 'Greeting card 2', 'Greeting card 2 description'), (NULL, 'Greeting card 2', 'Greeting card 2 description'), (NULL, 'Greeting card 3 description', 'Greeting card 3'), (NULL, 'Greeting card 4', 'Greeting card 4 description'), (NULL, 'Birthday card 1', 'Birthday card 1 description')

## image

id
name
template_id : int - template foreign key

CREATE TABLE `template`.`image` ( `id` INT(11) NOT NULL AUTO_INCREMENT , `name` VARCHAR(255) NOT NULL , `template_id` INT(11) NOT NULL , PRIMARY KEY (`id`)), UNIQUE(`name`), UNIQUE `name_idx` (`name`)) ENGINE = InnoDB;

## user

[!NOTE] remove backlash in 'template.\* '

SELECT User FROM mysql.user;
CREATE USER 'dev'@'localhost' IDENTIFIED BY 'dev';
GRANT ALL PRIVILEGES ON template.\* TO 'dev'@'localhost';
desc mysql.user;

## PDO

```php
  try {
    // get DB object
    $db = new db();
    $dbConnect = $db->connect();
    $stmt = $dbConnect->query($sql);
    $templates = $stmt->fetch(PDO::FETCH_OBJ);
    //probably would be done at the end of this script anyways
    $dbConnect = null;
    // echo json_encode($templates);
    // $response->getBody()->write("Done");
    $response->getBody()->write(json_encode($templates));
  } catch(PDOException $e) {
    echo '{"error": {"text": '.$e->getMessage().'}';
  }
```

[!NOTE] json_encode(\$templates) return just the first BROCKEN record
Reason: the 'XML' property/string of a sample is not 'well formed'
Policy : catch error, log with a template name. the sample XML structure was fixed.

[!NOTE] Duplication check
As a template's Id does not exist on this stage, check by a template name, stop processing if existed and and log it.

[on-line XML2JSON conver](https://www.freeformatter.com/xml-to-json-converter.html#ad-output)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<image_composition>
   <canvas width="1800" height="1200" color="ffffff">
      <layer order="1" x="0" y="0" width="1800" height="1200">...</layer>
   </canvas>
</image_composition>
```

from node.js test

```xml
<image_composition>
   <canvas width="1800" height="1200" color="ffffff">
      <layer order="1" x="0" y="0" width="1800" height="1200">
         <image filename="background1.jpg" width="1800" height="1200">
            <image_edit />
         </image>
      </layer>
      <layer order="2" x="600" y="100" width="1000" height="1000" alpha_merge="true">
         <border filename="edge1.png" width="1200" height="1200">
            <image_edit />
         </border>
      </layer>
   </canvas>
</image_composition>
```

[!NOTE] update the 'xml' field of the 'template' table. done.

```sql
UPDATE `template` SET `template_xml` = '<image_composition> <canvas width="1800" height="1200" color="ffffff"> <layer order="1" x="0" y="0" width="1800" height="1200">...</layer> </canvas> </image_composition>' WHERE `template`.`id` = 1
```

[!NOTE] check php loggers stack. done.

## downloadlable urls

[!NOTE] done

sql updated

```sql
SELECT t.id as id, t.name as name, c.name as category, t.width as width, t.height as width, t.template_xml as xml FROM template t INNER JOIN category c ON t.category_id = c.id WHERE  t.id = $id
```

```php
        $uri_auth = "http://localhost:8000";
        $uri_path = "/image/";

        $pics = $stmt_pics->fetchAll(PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE, 'Image');
        foreach ($pics as $pic) {
            $pic->setPath($uri_auth . $uri_path);
        }
```
