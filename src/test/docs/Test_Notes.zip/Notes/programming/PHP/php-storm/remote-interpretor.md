# Remote interpreter

[PHPStorm Remote interpreter](https://www.jetbrains.com/help/phpstorm/configuring-remote-php-interpreters.html)

https://www.jetbrains.com/help/phpstorm/docker.html

## Before you start:

- Make sure that Docker is downloaded, installed, and configured on your computer as described in Docker.
- Make sure the Docker Integration, PHP Docker, and PHP Remote Interpreter plugins are installed and enabled.
- ## Configure the PHP development environment in the Docker container to be used.

PHPStorm has an awesome support for remote PHP Interpreters. You can develop on a Windows PC or a Mac while running and debugging on a remote Linux server. PHPStorm has this feature out of the box https://www.jetbrains.com/help/phpstorm/configuring-remote-php-interpreters.html.

Having a remote interpreter allows you to use other cool PHP utilities such as phpcs, composer and many others.

Remote interpreters can either be integrated using Docker containers or via SSH. This is something which is holding us back from VSCODE.

## Debugger

https://thecodingmachine.io/configuring-xdebug-phpstorm-docker

https://stackoverflow.com/questions/46263043/how-to-setup-docker-phpstorm-xdebug-on-ubuntu-16-04
