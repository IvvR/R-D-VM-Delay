# Template Storefront

## Preps

- mkdir template
- cd template
- composer require slim/slim "^3.0"
- [!NOTE] ls. composer.json created.
- create 'public' folder
- create 'index.php' inside 'public'
- copy 'starter app' from Slim homepage to 'index.php'
- fix GET route
- ```php
  $app->get('/api/template/{id}', function (Request $request, Response $response, array $args) {
      $id = $args['id'];
      $response->getBody()->write("Template, $id");
      return $response;
  });
  ```
- fix the vendor's location
  require '../vendor/autoload.php';
- ran in a browser: [!NOTE] '/api/template/123' must be used
  http://localhost/template/public/index.php/api/template/123
- [!NOTE] done

- fix the path with '.htaccess'
- sudo a2enmod rewrite
- service apache2 restart

## Logging / Monolog Installation

[!NOTE] composer is a pretty slow utility. stay calm.

- composer require monolog/monolog
  "monolog/monolog": "^1.24" has added to composer.json
