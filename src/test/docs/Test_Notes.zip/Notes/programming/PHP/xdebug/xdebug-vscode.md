# XDEBUG VScode

## Local installation

[Debugging: Configure VS Code + XDebug + PHPUnit ](https://tighten.co/blog/configure-vscode-to-debug-phpunit-tests-with-xdebug)

- install xdebug

```sh
- sudo apt-get install php-xdebug
- php --ini // output : /etc/php/7.0/cli/conf.d/20-xdebug.ini
- php -m  // output :  xdebug
```

- start nging & fpm

  - systemctl is-active nginx
  - systemctl is-active php7.0-fpm
  - sudo service nginx start
  - sudo service php7.0-fpm start

- nging blocks check
  - /etc/nginx/conf.d // ok : splain.conf, testing.conf exist
  - splain:8080 in a browser

[!NOTE] OK, it works on hardware

## Docker installation

- launch : // sudo docker-compose up -d
- check containers : // docker ps -a
- log into container : // docker exec -it ph sh
- ping the host : //

[!NOTE] StoreTestIdia configured UNproperly

> trying 'ninja-dock' it worked couple days ago

- sudo docker-compose down -v
- sudo docker-compose up -d // luckily it works on 'ninja-dock'
- docker ps -a
- docker exec -it ninja-dock_php_1 sh

## Inspect network

- docker network ls
- docker network inspect ninja-dock_default

```sh output
                "Name": "ninja-dock_php_1",
                "EndpointID": "1ccb505a884f18b32f78dc21d077d3696c708000a5398c3aaf5cf5796f9fdd08",
                "MacAddress": "02:42:c0:a8:d0:02",
                "IPv4Address": "192.168.208.2/20",
```

### Gateway ?

192.168.208.1
