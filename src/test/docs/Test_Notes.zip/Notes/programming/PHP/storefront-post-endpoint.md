# POST ENDPOINT

return template id

## post form data for node

```javascript
const formData = {
  name: 'Birthday-Greeting-1',
  category: 'birthday',
  xml: `<image_composition>
<canvas width="1800" height="1200" color="ffffff">
    <layer order="1" x="0" y="0" width="1800" height="1200">
        <image filename="background1.jpg" width="1800" height="1200">
            <image_edit/>                
        </image>
    </layer>
    <layer order="2" x="600" y="100" width="1000" height="1000" alpha_merge="true">
        <border filename="edge1.png" width="1200" height="1200">
            <image_edit/>
        </border>
    </layer>
</canvas>
</image_composition>`,
  width: 1800,
  height: 1200,
  number_of_images: 2,
  image_1: fs.createReadStream(__dirname + '/background1.png'),
  image_2: fs.createReadStream(__dirname + '/edge1.png')
};
```

[!NOTE] should images be saved in a DB without its file extensions, or not

```javascript
let filename = path.basename(images[i]) + '.png';
const writeFile = fs.createWriteStream(path.join(downloadDir, filename));
```

## logging

```php
$logMsg = "GET /api/templates route. Connection closed " . PHP_EOL;
file_put_contents('/home/ivan/projects/PHP/template/public/log/server.log', $logMsg, FILE_APPEND | LOCK_EX);
```

php debug

```php
foreach ($templProps as $key => $value) {
    $logMsg = "$templProps: " . $key . " : " . $value . PHP_EOL;
    file_put_contents('/home/ivan/projects/PHP/template/public/log/server.log', $logMsg, FILE_APPEND | LOCK_EX);
}
```

```json
{"id":"1","name":"Greeting card 1","category":"birthday","width":"1800","height":"1200","xml":"
<image_composition>\r\n
 <canvas width=\"1800\" height=\"1200\" color=\"ffffff\">\r\n
 <layer order=\"1\" x=\"0\" y=\"0\" width=\"1800\" height=\"1200\">...<\/layer>\r\n <\/canvas>\r\n
<\/image_composition>",
"images":["http:\/\/localhost:8000\/image\/f46565a295be11e89eb6529269fb1459.png","http:\/\/localhost:8000\/image\/feebc38695be11e89eb6529269fb1459.png"]}
```

## forward slashes issue

To fix use JSON_UNESCAPED_SLASHES

- json_encode(\$template, JSON_UNESCAPED_SLASHES)

## MYSQL error 1364 Field doesn't have a default values

mysql error 1364 Field doesn't have a default values

Open phpmyadmin and goto 'More' Tab and select 'Variables' submenu. Scroll down to find sql mode. Edit sql mode and remove 'STRICT_TRANS_TABLES' Save it.

sudo systemctl restart mysql

'Birthday-Greeting-1'

SELECT \* FROM `template` WHERE name='Birthday-Greeting-7'

$logMsg = "POST /api/template . Last id: " . $last_template_id . PHP_EOL;
file_put_contents('/home/ivan/projects/PHP/template/public/log/server.log', \$logMsg, FILE_APPEND | LOCK_EX);

        $logMsg = "POST /api/template . imgHandler. Error status : " . $errors['status'] . PHP_EOL;
        file_put_contents('/home/ivan/projects/PHP/template/public/log/server.log', $logMsg, FILE_APPEND | LOCK_EX);


        $logMsg = "POST /api/template . imgHandler. Error size : " . $errors['status'] . PHP_EOL;
        file_put_contents('/home/ivan/projects/PHP/template/public/log/server.log', $logMsg, FILE_APPEND | LOCK_EX);
