# Tools installation

## PHP Composer

PHP dependency management tool

### Installing the Dependencies

sudo apt install curl php-cli php-mbstring git unzip

### Installing Composer

- curl -sS https://getcomposer.org/installer -o composer-setup.php
- HASH=48e3236262b34d30969dca3c37281b3b4bbe3221bda826ac6a9a62d6444cdb0dcd0615698a5cbe587c3f0fe57a54d8f5
- php -r "if (hash_file('SHA384', 'composer-setup.php') === '\$HASH') { echo 'Installer verified'; } else { echo 'Installer corrupt'; unlink('composer-setup.php'); } echo PHP_EOL;"
- sudo php composer-setup.php --install-dir=/usr/local/bin --filename=composer

## Slim Framework 3 Skeleton Application

https://github.com/slimphp/Slim-Skeleton

php composer.phar create-project slim/slim-skeleton [my-app-name]

php composer.phar create-project slim/slim-skeleton FrontSk
composer create-project slim/slim-skeleton FrontSk

## PHP Unit

composer require --dev phpunit/phpunit
composer require --dev mockery/mockery

## source management / Autoloading

- composer init
- composer require --dev phpunit/phpunit
- composer require monolog/monolog
- composer remove monolog/monolog

### Autoloading

[PHP Composer … The Autoloader](https://medium.com/tech-tajawal/php-composer-the-autoloader-d676a2f103aa)

[PSR4 Autoloading your PHP files using Compose](https://thewebtier.com/php/psr4-autoloading-php-files-using-composer/)

Composer generates a vendor/autoload.php file which automatically loads the classes your project depends on. Just include that file in your PHP script:

```php
    require __DIR__.'/vendor/autoload.php'
```

- issue : Composer doesn't autoload packages
- solution : add PSR-4 to composer.json

Both of PSR-0 and PSR-4 are almost have the same rules.
Note the following:

- For both, you don’t have to run composer dumpautoload every time you add a new PHP class because “searching for file path” process is going dynamically.
- You have to use namespaces, especially with PSR-4 because the namespace is attached to the file path.

## New app skeleton

- composer create-project slim/slim-skeleton rest-refresh
