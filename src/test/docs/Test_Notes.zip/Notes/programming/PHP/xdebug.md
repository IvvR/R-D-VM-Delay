# XDEBUG installation

[Configure Xdebug + PHP 7 + Nginx + Ubuntu 17.10](https://blog.thamaraiselvam.com/finally-configured-xdebug-with-sublime-text-3-on-ubuntu-17-04-ea19aff56c67?gi=97096e7ed8d2)

xdebug installation instruction
https://xdebug.org/wizard.php

## BS. forget it !!!

2. install the pre-requisites for compiling PHP extensions. On your Ubuntu system, install them with:

   1. sudo apt-get install php-dev autoconf automake
      - due to brocken php7.3, sudo apt-get remove php-dev autoconf automake
      - sudo apt-get install php-dev autoconf automake

sudo apt-get remove php-dev autoconf automake

apt–get remove libpcre3

sudo apt–get install libpcre3 libpcre16-3

apt–get install libpcre3–dev
libpcre3 2:8.42

## XDEBUG with PHP Storm

- sudo apt-get install php-xdebug
- sudo gedit /etc/php/7.0/mods-available/xdebug.ini

```bash
zend_extension=xdebug.so
zend_extension=/usr/lib/php/20151012/xdebug.so
# xdebug.remote_autostart = 1 # questionable parameter
# some config set it to 'on'
xdebug.remote_enable = 1
xdebug.remote_handler = dbgp
xdebug.remote_host = 127.0.0.1
  # change the access mode to 666
xdebug.remote_log = /tmp/xdebug_remote.log
  # questionable parameter
xdebug.remote_mode = req
#if you want to change the port 9005 you can change. Lol. It must be opened !!!
xdebug.remote_port = 9005
# xdebug.show_error_trace = 1
```

- sudo apt-get install php7.0-cgi
- sudo systemctl restart php7.0-fpm
- sudo systemctl restart nginx

[!NOTE] worked well for a bit

```log
Cannot load Xdebug - it was already loaded
XDebug could not open the remote debug file '/tmp/xdebug_remote.log'.
```

solution 1 [!NOTE] used this way

- sudo chown www-data:www-data /tmp/xdebug-remote.log
- sudo chmod 664 /tmp/xdebug-remote.log

> or 666 rw-rw-rw
> sudo chmod 666 /tmp/xdebug-remote.log

solution 2
[](https://github.com/Varying-Vagrant-Vagrants/VVV/issues/621)

- cd /etc/php/7.0/mods-available
  Edit the xdebug config file:
- sudoedit xdebug.ini
  The first line in the file should be:
- xdebug.remote_log = /var/log/xdebug/xdebug.log

This solves 2 problems: 1) It will get rid of the error and 2) It will put the log file into a folder shared with your host. You can look at the log file on your host OS without having to SSH over to your VM and figure out where the file is buried in the VM OS.

[!NOTE] DONE !!!! - sorry, not. lol

## Remote debug config

[Configure IntelliJ IDEA Ultimate or PhpStorm](https://phauer.com/2017/debug-php-docker-container-idea-phpstorm/)

curl "http://localhost:8000/index.php?XDEBUG_SESSION_START=PHPSTORM"

Yes – `/bin/bash` doesn't exist on Alpine (unless you manually install it). `/bin/sh` and `/bin/ash` do though.

Try `docker exec -it node-app-1 sh`
