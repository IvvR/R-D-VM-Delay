#image upload

415 Unsupported Media Type
416 Requested Range Not Satisfiable
417 Expectation Failed
421 Misdirected Request
422 Unprocessable Entity
424 Failed Dependency
426 Upgrade Required
428 Precondition Required
