
# Domain Driven Design notes

