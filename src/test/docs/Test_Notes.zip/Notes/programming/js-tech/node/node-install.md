# Node installation

[digital ocean]()

wget -qO- https://raw.githubusercontent.com/creationix/nvm/v0.34.0/install.sh | bash
