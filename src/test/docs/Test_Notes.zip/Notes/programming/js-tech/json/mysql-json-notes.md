
# JSON notes

JSON key, value mechanisms.  

key, value we mean there exists some tag (normally a string) that forms
the key and each key is associated with a value.
JSON allows to describe data in any way without forcing structure.
The only restriction is the proper use of the descriptors (curly braces, square brackets, quotes, commas, etc.) that must be aligned and in some cases paired correctly.

API sometimes  called a programming library, is a set of classes and methods.

MySQL X DevAPI (built on the X Protocol) provide connectivity to the server, abstractions of concepts (such as collections, tables, SQL operations), and more.

## NoSQL Interface

NoSQL interface is an API that does not require the use of SQL statements to access data.
NoSQL interfaces allows to use APIs to work with the data rather than SQL command-based interfaces.

### MySQL hybrid options

MySQL has been designed to permit storing and retrieving JSON documents in the relational data (via the SQL interface). The server has been modified to allow all manner of things with the JSON data via the SQL interface.

JSON documents could be used via the NoSQL X DevAPI as a pure document store.

## Document Store

a storage and retrieval system for managing semistructured data (documents).

## JSON Documents

The JSON data type advantages:

- Validation
- Efficient access: binary format for fast access to elements rather than parsing the data each time.

## Using JSON in MySQL

in MySQL, JSON documents are written as strings.  
good news, just check AlphaVantage JSON structure with MySQL validator and it's passed.
the trick is single quotes usage with {}.

MySQL json validation:

```sql
SELECT JSON_VALID('{
    "Meta Data": {
        "1. Information": "Intraday (5min) open, high, low, close prices and volume",
        "2. Symbol": "MSFT",
        "3. Last Refreshed": "2018-09-07 15:55:00",
        "4. Interval": "5min",
        "5. Output Size": "Compact",
        "6. Time Zone": "US/Eastern"
    }}');
```

> let's try to use it

CREATE DATABASE `test`;
> do I have to use 'commit' ?
USE test
> nah,  USE db_name (should be without quotes)

```sql
CREATE TABLE test.addresses (id BINARY(16) PRIMARY KEY NOT NULL, address json DEFAULT NULL);

INSERT INTO test.addresses
VALUES (UUID_TO_BIN(UUID()), '{"address": {"street": "123 First Street","city":
"Oxnard","state": "CA","zip": "90122"}}');

INSERT INTO `test`.`addresses` VALUES
(UUID_TO_BIN(UUID()), '{"address": {"street":"4 Main Street","city":"Melborne","state":
"California","zip":"90125"}}');

-- good, but UUID in binary
SELECT * FROM test.addresses;

SELECT BIN_TO_UUID(id) id, address FROM test.addresses;
  
```

[!NOTE]
> the sum of the JSON documents in a table row is limited to the value of
> the variable max_allowed_packet.  
> nano /etc/mysql/my.cnf , but empty. lol  
> select @@global.max_allowed_packet; works. who knows what does 67108864 mean. lol.  
> maybe should be divided to 1024k. default value is 64M ?

> [!TIP]  
> JSON columns cannot have a default value like other columns (data types)
> in a table.

The JSON_ARRAY() function takes a list of values and returns a valid formatted JSON
array.

```sql
SELECT JSON_ARRAY(1, true, 'test', 2.4);
```

The JSON_OBJECT() function takes a list of key, value pairs and returns a valid JSON
object.

```sql
SELECT JSON_OBJECT("street","4 Main Street","city","Melborne",'state','California','zip',90125);
```

The JSON_TYPE() function takes a JSON document and parses it into a JSON value.

## how to access the elements in a JSON document

To access an element—via its key—special notation called path expressions should be used.  
> Wow ! Cool.

```sql
SELECT BIN_TO_UUID(id), address->'$.address.city'
FROM test.addresses WHERE address->'$.address.zip' = '90125';
```

## Path Expressions

## MySQL Shell

- install with 'sudo apt-get install mysql-shell'
- load with 'mysqlsh root@localhost/test --py'

```sql
ivan@ivr:~$ mysqlsh root@localhost/test --py
Creating a session to 'root@localhost/test'
Please provide the password for 'root@localhost': *****
Save password for 'root@localhost'? [Y]es/[N]o/Ne[v]er (default No): y
Fetching schema names for autocompletion... Press ^C to stop.
Your MySQL connection id is 62 (X protocol)
Server version: 8.0.12 MySQL Community Server - GPL
Default schema `test` accessible through db.
MySQL Shell 8.0.12
```


