# JS6 Map - Reduce

// Optionally, you can specify an initial value
let result = arr.reduce(callback, initValue);

where callback function for es6 looks like:

```javascript
(accumulator, val) => {
  return accumulator + val;
};
```

where 'accumulator' is a var to collect values and
'val' is a current object of the collection
