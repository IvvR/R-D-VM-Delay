
# Sounds classification

[Sound Classification with TensorFlow](https://medium.com/iotforall/sound-classification-with-tensorflow-8209bdb03dfb)


[Models for AudioSet](https://github.com/tensorflow/models/tree/master/research/audioset)

[Voice Recognition (NOT Speech Recognition) Is Here](https://dzone.com/articles/voice-recognition-not-speech-recognition-is-here)

## Speaker Diarization

[!NOTE]
> That's it !!! 

Speaker diarisation (or diarization) is the process of partitioning an input audio stream into homogeneous segments according to the speaker identity.

## Multichannel Recognition 

In multiparticipant recordings where each participant is recorded in a separate channel (e.g., phone call with two channels or video conference with four channels), Cloud Speech-to-Text will recognize each channel separately and then annotate the transcripts so that they follow the same order as in real life. 

Pretty good presentation of HONGJOO LEE, CTO and Machine Learning Engineer.
[Speaker Diarization ]
(https://www.slideshare.net/hongjoo/speaker-diarization)

## IBM Speach to text

Lite
100 Minutes per Month
Free

service name
Speech to Text-q1

[Android SDK](https://github.com/watson-developer-cloud/android-sdk)

## pyAudioAnalysis

[pyAudioAnalysis]
(https://github.com/tyiannak/pyAudioAnalysis)

- Extract audio features and representations (e.g. mfccs, spectrogram, chromagram)
- Classify unknown sounds
- Train, parameter tune and evaluate classifiers of audio segments
- Detect audio events and exclude silence periods from long recordings
- Perform supervised segmentation (joint segmentation - classification)
- Perform unsupervised segmentation (e.g. speaker diarization)
- Extract audio thumbnails
- Train and use audio regression models (example application: emotion recognition)
- Apply dimensionality reduction to visualize audio data and content similarities

Old post but it was helpful  
[Best Practices for Speaker Diarization](https://www.kaggle.com/general/24412)

