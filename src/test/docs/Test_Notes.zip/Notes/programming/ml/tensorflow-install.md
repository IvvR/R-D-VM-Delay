
# Tensorflow installation

[With Docker](https://www.tensorflow.org/install/docker)

## Docker installation

[Docker install](https://docs.docker.com/install/)  
[Ubuntu](https://docs.docker.com/install/linux/docker-ce/ubuntu/)

> lol. it was funny.  
> sudo apt-get install docker-ce  
> docker-ce is already the newest version (18.06.1~ce~3-0~ubuntu).

Verify that Docker CE is installed correctly by running the hello-world image.

- sudo docker run hello-world

## How to check nvidia-docker version?

```bash
ivan@ivr:~$ nvidia-docker version
nvidia-docker: command not found
```

so, no needs to remove the ald version.
ok, let's install the new one

[GPU support installation](https://gist.github.com/Brainiarc7/a8ab5f89494d053003454efc3be2d2ef)

ok, it says  
Success: TensorFlow is now installed. Read the tutorials to get started.  
[Tutorial](https://www.tensorflow.org/tutorials/)

## within a TensorFlow-configured container

Start a bash shell session  

```bash
sudo docker run -it tensorflow/tensorflow bash
root@78f6e5c788a5:/notebooks# 
```

To run a TensorFlow program developed on the host machine within a container, mount the host directory and change the container's working directory (-v hostDir:containerDir -w workDir):

```bash
sudo docker run -it --rm -v $PWD:/tmp -w /tmp tensorflow/tensorflow python ./script.py
```

## Docker. detach.

[Correct way to detach from a container without stopping it](https://stackoverflow.com/questions/25267372/correct-way-to-detach-from-a-container-without-stopping-it)

- <CTRL> + <C> kills the container
- 