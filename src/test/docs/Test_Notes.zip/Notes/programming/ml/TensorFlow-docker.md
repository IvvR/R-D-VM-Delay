
# TensorFlow docker

a bit BS article:  
[A TensorFlow docker image to rule them all](https://ricardodeazambuja.com/deep_learning/2018/05/04/tuning_tensorflow_docker/)

Right cmd:
docker run --runtime=nvidia -it tensorflow/tensorflow:latest-gpu bash

well, not so shitty article. It shows how to open a channel to use the host notebook browser.

docker run --rm --runtime=nvidia -it -p 8888:8888 tensorflow/tensorflow:latest-gpu-py3

So far so good. The command above automatically opens/tunnels the port 8888 to the host (enabling you to access jupyter notebooks using the host browser) and this particular image launches, by default, the jupyter notebook server when you start your container.

[ROS](http://wiki.ros.org/docker/Tutorials/GUI)
BTW, quite interesting info  
[About Ricardo](https://ricardodeazambuja.com/about/)

To give you an idea, my final project (yes, undergrads had to develop a project, with a dissertation and defend it during a public presentation in front of three examiners) was a system, 100% written in assembly language, to generate text messages using composite video signals (TEXvid). My M.Sc., again, had a dissertation and public presentation, but with an extra external examiner. 

For my Ph.D... 
During my fours years at University of Plymouth/UK, I had the chance to interact and learn from top researchers in the field of artificial intelligence, cognition and robotics. I was also part of the Bioinspired Architecture for Brain Embodied Language (BABEL) project where I received training and had access to collaborative robotics and neuromorphic computers. Throughout my research, I worked on cognitive robotics, spiking neural networks and collaborative robotics. Those fields were introduced to me by my first director of studies, Prof. Angelo Cangelosi, and my supervisors Dr. Samantha V. Adams and Dr. Martin F. Stoelen.

during my final year, I worked part-time on an agricultural and collaborative robotics startup.

