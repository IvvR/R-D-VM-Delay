
# Make a call

https://stackoverflow.com/questions/4816683/how-to-make-a-phone-call-programmatically


With some fully audio playing. Attempt.
https://stackoverflow.com/questions/36565820/android-call-answering-programatically

