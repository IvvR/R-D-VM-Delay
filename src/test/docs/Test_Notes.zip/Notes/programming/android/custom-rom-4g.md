# Custom roms

[Redmi NOTE 4G (dior) CM14 (CyanogenMod 14) Nougat 7.0 ROM](https://www.cyanogenmods.org/forums/topic/redmi-note-4g-cm14-cyanogenmod-14-nougat-7-0-rom/)

- install libs: 
```ubuntu apt
sudo apt-get install bc bison build-essential ccache curl flex g++-multilib gcc-multilib git gnupg gperf imagemagick lib32ncurses5-dev lib32readline-dev lib32z1-dev liblz4-tool libncurses5-dev libsdl1.2-dev libssl-dev libwxgtk3.0-dev libxml2 libxml2-utils lzop pngcrush rsync schedtool squashfs-tools xsltproc zip zlib1g-dev
```
- Create the directories
    - mkdir -p ~/bin
mkdir -p ~/android/lineage


mkdir -p ~/droid


mkdir -p droid
curl https://storage.googleapis.com/git-repo-downloads/repo > ~/bin/repo

act:
curl https://storage.googleapis.com/git-repo-downloads/repo > bin/repo

cd ~/android/lineage
repo init -u https://github.com/LineageOS/android.git -b lineage-15.1

act:
cd ~android/lineage
repo init -u https://github.com/LineageOS/android.git -b cm-14.1

Then to sync up:
repo sync
https://hacksandgeeks.com/single-post/2017/04/02/How-to-Build-Custom-Lineage-OS-ROM

## Linux kernel for Xiaomi Redmi Note 4G aka dior MSM8926
