
# Table layout

can be scrollable
[!NOTE]  
> android:isScrollContainer="true"   
> BS. doesn't work

```xml
<android.support.constraint.ConstraintLayout
        android:layout_width="match_parent"
        android:layout_height="match_parent">

        <TableLayout
            android:id="@+id/tableLayout"
            android:layout_width="fill_parent"
            android:layout_height="fill_parent"
            android:isScrollContainer="true">
```

it's need to be wrapped up into ScrollView

```xml
    <ScrollView
        android:layout_width="fill_parent"
        android:layout_height="fill_parent"
        android:layout_weight="1"
        android:scrollbars="none">


        <TableLayout
```



To make symmetric columns:

```xml
android:layout_width="0dp"
android:layout_weight="1"
```
he layout_span attribute must be added to the child, not to TableRow. 

```xml
    <TableRow
        android:layout_width="wrap_content"
        android:layout_height="wrap_content" >

        <Button
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_span="2"
            android:text="@string/create" />
    </TableRow>
```

## Remove autofocus

To remove autofocus from  edit fields, set it on TableLayout

```xml
        <TableLayout
            ...
            android:focusable="true"
            android:focusableInTouchMode="true"
```

## table row height

How to increase the height of table row according to screens?

```xml
android:minHeight="60px"
```


If you setEnabled(false) then your editText would look disabled (gray, etc). You may not want to change the visual aspect of your editor.

A less intrusive way would be to use setFocusable(false).

