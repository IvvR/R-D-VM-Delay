# Services

Type of cervices

- foreground
- started
- binded

## in a separate process android

[Start a service](https://stackoverflow.com/questions/22514373/start-a-service-in-a-separate-process-android)

Defining a Process of a Service

The android:process field defines the name of the process where the service is to run. Normally, all components of an application run in the default process created for the application. However, a component can override the default with its own process attribute, allowing you to spread your application across multiple processes.

If the name assigned to this attribute begins with a colon (':'), the service will run in its own separate process.

<service
  android:name="com.example.appName"
  android:process=":externalProcess" />

If the process name begins with a lowercase character, the service will run in a global process of that name, provided that it has permission to do so. This allows components in different applications to share a process, reducing resource usage.

## Start your service as a Foreground Service

[Running a service in the foreground]
(https://developer.android.com/guide/components/services#Foreground)

A foreground service is a service that the user is actively aware of and isn't a candidate for the system to kill when low on memory. A foreground service must provide a notification for the status bar, which is placed under the Ongoing heading.

foreground services must show a status bar notification with a priority of PRIORITY_LOW or higher

example:  
an app to let users track their runs would need a foreground service to track the user's location.

[!NOTE]
> Yeah, I new it !!!

To request that your service run in the foreground, call
 
```java
startForeground(). 
```

### Example

From your main activity, start the service with the following code:

```java
Intent i = new Intent(context, MyService.class); 
context.startService(i);
```

Then in your service for onCreate() you would build your notification and set it as foreground like so:

```java
Intent notificationIntent = new Intent(this, MainActivity.class);

PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
                notificationIntent, 0);

Notification notification = new NotificationCompat.Builder(this)
                .setSmallIcon(R.mipmap.app_icon)
                .setContentTitle("My Awesome App")
                .setContentText("Doing some work...")
                .setContentIntent(pendingIntent).build();

startForeground(1337, notification);
```

[!NOTE]
> The code above deserves the note about Intent, PendingIntent, Notification collaboration
> PendingIntent used to load the app main activity (ui to do smth) from Notification
> Respect the Engs !
> Q : 
