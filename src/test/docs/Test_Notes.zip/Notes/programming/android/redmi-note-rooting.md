
# Rooting

Prerequisites:

- Redmi Note 4G(Single SIM) Stable/Developer Global ROM.
- Stock MI-Recovery 2.0.1
- Root.zip File

Steps to follow for rooting:

1. Download the Root.zip and Copy the file to the folder 'Internal storage' (root of internal storage)
2. Open the Updater app, Press the 3 dots at Right Top Corner,  A menu will open. Tap on “Choose Update Package“ and select the Root.zip File.


## Method 2: Recovery Update

[!NOTE]
> Please wipe all data in Recovery mode if you want to update to a discontinuous ROM 
> version, or downgrade to an older ROM version using MIUI full ROM pack. Due to the
> differences in Recovery interface, this method is not applicable to some Redmi MTK
> devices and devices with locked bootloader.

Download MIUI Global Forum app to get the latest news of MIUI and win amazing gifts. Click here to download

1. Download the latest MIUI ROM file Download here. Rename the downloaded ROM file to ‘update.zip’ on the computer.
2. Connect your device to the Windows PC/laptop via a micro USB cable, and copy the ROM file downloaded and renamed in Step 1 into the root directory of the internal storage of your device. (Do not put it in any folder)
3. Enter the Recovery mode of your device. There are 2 methods to do it as follows:

    3.1. Method 1: Launch ‘Settings’ app on your device, select ‘About phone’, click ‘System update’, then click the ‘…’ icon at the top-right corner, and select ‘Reboot to Recovery mode’ to enter.
    3.2. Method 2: You can also turn off your device and then hold both Volume+ button and Power button at the same time to enter Recovery mode.

## TWRP for Xiaomi

[TWRP for Xiaomi Redmi Note 4G (Single SIM)](https://twrp.me/xiaomi/xiaomiredminote4gsinglesim.html)

2.With MiRecovery using flashable zip:

    Copy the zip file in root of internal storage
    Rename it to update.zip
    Enter into recovery (volume up + power)
    Install update.zip from SDcard.
    Reboot.



3. With CWM or TWRP using flashable zip:

    Copy the zip file in root of external sd card
    Enter into recovery (volume up + power)
    Install zip from SDcard.
    Reboot.

## from ubuntu

[TWRP Installation Tutorial for Linux Mint and Ubuntu users](https://xiaomifirmware.com/guides-and-tips/flash-twrp-recovery-linux-ubuntu/)

> great experience

run the following command from the terminal.  
on the phone dev options & allow fastboot  must be switched ON

``` android script
adb devices
adb reboot bootloader
sudo fastboot devices
sudo fastboot flash recovery trwp.img
// well, if someting went wrong:
sudo fastboot reboot
```
let's try
sudo fastboot flash recovery twrp-3.2.3-0-dior.img // no sugar
// next try
sudo fastboot flash recovery twrp-2.8.7.0-dior.img

```output
8d41917	fastboot
ivan@ivr:~/TMP$ sudo fastboot flash recovery twrp-3.2.3-0-dior.img
target reported max download size of 838860800 bytes
sending 'recovery' (13726 KB)...
OKAY [  0.432s]
writing 'recovery'...
OKAY [  0.600s]
finished. total time: 1.032s
```

sudo fastboot oem device-info
(bootloader) 	Device tampered: false
(bootloader) 	Device unlocked: false
(bootloader) 	Charger screen enabled: false

that' was a miracle !!!

> [!IMPORTANT]  
> Done !