# Android Media

## NediaPlayer vs Wxoplayer


https://www.reddit.com/r/androiddev/comments/95l3hc/exoplayer_or_mediaplayer/

ExoPlayer can stream while the screen is off.
can be used for large video streaming apps.

[ExoPlayer’s new modular structure](https://medium.com/google-exoplayer/exoplayers-new-modular-structure-a916c0874907)

ExoPlayer 2.4 we’ve split the library into five modules:
- exoplayer-core: Core functionality (required).
- exoplayer-dash: Support for DASH content.
- exoplayer-hls: Support for HLS content.
- exoplayer-smoothstreaming: Support for SmoothStreaming content.
- exoplayer-ui: UI components and resources for use with ExoPlayer.

[!NOTE]
> Q: what type of content is streaming audio ?

compile 'com.google.android.exoplayer:exoplayer-core:r2.4.0'
compile 'com.google.android.exoplayer:exoplayer-dash:r2.4.0'

> Really good session !!
[Building feature-rich media apps with ExoPlayer (Google I/O '18)]
(https://www.youtube.com/watch?v=svdq1BWl4r8)

[Understanding MediaSession](https://medium.com/androiddevelopers/understanding-mediasession-part-1-3-e4d2725f18e4)

A music player app should absolutely integrate MediaSession. MediaSession provides hooks for playback control via media buttons on headphones, Android Wear, Android Auto, and Google Assistant. It might also benefit from utilizing a MediaBrowserService. By providing a MediaBrowserService, the app can allow users to use Android Auto, Wear, Assistant, and Bluetooth devices to navigate the media contents (without using the app’s UI).
