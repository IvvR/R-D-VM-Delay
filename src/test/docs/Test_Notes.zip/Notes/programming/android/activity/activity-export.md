# How to Export activities

There is apparently 2 ways:

[how others apps can call an activity?](https://stackoverflow.com/questions/8150003/how-to-export-an-activity-so-other-apps-can-call-it)

1. With an action filter

You need to declare an intent-filter in your Manifest (I took the following example from Barcode Scanner) :

```xml
<activity android:name="...">
    <intent-filter>
        <action android:name="com.google.zxing.client.android.SCAN" />
        <category android:name="android.intent.category.DEFAULT" />
    </intent-filter>
</activity>
```
Then create an intent with the same action string :

```xml
Intent intent = new Intent("com.google.zxing.client.android.SCAN");
startActivityForResult(intent, code);
```

2. With export

In the Manifest edit your Activity tag like so:

```xml
<activity
    android:name=".SomeActivity"
    ....
    android:exported="true" />
```

The important part is android:exported="true", this export tag determines "whether or not the activity can be launched by components of other applications". If your <activity> contains an <intent-filter> then this tag is set to true automatically, if it does not then it is set to false by default.

Then to launch the Activity do this:

```xml
Intent i = new Intent();
i.setComponent(new ComponentName("package name", "fully-qualified name of activity"));
startActivity(i);
```

Of course with this method you will need to know the exact name of the Activity you are trying to launch.

```xml

        Intent i = new Intent();
        String pkg = "com.xyz.app1";
        String cls = "com.xyz.app1.App1MainActivity";
        i.setComponent(new ComponentName(pkg, cls));
        App2MainActivity.this.startActivity(i);
```