# Android Activity

Activity must be implemented so as to be entirely independent of other activities in the application. A shared activity cannot rely on being called at a known point in a program flow (since other applications may make use of the activity in unanticipated ways) and one activity cannot directly call methods or access instance data of another activity. This, instead, is achieved using Intents and Content Providers. By default, an activity cannot return results to the activity from which it was invoked.

[!NOTE]
> so, what about preferences ? How to keep the state of the application ?

the system  creates  an importance hierarchy combining the priority and state currently running processes.

## The Activity Lifecycle

### The Activity Stack

### Dynamic State vs. Persistent State

