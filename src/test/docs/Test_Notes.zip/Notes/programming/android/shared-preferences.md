
# Shared Preferences

[Storing and Accessing SharedPreferences](https://guides.codepath.com/android/Storing-and-Accessing-SharedPreferences#accessing-stored-data-from-sharedprefrences)

## if SharedPreferences exists

[How to check if SharedPreferences exists or not](https://stackoverflow.com/questions/22821270/how-to-check-if-sharedpreferences-exists-or-not)

introduce IS_INITIALISED

```java
SharedPreferences sharedPrefs = getSharedPreferences("sp_name", MODE_PRIVATE);
    SharedPreferences.Editor ed;
    if(!sharedPrefs.contains("initialized")){
        ed = sharedPrefs.edit();

        //Indicate that the default shared prefs have been set
        ed.putBoolean("initialized", true);

        //Set some default shared pref
        ed.putString("myDefString", "wowsaBowsa");

        ed.commit();
    }  
```
