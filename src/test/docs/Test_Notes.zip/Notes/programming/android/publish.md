
# Keystore

## SHA-1 fingerprint

ivan@ivr:~/GitProjects/RD_IVVR$ keytool -list -v -keystore rd_ivvr.jks
Enter keystore password:  
Keystore type: jks
Keystore provider: SUN

Your keystore contains 1 entry

Alias name: vmdelay
Creation date: 23-Oct-2018
Entry type: PrivateKeyEntry
Certificate chain length: 1
Certificate[1]:
Owner: CN=Ivan Rakin, OU=RD, O=IVVR, L=New Westminster, ST=British Columbia, C=CA
Issuer: CN=Ivan Rakin, OU=RD, O=IVVR, L=New Westminster, ST=British Columbia, C=CA
Serial number: 52cc8c19
Valid from: Tue Oct 23 02:44:20 PDT 2018 until: Sat Oct 17 02:44:20 PDT 2043
Certificate fingerprints:
	 MD5:  53:D3:8C:73:8F:B8:04:25:B7:5D:2C:ED:56:52:20:8B
	 SHA1: E5:2B:34:A5:03:9A:A4:82:CE:E3:5A:7D:BC:F7:A3:FA:A1:FD:1E:3E
	 SHA256: 46:3E:2F:BB:C9:09:0D:14:DC:53:28:00:E4:8E:81:39:D7:DD:8E:7D:DC:36:93:BF:DA:D6:54:E2:A5:F7:B3:65
Signature algorithm name: SHA256withRSA
Subject Public Key Algorithm: 2048-bit RSA key
Version: 3

Extensions: 

#1: ObjectId: 2.5.29.14 Criticality=false
SubjectKeyIdentifier [
KeyIdentifier [
0000: 5D 92 6D DE C1 FA BC 0E   27 6C E3 EB 8F 3B 6C 8E  ].m.....'l...;l.
0010: 8E 6F 79 CF                                        .oy.
]
]



*******************************************
*******************************************



Warning:
The JKS keystore uses a proprietary format. It is recommended to migrate to PKCS12 which is an industry standard format using "keytool -importkeystore -srckeystore rd_ivvr.jks -destkeystore rd_ivvr.jks -deststoretype pkcs12".
ivan@ivr:~/GitProjects/RD_IVVR$ 
