
# System app install

[Android system apps](https://www.androidauthority.com/install-user-app-as-system-app-how-to-93522/)

## Requirements

- A rooted Android device.
- Enable USB debugging on your Android device. On most Android devices, you can find USB Debugging in Settings > Applications > Development.
- Backup all personal data
- Maintain a battery charge of 70% or more to make sure that you have sufficient power for the entire procedure.

## Installing a System App via ADB

- Open a command prompt on your computer and navigate to where the APK file is located.
- Enable USB debugging on your device and connect your device to the computer via USB cable.
- Enter the following commands: 
    - adb remount
    - adb push apk-filename-here /system/app/
    - adb shell chmod 644 /system/app/apk-filename-here
    - adb reboot

adb push Tango2.apk /system/app/

You can simply copy the apk (its name not relevant) into /system/app or /system/priv-app, set the appropriate permissions (rw-r-r, root:root) and then do a reboot. That's it.  
done the above steps but MODIFY_PHONE_STATE permission is not yet granted to my app. 


The /system/app method does work. I've installed apps that i've written and signed with my own key in that partition using the post-build method (mounting the image and then adding in the APKs manually) and was able to run them without a problem. BUT I have run into issues pre-installing apps using this method with certain APKs like Hulu Plus. – Android Noob Jun 11 '13 at 19:34


@Jakar: I copied my apk (a filemanager) to /system/app, gave 644 permissions, and rebooted. Yet, my app is still run without root privileges (deny access to some folders). Any clue? Thanks! – Luis A. Florit Sep 11 '14 at 12:51

Generally speaking an app being in the /system/app folder makes all declared permissions available to it, (for example, declaring WRITE_SECURE_SETTINGS only does anything for system apps), and then the code that was only available to system apps is now available to yours as well. 

[!NOTE]
> life tough for kidds

1. $ adb shell   // to exit from adb shell <CTRL> D
2. $ su
3. mount -o rw,remount /system

ok next
<!-- adb shell su -c "push Tango2.apk /system/app/" -->
 
adb devices
adb push Tango2.apk /sdcard/    // abd pushed it to sdcard0
adb shell
su
cd /sdcard
mv Tango2.apk /system/app
# or when using Android 4.3 or higher
mv Tango2.apk /system/priv-app

> life is really  not easy
cd storage
cd scard0

adb shell chmod 644 /system/app/apk-filename-here

default app permissions 644 RW/R/R
need 

com.irv.tango2-1.apk
mv com.irv.tango2-1.apk /system/app/ com.irv.tango2-1.apk
cp com.irv.tango2-1.apk /system/app/com.irv.tango2-1.apk


YESSSS !!!

1. $ adb shell   // to exit from adb shell <CTRL> D
2. $ su
3. mount -o rw,remount /system
4. cp com.irv.tango2-1.apk /system/app/com.irv.tango2-2.apk
5. mount -o ro,remount /system
6. Check how the /system partition is mounted as read-only (ro), In particular note the device
    # mount | grep system
 
1. rm -f /system/app/com.irv.tango2-2.apk    // force remove without prompt
2. rm -f com.irv.tango2-1.apk
mv /system/app/com.irv.tango2-2.apk /system/app/com.irv.tango2-1.apk // rename
chmod 644 com.irv.tango2-1.apk

[!NOTE]
> aftere deleting the file : device is busy
> repeat : mount -o rw,remount /system


[ADBShell command](http://adbshell.com/commands/adb-shell-mv)
