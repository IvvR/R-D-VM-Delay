
# Wireless

[Connect devices wirelessly](https://developer.android.com/training/connect-devices-wirelessly/)


