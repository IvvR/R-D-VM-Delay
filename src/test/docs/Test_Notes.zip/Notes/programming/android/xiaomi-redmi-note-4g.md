
# ROMs


[official site](https://en.miui.com/download-309.html)


[ROMs] Resurrection Remix 5.8.4 [Nougat 7.1] ROM forRedmi NOTE 4G (dior]
(http://en.miui.com/thread-553194-1-1.html)


https://forum.xda-developers.com/redmi-note/general/rom-nougat-dior-t3517804

http://en.miui.com/thread-294848-1-1.html

MIUI GLOBAL 9.2 / STABLE/ 9.2.3.0 9KHIMIEK0