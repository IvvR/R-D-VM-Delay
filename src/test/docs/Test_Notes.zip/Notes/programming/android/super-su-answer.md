
#Supersu answer

build on the following command adb shell command:
```adb shell 
adb shell service call phone 5
```

[ADBShell command](http://adbshell.com/commands/adb-shell-mv)

```java
try {
    Process proc = Runtime.getRuntime().exec("su");
    DataOutputStream os = new DataOutputStream(proc.getOutputStream());

    os.writeBytes("service call phone 5\n");
    os.flush();

    os.writeBytes("exit\n");
    os.flush();

    if (proc.waitFor() == 255) {
        // TODO handle being declined root access
        // 255 is the standard code for being declined root for SU
    }
} catch (IOException e) {
    // TODO handle I/O going wrong
    // this probably means that the device isn't rooted
} catch (InterruptedException e) {
    // don't swallow interruptions
    Thread.currentThread().interrupt();
}
```

Manifest

<!-- Inform the user we want them root accesses. -->
<uses-permission android:name="android.permission.ACCESS_SUPERUSER"/>

by the way, if you want to answer an incoming call on a rooted phone you just have to pase on the method this line:  

 Terminal.executeSuCommandWithoutResult("service call phone 5"); 

