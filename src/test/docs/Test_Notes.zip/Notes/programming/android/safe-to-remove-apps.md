
# Safe to remove bloatware

[List Of Safe To Remove System Apps](https://xiaomi.eu/community/threads/list-of-safe-to-remove-system-apps.36090/)
List of safe to remove System apps ( not frozen ) :

AntiSpam.apk
BackupReceiver.apk
BookmarkProvider.apk
BugReport.apk
CloudPrint2.apk
CloudService.apk
FileExplorer.apk ( replaced with RootExplorer )
GoogleCalendarSyncAdapter.apk
GoogleContactsSyncAdapter.apk
GoogleTTS.apk
HTMLViewer.apk
KingSoftCleaner.apk
KSICibaEngine.apk
LiveWallpapersPicker.apk
Metok.apk
MiGalleryLockscreen.apk
MiLinkService.apk
MiuiVideo.apk ( replaced with MX player pro )
NetworkAssistant2.apk
PartnerBookmarksProvider.apk
PicoTts.apk
PowerKeeper.apk
QuickSearchBox.apk
SecurityAdd.apk
SecurityCoreAdd.apk
TouchAssistant.apk
TranslationService.apk
Updater.apk ---don't remove ! can cause problems,like force close ,system fail ---
XiaomiAccount.apk ---don't remove ! can cause problems,like force close ,system fail ---
XMRemoteController.apk

--------------------------------

Backup.apk
BackupRestoreConfirmation.apk
Browser.apk ( replaced with other )
CellBroadcastReceiver.apk
CleanMaster.apk
CloudBackup.apk
DownloadProviderUi.apk
FindDevice.apk ---don't remove ! can cause problems,like force close ,system fail ---
GoogleBackupTransport.apk
MiDrop.apk
Mipub.apk
MiuiGallery.apk ( replaced with Galery2 from CM 13 rom)
Music.apk ( replaced with other )
SmartCardService.apk
SpacesTrustAgent.apk
VpnDialogs.apk
Weather.apk
WeatherProvider.apk
YellowPage.apk


Again this is the list of apps i removed from my own device ( this is how i like it ).

WARNING: This removes some functionality that may be useful to some users.
-> you don't have to remove all of them !!! <-
This is not a complete list ,the are more system apps which could be removed safely without causing the device to crash or popping up force close warnings.
