
# Telecom

[Telecom framework overview](https://developer.android.com/guide/topics/connectivity/telecom/)

The Android Telecom framework manages audio and video calls on an Android device. This includes SIM-based calls (e.g. using the Telephony framework) as well as VOIP calls provided by implementors of the ConnectionService API.

The two major components which Telecom deals with are ConnectionServices and InCallServices. A ConnectionService implementation is responsible for connecting calls to another party using some means (e.g. VOIP). The most common ConnectionService implementation on a phone is the Telephony ConnectionService which is responsible for connecting carrier calls. A InCallService implementation is responsible for providing a user interface to calls managed by Telecom and for providing the user with a means to control and interact with these calls. The Phone app bundled with a device is the most common example of an implementation of an InCallService .

## InCallService

If you want to create a replacement for the default Phone app on an Android deveice, implement the InCallService API.

> [!NOTE]
> Is it possible to call / hack installed Phone system app ? 
> my guess, it is possible. lol. Need that source code
> The Gods are good !!!

[android / platform / packages / apps / Phone](https://android.googlesource.com/platform/packages/apps/Phone/)


Pretty empty shit but with some passion it's possible to get the code
[aosp-mirror/platform_packages_apps_phone mirrored from](https://github.com/aosp-mirror/platform_packages_apps_phone)


