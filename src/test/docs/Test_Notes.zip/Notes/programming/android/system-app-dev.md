
# Development system apps

[How to install an app in system/app while developing from android studio](https://stackoverflow.com/questions/28302833/how-to-install-an-app-in-system-app-while-developing-from-android-studio)

Deploy automatically system app from AS

You can create a script that will do the job, and run it automatically each time you hit run in AS.
1. Create the script

You can adapt this script that I've created from my needs. Place it in: project_directory/installSystem.sh

```bash.sh
app_package="com.example"
dir_app_name="MySysApp"
MAIN_ACTIVITY="SysAppMainActivity"

ADB="adb" # how you execute adb
ADB_SH="$ADB shell" # this script assumes using `adb root`. for `adb su` see `Caveats`

path_sysapp="/system/priv-app" # assuming the app is priviledged
apk_host="./app/build/outputs/apk/app-debug.apk"
apk_name=$dir_app_name".apk"
apk_target_dir="$path_sysapp/$dir_app_name"
apk_target_sys="$apk_target_dir/$apk_name"

# Delete previous APK
rm -f $apk_host

# Compile the APK: you can adapt this for production build, flavors, etc.
./gradlew assembleDebug || exit -1 # exit on failure

# Install APK: using adb root
$ADB root 2> /dev/null
$ADB remount # mount system
$ADB push $apk_host $apk_target_sys

# Give permissions
$ADB_SH "chmod 755 $apk_target_dir"
$ADB_SH "chmod 644 $apk_target_sys"

#Unmount system
$ADB_SH "mount -o remount,ro /"

# Stop the app
$ADB shell "am force-stop $app_package"

# Re execute the app
$ADB shell "am start -n \"$app_package/$app_package.$MAIN_ACTIVITY\" -a android.intent.action.MAIN -c android.intent.category.LAUNCHER"
```

2. Bind it with AS Run

    Go to Run -> Edit Configurations

    Do the following changes on General tab (of your module)
        Installation Options->Deplay: Nothing
        Launch Options->Launch: Nothing
        Before launch: press +, then Run External Tool, to select your script.
            In the new dialog:
                set any name.
                On 'Tool Settings'->Program: navigate to the project's dir, and select your script

Caveats :
First installation

The device needs to be restarted (adb reboot) only once, on the very first installation of your app. Afterwards, you can simply press Run and everything will happen automatically.

This is because the host compiler (dex2oat) is not invoked automatically. Somehow the OS is not yet informed for this new system app. Calling dex2oat manually should solve this, but I had no luck. If anyone solves it please share.

adb root issues

Sometimes (usually the initial execution after the restart) the call to adb root does not find the device. You can simply re-play from AStudio, or sleep for a second after a successful adb root.

using su instead of adb root

adb push won't be working despite mounting system and giving permissions. To make it work replace the ADB_SH variable and the install section of the script with the following:

```script
..
ADB_SH="$ADB shell su -c"
..
# Install APK: using adb su
$ADB_SH "mount -o rw,remount /system"
$ADB_SH "chmod 777 /system/lib/"
$ADB_SH "mkdir -p /sdcard/tmp" 2> /dev/null
$ADB_SH "mkdir -p $apk_target_dir" 2> /dev/null
$ADB push $apk_host /sdcard/tmp/$apk_name 2> /dev/null
$ADB_SH "mv /sdcard/tmp/$apk_name $apk_target_sys"
$ADB_SH "rmdir /sdcard/tmp" 2> /dev/null
```

