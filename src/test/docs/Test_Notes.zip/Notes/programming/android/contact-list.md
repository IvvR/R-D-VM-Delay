
# Contact list

Objectives - get to know how to:

- retrieve data from the contact list(s?)
- add record ? 
- remove record

let's start with recipes ?  