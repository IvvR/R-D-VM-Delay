# Deployment

## Signiture

create keystore : /AndroidProjects/DroidStore
/AndroidStudioProjects/DroidStore/droid_apps.jks



It is a new signing mechanism introduced in Android 7.0, with additional features designed to make the APK signature more secure.

It is not mandatory. You should check BOTH of those checkboxes if possible, but if the new V2 signing mechanism gives you problems, you can omit it.

So you can just leave V2 unchecked if you encounter problems, but should have it checked if possible.
