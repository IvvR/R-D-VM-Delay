# ADB  - android debug bridge

Goes with platfom sdk
in linux terminal:
cd /Android/Sdk/platform-tools

adb devices  // maybe sudo ?

// ok, nothing is here
// run again - with

## long way
[]
(https://askubuntu.com/questions/632651/adb-devices-command-wont-detect-my-4-4-android-phone)

- Step 1: Find the Vendor ID
lsusb
 
Bus 001 Device 010: ID 2b0e:171b  
Bus 001 Device 012: ID 2b0e:171b  

device id 2b0e:171b
[!NOTE] IT'S NOW: 
2b0e:171e 


- Step 2: Create an adb_usb.ini file

Run the following

echo "0x<your device's Vendor ID>" > ~/.android/adb_usb.ini

echo "0x<your device's Vendor ID>" > ~/.android/adb_usb.ini

//echo "0x2b0e:171b" > ~/.android/adb_usb.ini
echo "2b0e:171e" > ~/.android/adb_usb.ini
 

[!NOTE] it bloody works !!!

```bash
ivan@ivr:~$ adb devices
List of devices attached 
0123456789ABCDEF	device
```

## TWRP flash


- adb reboot bootloader

- sudo fastboot oem unlock-go
OKAY [  0.048s]
finished. total time: 0.048s


- adb reboot-bootloader // ??
- fastboot devices // check if it's available

sudo fastboot boot twrp-3.2.1-0-s2.img



- sudo fastboot flash recovery twrp-3.2.1-0-s2.img
target reported max download size of 536870912 bytes
sending 'recovery' (17296 KB)...
OKAY [  0.544s]
writing 'recovery'...
OKAY [  0.119s]
finished. total time: 0.663s

- sudo fastboot reboot
rebooting...
finished. total time: 0.050s

``` bash
[!]
ivan@ivr:~/LeEco2$ fastboot devices
no permissions	fastboot

ivan@ivr:~/LeEco2$ sudo $(which fastboot) devices
56e55a69	fastboot

ivan@ivr:~/LeEco2$ sudo fastboot oem unlock
...
FAILED (remote: Need wipe userdata. Do 'fastboot oem unlock-go')
finished. total time: 0.000s

```


- fastboot reboot

[Unlocking, Rooting, and Restoring to Stock for Le 2 / S3 (noob-friendly!)]
(https://forum.xda-developers.com/le-2/how-to/guide-unlocking-rooting-restoring-to-t3515555)


Bus 001 Device 062: ID 2b0e:171e 
ls -l /dev/bus/usb/001/{062}

sudo vi /etc/udev/rules.d/51-android.rules
SUBSYSTEM=="usb", ATTR{idVendor}=="2b0e", MODE="0666", GROUP="plugdev"

ivan@ivr:~$ ls -l /dev/bus/usb/001/062
crw-rw-r-- 1 root root 189, 61 Dec  5 03:31 /dev/bus/usb/001/062

sudo chmod a+rw /dev/bus/usb/001/062
ivan@ivr:~$ ls -l /dev/bus/usb/001/062
crw-rw-rw- 1 root root 189, 61 Dec  5 03:31 /dev/bus/usb/001/062

### Shared folders to exchange data

https://help.ubuntu.com/community/VirtualBox/SharedFolders

<TMP> - ubuntu shared folder 
sudo mount -t vboxsf -o uid=$UID,gid=$(id -g) TMP ~/TMP

mount: mount point /home/ivan/host does not exist


- go to fastboot 
- lsusb
Bus 001 Device 036: ID 18d1:d00d Google Inc.

- sudo fastboot devices
56e55a69	fastboot

// let see what I can read there


sudo fastboot flash recovery twrp3.img  
sudo fastboot reboot  

ivan@ivr:~/TMP$ sudo fastboot oem device-info
...
(bootloader) 	Device product name: []
(bootloader) 	Device tampered: false
(bootloader) 	Device unlocked: true
(bootloader) 	Device critical unlocked: false
(bootloader) 	Charger screen enabled: false
(bootloader) 	Display panel: 
OKAY [  0.006s]
finished. total time: 0.006s


OK. temporary load
sudo fastboot recovery  twrp-3.2.1-0-s2.img
// not good with dots . no. it doesn't like temp solution - w/o flush
sudo fastboot flash  recovery twrp.img
 

sudo fastboot flash recovery  twrp-3.2.1-0-s2.img
sudo fastboot reboot

/////////////

adb push lineage-15.1.zip /sdcard/
// adb push SuperSU.zip /sdcard/
adb push MindTheGapps.zip /sdcard/
adb push open_gapps.zip /sdcard/
adb push addonsu.zip /sdcard/

## ADB dev permissions

let's finish it to the  final end

[???????????? no permissions](https://stackoverflow.com/questions/9210152/set-up-device-for-development-no-permissions)

with sudo privilege works partially: shows device id but  no permission
```adb
sudo sudo adb start-server
ivan@ivr:~$ adb devices
List of devices attached 
56e55a69	unauthorized
```

suggestion:
'try to check that your user is in plugdev group"

cd /etc/udev/rules.d
nano 51-android.rules

[!NOTE] it was BS in the file:
UBSYSTEM=="usb", ATTR{idVendor}=="2b0e", MODE="0666", GROUP="plugdev"

Right command for the sn:
    adb shell getprop | grep ro.boot.serialno
the same result with:  
    adb devices

so I copied idVendor to the file like
SUBSYSTEM=="usb", ATTRS{idVendor}=="56e5", MODE="0666"
and moved it to '/etc/udev/rules.d' as '51-android.rules'

```bash / adb
sudo cp TMP/android.rules /etc/udev/rules.d/51-android.rules
sudo chmod 644   /etc/udev/rules.d/51-android.rules
sudo chown root. /etc/udev/rules.d/51-android.rules
sudo service udev restart
sudo killall adb
```

- Disconnect the USB cable between the phone and the computer.
- Reconnect the phone.
- Run adb devices to confirm that now it has permission to access the phone.

[!NOTE] Good day !!! It works
> LeEco x25X has recognized. Sample api stack level 27 app has been deployed.

what puzzle me  - why Redmi note works with 3G

 for GSM Mhz band	Tri-Band 900/1800/1900
Primary 2G network	GSM 900/1800/1900
Primary 3G network	TD-SCDMA 1900/2000
Primary 4G network	TD-LTE 1800/2300/2600

may be answer is: 
Primary 3G network	TD-SCDMA 1900/2000
*#*#4636#*#*

for Xiaomi

network type  
PREFERED TYPES LTE, GSM/WCDMA

[NOTE]  english
> every once in a while - time to time

// Salesforce
rakin.i.v@brave-otter-1k8100.com