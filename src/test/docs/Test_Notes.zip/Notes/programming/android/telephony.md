# Android Telephony

## The base idea answering phone then brake it after a second

[answering programatically](https://stackoverflow.com/questions/36565820/android-call-answering-programatically)

I have came across same issue for my app. Put some delay for accepting incoming call(~3000 ms). You also need to invoke acceptCall() method in different thread as well.

[incoming calls be answered programmatically](https://stackoverflow.com/questions/26924618/how-can-incoming-calls-be-answered-programmatically-in-android-5-0-lollipop)

Oreo 8.0

open fun acceptRingingCall(): Unit
open fun acceptRingingCall(videoState: Int): Unit
open fun silenceRinger(): Unit

## android how to change sound level programmatically
[Set media volume programmatically ](https://android--code.blogspot.com/2017/08/android-set-media-volume.html)

```java
AudioManager mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
int media_current_volume = mAudioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
int media_max_volume = mAudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
```
> I guess should be smth like :
> AudioManager  getStreamMinVolume(AudioManager.STREAM_MUSIC);
> STREAM_VOICE_CALL or 0

```java
mAudioManager.setStreamVolume(
                AudioManager.STREAM_MUSIC, // Stream type
                random_volume, // Index
                AudioManager.STREAM_VOICE_CALL // Flags  
                );
```

> public boolean endCall()

### how to record incoming call

[How to Record Voice Calls in Android](http://playingwithandroid.blogspot.com/2012/08/how-to-record-voice-call-in-android.html)

```java
recorder = new MediaRecorder();
recorder.setAudioSource(MediaRecorder.AudioSource.VOICE_CALL);
recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
recorder.setOutputFile(audiofile.getAbsolutePath());
recorder.prepare();
recorder.start();
recordStarted = true;
```

[Android Recording Incoming and Outgoing Calls(https://stackoverflow.com/questions/6688444/android-recording-incoming-and-outgoing-calls)

