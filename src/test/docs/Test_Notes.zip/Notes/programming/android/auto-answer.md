
# auto-answer

[Can't answer incoming call in android marshmallow 6.0](https://stackoverflow.com/questions/42339534/cant-answer-incoming-call-in-android-marshmallow-6-0)

[!NOTE]
> I can't believe it !
> Settings -> System apps-> Phone -> Call forwarding
> Settings -> System apps-> Phone -> 
> Settings -> System apps-> Phone -> 
> Settings -> System apps-> Phone -> Auro answer -> ...

