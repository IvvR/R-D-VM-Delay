
# Django notes

## installation 

with conda with conda-forge:

- conda config --add channels conda-forge
- conda install djangorestframework

> ok. Warning: 'conda-forge' already in 'channels' list, moving to the top


