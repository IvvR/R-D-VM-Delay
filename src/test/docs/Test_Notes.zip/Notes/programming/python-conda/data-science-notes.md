
# Data science notes

Extract, Transformation, and Loading (ETL)  
The ETL specialist uses programming languages such as Python to extract the data from a number of sources.  
Python helps to perform data loading,transformation, and analysis tasks.  

> [!NOTE]
> immense, adj - extremely large or great, especially in scale or degree.  
> syn: massive, enormous, gigantic, colossal  
> The immense datasets

Data science is partly art and partly engineering.  
to make the art part of data science realizable, the engineering part relies
on the data science pipeline process, which requires to follow particular
steps in the preparation, analysis, and presentation of the data.  

## Preparing the data

it may need to trans­form it to make all the data sources cohesive and amenable to analysis.

## Exploratory data analysis

data science provides  a wealth of statistical methods and algorithms that helps to discover patterns in the data.

## the shifting profile

manipulate large databases and discover new patterns in them.  
create new data based on the old data — making an informed prediction of sorts.  
creating altogether new kinds of applications
[!NOTE]
> Reality augmentation is an expensive development. Find a pattern to new app features.

## Python

> a skunkworks project.  
> skunkwork - an experimental laboratory or department of a company or institution,  
> typically smaller than and independent of its main research division.  

## Conda package update

[!NOTE]
> may by  I need to create it under 3.7 env as scikit-learn=0.19.2 was intended to work > with Python 3.7.  
> OK. It.s next TO DO. I guess It works like
>
> - swith to 'py370env' with 'source activate py370env'
> - update stuff specifically for py370env
> - work and exit with 'source deactivate'  

check version:  
    conda list  
append new channel :  
    conda config --append channels conda-forge  
install wanted version  
    conda install scikit-learn=0.19.2

