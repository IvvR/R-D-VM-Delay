# Flask Azure

[Deploying Python Flask application to Azure App service]
(https://www.youtube.com/watch?v=K_RTlbOOCts)

[Azure-Samples/python-docs-hello-world]
(https://github.com/Azure-Samples/python-docs-hello-world)