
# VS Code Python linting

[The rise of the linters](https://hk.saowen.com/a/92146acd7ac700607cfc4bed04e579e6b97860f630f873fbca86366ccdb2d638)

- Some of the Error messages can also be caught by pyflakes which is fast and produces very few false positive too.
- The Convention category can also be taken care of by pycodestyle .
- A few Refactoring warnings (but not all) can also be caught by mccabe , which measures code complexity.

