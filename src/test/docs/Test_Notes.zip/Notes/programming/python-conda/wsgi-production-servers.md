
# WSGI production servers

When running publicly rather than in development, you should not use the built-in development server (flask run). The development server is provided by Werkzeug for convenience, but is not designed to be particularly efficient, stable, or secure.

[Waitress](https://docs.pylonsproject.org/projects/waitress/en/latest/)