
# Python notes

## Different python environments

- to avoid libraries breaking changes  
- to collaborate with someone in different environment
- to deliver  an application to different clients

[Python environments with Conda](https://medium.freecodecamp.org/why-you-need-python-environments-and-how-to-manage-them-with-conda-85f155f4353c?gi=f6b8f5c6d52)

popular tools for setting up environments:

- PIP (Python package manager)
- Conda (package and environment manager)

 Conda advantages: clear structure, transparent file management, flexibility, multipurpose.  
Anaconda (3Gb) vs Miniconda(400M)  - just what you need.  

why don’t I just create two environments based on these two 2.7 and 3.x versions?  
The root environment is the one that is created during the installation process and it’s activated by default.  

## Anaconda installation

[digitalocean for Ubuntu 16.04](https://www.digitalocean.com/community/tutorials/how-to-install-the-anaconda-python-distribution-on-ubuntu-16-04)

- find the last install script. for the moment is Anaconda3-5.2.0. btw 622M.  
- get it by:  curl -O https://repo.anaconda.com/archive/Anaconda3-5.2.0-Linux-x86_64.sh
- checksum: sha256sum Anaconda3-5.2.0-Linux-x86_64.sh
- run the script: bash Anaconda3-5.2.0-Linux-x86_64.sh
- activate the installation: source ~/.bashrc
- verify: conda list

[!NOTE]
> after source activation Python conda interpreter is in active, but not from the Ubuntu

ok. it works.  

> what does activate the installation mean ?  
> apparently it means a conda environment to be activated by default when you launch a  
> new bash terminal, you can add the following line to your ~/.bashrc file:  
> to prepend - add (something) to the beginning of something else.

## Setting Up Anaconda Environments

check the Python versions: conda search "^python$". well, the endless list is available.  

> [!NOTE]
> Got it !!!  ex. name  = py37env  
- for the most recent version: conda create --name py3env python=3
- for the specific version: conda create -n py370env python=3.7.0
- activate: source activate py370env
- deactivate: source deactivate
- inspect all of the environments you have set up:  

You can add additional packages with the following command:  
conda install --name my_env35 numpy.

## Updating Anaconda

- conda update conda  -  to update the manager
- conda update anaconda  - to update the distribution

## Jupyter notebook

to launch type in the terminal: jupyter notebook  
in the web browser click new/ PythonXXX   button in the top right  

## Python - Anaconda - VSCode integration

[Stackoverflow Suggestions](https://stackoverflow.com/questions/43351596/activating-anaconda-environment-in-vscode)

- install MS Python extension
- update 'python.path' in 'settings.json': 

[!NOTE]
> "python.pythonPath": "C:\\Anaconda3\\envs\\py34\\python.exe" -  what it could be for 
> Linux

## SQLAlchemy support to your Flask 

[SQLAlchemy support to your Flask ](https://anaconda.org/conda-forge/flask-sqlalchemy)

conda install -c conda-forge flask-sqlalchemy

## Conda environments

- conda env list
- conda info --envs

### Managing environments

- conda create --name myenv

conda create --name sel_env
conda create -n sel_env python=3.4

source activate sel_env
conda install -c conda-forge selenium  
// if it was a part of distribution
conda install selenium 
// to a fiff env
conda install -c conda-forge --name myenv selenium 
conda install jupyter

### Multiple package resolutions

conda update conda
