
# MyPy

The mypy utility is a static type checker for Python. 


[optional static typing](https://hk.saowen.com/a/0d36fbfd4d23627c10c111894779e4c96c6dfa3c6cfac9c1506705be0962335e)

if you have a large codebase things start to get complicated.

```python
def extract_images(html):
    lst = []
    ...
    return lst
```

If I look at this code, then what is “html”? Is it raw HTML (string), or is it a BeautifulSoup object? What is the return value? What is in the returned list? Does it return a list of URLs (a list of strings)? Or is it a list of custom objects that wrap the URLs?

```python
from typing import List
from bs4 import BeautifulSoup
from myimage import Image

def extract_images(html: BeautifulSoup) -> List[Image]:
    lst = []
    ...
    return lst
```

And now everything is clear and there is no need to carefully analyse the code to figure out what goes in and what comes out.

This new syntax was introduced in Python 3.6. Actually, if you run such an annotated program, the Python interpreter ignores all these hints.
