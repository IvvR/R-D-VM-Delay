# Cucumber

- The tests	are	written	in plain text in the form of stories or	features
- The Domain specific language (Gherkin) is	used for writing the tests.

## Features

Gherkin	is	the	plain text language	used to	write feature files (also called as	story files)in BDD frameworks like cucumber.

[!NOTE] Do stories describe a feature from the different aspects (scenarios) ?

- Each feature	file can contain one or	more scenarios and	optinally outline and background.
- Each scenario has steps like	given, when, and, then,	but

Feature: Favorites Repository

Scenario: Empty Favorites Repository