# Test Data

fake data generators

[Faker is a PHP library that generates fake data for you.](https://github.com/fzaninotto/Faker)

Route coordinate generator

## google map

- Sign into your google account/If you don't have one then you will need to create one to do it this way.
- https://www.google.com/mymaps

[!NOTE] next steps a bit tricky but I did it and it works.

- Create new map with a car type
- share or export ? to KML

Let's try it again // TODO: automate with Selenium ?!

- click 'draw a line' button / icon
- it shows "add driving route"
- push and a new layer would be showed on the right panel

ok. it works great jus not to be in a hurry 

- when it created a new entry it says pin your points.
- pin to points and push 'enter'
- the coordinates will be added to that layer
- on the top right (ghe highest - Untitled map) select 3 points button with the options
- select the layer and export to KML
- Click 2 times on the title to rename  "Untitled"


[Export roots to KML coordinates](https://webapps.stackexchange.com/questions/34159/how-to-convert-google-map-route-into-array-of-coordinates)


in the KML file i have the LatLng was backwards.  
[KML to Google maps coordinates]
(https://stackoverflow.com/questions/6690078/google-maps-coordinates-in-kml)
