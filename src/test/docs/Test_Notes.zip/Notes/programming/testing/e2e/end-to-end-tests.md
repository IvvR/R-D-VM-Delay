# End-to-End Tests

writing End-to-End (E2E) tests, and then using them to drive the development of our API.

## types of test

- Unit tests
- Integration tests
- E2E/functional tests
- User interface (UI) tests
- Manual tests
- Acceptance tests

Testing Pyramid - make sure that our test suite contains a lot of unit tests, fewer integration tests, and the fewest E2E tests.

## E2E tests first

In fact, when implementing a new feature, E2E tests are the most important tests, and should be the first test you write when composing your test suite. E2E tests mimic how your end users would interact with the project, and are often tied to the business requirements. If your E2E tests pass, it means the feature you are developing is working.

Moreover, it's often impractical to write your unit tests first. A unit tests concerns itself with implementation details, but there are many ways to implement a set of features and our first solutions are often substandard. It is likely to undergo many iterations of changes before it becomes stable. Since unit tests are coupled to the implementation they are testing, when the implementation changes, the unit tests would be discarded.

Therefore, when implementing new features, E2E tests should be written first; unit and integration tests should be written only after the implementation has settled.

[!NOTE]
> Scaffolding generally refers to a quickly set up skeleton for an app.

[Behavior-driven development framework](https://behave.readthedocs.io/en/latest/)