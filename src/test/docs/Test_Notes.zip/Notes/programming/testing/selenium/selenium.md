# Selenium

select Selenium env with :

- conda env list
- source activate "sel_env"
- VS Code env activation: "select evironment" from the Command Palette (Ctrl+Shift+P).
- install pylint to "sel_env": conda install --name sel_env mypy

## Find element

driver.find_element(*WikipediaHomepage.Random_Link)

In this context, * is the argument-unpacking operator. It tells Python to unpack the values in the sequence that follows and pass them as arguments to the function. For example,
foo(*(1, 2, 3))
is equivalent to
foo(1, 2, 3)

