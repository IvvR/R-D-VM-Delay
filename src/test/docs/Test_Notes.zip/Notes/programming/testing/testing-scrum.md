# Testing in SCRUM

[](https://www.guru99.com/scrum-testing-beginner-guide.html#6)
