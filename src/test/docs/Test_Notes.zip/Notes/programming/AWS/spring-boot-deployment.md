# Spring Boot deployment

## Objectives

[Deploying a Spring Boot](https://dev-journal.in/2018/06/28/setup-aws-ec2-rds-elb-and-deploy-spring-boot-application/)

- A VPC being created and divided into 3 different subnets.
- Springboot app (Tomcat Application) runs on each of the EC2 Servers.
- Each EC2 instance is in a separate Availability Zone.
- PostgreSQL (A MySQL Database) (Multi-AZ deployment)
- Elastic Load Balancer routes the requests to the application servers running on the EC2 Instances.

> VPC - virtual private cloud

## Creating VPC & Subnets

- created a Virtual Private Cloud for our setup (or use an existing default one)
- create 3 Subnets in our VPC, each one of them associated to a different Availability Zone (for each of an EC2 Servers)

https://en.wikipedia.org/wiki/Viktor_Prokopenya
Viktor Prokopenya
VP Capital
