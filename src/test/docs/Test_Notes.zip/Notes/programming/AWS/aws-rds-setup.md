# AWS RDS Setup

[AWS RDS Setup](https://dev-journal.in/2018/06/20/how-to-setup-database-on-aws-rds/)

[!NOTE] Check free tier !

PostgreSQL - 10.4

instance name - boot2
name : post_adm
pwd: AdmPost212

dbname: FirstBoot2
port: 5432
?? in edit - port 5431

Endpoint
Not yet available
