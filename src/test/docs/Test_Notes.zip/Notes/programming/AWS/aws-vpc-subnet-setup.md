# VPC -Subnet setup

[How to Setup VPC and Subnets in AWS](https://dev-journal.in/2018/06/15/how-to-setup-vpc-and-subnets-in-aws/)

## Regions, AZ, VPC and Subnets

- Step 0:launch VPC wizzard
- Step 1: Select a VPC Configuration

  10.0.0.0/24

[How to Configure your own VPC](https://www.linuxtechi.com/how-to-configure-vpc-in-aws/)

VPC Name = Boot-VPC
IPV4 CIDR = 192.168.0.0/24

[AWS non-default VPC](https://www.koding.com/docs/create-an-aws-vpc)

10.0.0.0/24
[!NOTE] no sugar!! = bs: OK / it was easy
Thje range was defined from 0 - 256
so for 3 subnets
356 /3 - 85
0-85
86-171
172 - 251 /6 ?
--
it works
10.0.0.64/24 -- nope
as

It works for IPv4 CIDR block as 192.168.100.0/24

192.168.100.00/26
192.168.100.64/26
192.168.100.128/26

### Create route table

- push create Route Table
- select VPC
- press Save btn

### Create IGW - inet gateway

[!NOTE] bloody IGW existed but wasn't visible

- select Internet Gateway from the Board on the left
- give it a name : boot2-igw
- attache the beast to VPC (actions-> attach)

### Modifying the route tables

Now Add Route to your route Table for Internet,
go to Route Tables Option, Select your Route Table, In my case it is “Lnx-RouteTable“, click on Route Tab and Click on Edit and the click on “add another route”
