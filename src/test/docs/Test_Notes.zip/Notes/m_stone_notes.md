
# Milestones list

Techs

!!! Stay focused !!

- Java
    - RESTfull
    - DB integration stuff (JDBC / JPA)
    - JMS
    - [SpringBoot](spring-boot-notes.md) !!!

- Deployment
    - Docker
    - Kubernetes
    - AWS / OpenShift

- Mobile / Android


// Not deep !!! Just enoug to understand and make a light prototype.
- JS 
    - Async
    - Prototypal inheritance
- React.js
- Protocols (?)
    - RESTfull
    - gRPC
    - graphQL
- gitHub [Git notes](git-notes.html)
- markdown [Markdown notes](markdown-notes.html)

Prototypes

- Invest [Invest prototype notes](inv_notes.html)
- HushGhost
- NeibJammer
- Hidden Files on the public server. Well, with no directory listing :) use REST to load personal folder or BS.  "F*ck you, Ivan !", Mad 'Cow' Jessica. I took it as a compliment.


