# Docker Ubuntu

[!NOTE]

> sudo with docker makes me tired

[How to Install and Use Docker on Ubuntu 18.04 ](https://www.digitalocean.com/community/tutorials/how-to-install-and-use-docker-on-ubuntu-18-04)

## Step 2 — Executing the Docker Command Without Sudo (Optional)

If you want to avoid typing sudo whenever you run the docker command, add your username to the docker group:

    sudo usermod -aG docker ${USER}

o apply the new group membership, log out of the server and back in, or type the following:

    su - ${USER}

Confirm that your user is now added to the docker group by typing:

    id -nG

## Step 3 — Using the Docker Command

## Docker 'restart always'

[prevent docker from starting a container automatically](https://stackoverflow.com/questions/40513545/how-to-prevent-docker-from-starting-a-container-automatically-on-system-startup)

Docker will autostart any container with a RestartPolicy of 'always' when the docker service initially starts.

- docker inspect my-container
- docker update --restart=no my-container
