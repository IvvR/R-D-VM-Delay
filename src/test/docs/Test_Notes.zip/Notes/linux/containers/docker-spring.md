# Docker Spring debugging

[Live In-Docker Debugging for Java with IntelliJ]
(https://www.youtube.com/watch?v=sz5Zv5QQ5ek)