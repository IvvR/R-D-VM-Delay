
# Docker Cassandra

[Getting Started with Cassandra on Docker](https://medium.com/@michaeljpr/five-minute-guide-getting-started-with-cassandra-on-docker-4ef69c710d84)

Step 1. Create Docker Account
Step 2. Installing Docker
Step 3. Pull The Docker Images

- Docker Login : docker login
- Pull the DataStax Image : docker pull datastax/dse-server:latest
- Pull DataStax Studio Image (Notebook) : docker pull datastax/dse-studio:latest

[!NOTE] datastax/dse-server & datastax/dse-studio are enormously big : 1.43Gb and 500M

- docker pull cassandra

Step 4. Run The Containers

- docker image ls // check the image

[docker run command]
(https://stackoverflow.com/questions/34645846/cannot-connect-to-cassandra-docker-with-cqlsh)

<!-- // docker run --name=cass  -p 3306:3306 -p 33060:33060 -e MYSQL_ROOT_PASSWORD=test -d mysql:latest -->

- docker run --name trans-cas -m 2g -d cassandra
- docker container ls -a
- docker logs trans-cas

```bash
a6f05300e753        cassandra               "docker-entrypoint.s…"   2 minutes ago       Up 2 minutes               7000-7001/tcp, 7199/tcp, 9042/tcp, 9160/tcp                                                                                                                       trans-cas
```

- docker stop trans-cas
- docker rm trans-cas
- docker ps
- docker container ls -a
- docker run --name trans-cas -p 7000:7001 -p 9160:9160 -p 9042:9042 -p 7199:7199 -d cassandra
- docker logs trans-cas
- docker start trans-cas

```bash
Exited (255) 4 weeks ago   4040/tcp, 5598-5599/tcp, 7000-7001/tcp, 7077/tcp, 7080-7081/tcp, 7199/tcp, 8090/tcp, 8182/tcp, 8609/tcp, 8983-8984/tcp, 9042/tcp, 9160/tcp, 9999/tcp, 18080/tcp   my-dse
```

check ip address:

- docker inspect --format='{{ .NetworkSettings.IPAddress }}' trans-cas

[!NOTE] that's it: why that address on the container ??!! but good to resolve

```bash
172.17.0.2
```

Go into cqlsh:

- docker run -it --link trans-cas --rm cassandra bash -c 'exec cqlsh 172.17.0.2'

## How to use this image

https://store.docker.com/images/cassandra

## Video course of Data Modeling with Cassandra

https://www.youtube.com/watch?v=eLjCtT2pBxw

## Working with Cassandra

- docker exec trans-cas nodetool status

Show databases /keyspaces

- DESCRIBE keyspaces;
- USE <keyspace_name>;
- describe tables;

```cqlsh
system_traces  system_schema  system_auth  system  system_distributed
```

- CREATE KEYSPACE transpdb WITH REPLICATION