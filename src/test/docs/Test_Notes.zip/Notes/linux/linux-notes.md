
# Linux Notes

## How to create desktop icon

- install gnome-panel:  'udo apt-get install --no-install-recommends gnome-panel'
- launch: 'gnome-desktop-item-edit --create-new ~/Desktop'
    - press icon to change the image

[ask ubuntu](https://askubuntu.com/questions/854373/how-to-create-a-desktop-shortcut)

[How To Use Systemctl to Manage Systemd Services and Units](https://www.digitalocean.com/community/tutorials/how-to-use-systemctl-to-manage-systemd-services-and-units)

## IP address

the loopback is interface lo and ip 127.0.0.1 by default

127.0.0.1 localhost

Debian than ubuntu choose to define 127.0.1.1 for mapping the ip of your host_name in case that you have no network

The host_name matches the hostname defined in the "/etc/hostname".

## rpm 2 deb

[Installing Oracle SQL Developer on Ubuntu 16.04 LTS](https://medium.com/@seralahthan/installing-oracle-sql-developer-on-ubuntu-16-04-lts-bfa4af959deb)

### Installing with RPM package

Install Alien… Alien converts an RPM package file into a Debian package file or Alien can install an RPM file directly. But, this is not the recommended way to install software packages in Ubuntu.

```bash
sudo add-apt-repository universe  // already enabled
sudo apt-get update
sudo apt-get install alien

cd <path_to_the_rpm_package>
sudo alien <name_of_package>.rpm

sudo dpkg -i <name_of_package>.deb

```