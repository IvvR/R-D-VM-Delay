# Gradle

## installation

wget https://services.gradle.org/distributions/gradle-5.1-bin.zip

sudo mkdir /opt/gradle

sudo unzip -d /opt/gradle gradle-5.1-bin.zip

export PATH=\$PATH:/opt/gradle/gradle-5.1/bin

<!-- export PATH=$PATH:/opt/gradle/gradle-3.4.1/bin -->

sudo mv fromPath/ toPath/

sudo mv /opt/gradle /home/ivan/DevTools/

sudo rm -R gradle

[!NOTE] Java Path was wrong

gksudo gedit /etc/environment
update/reboot

lol: finally the right way : jdk-11.0.1

sudo unzip -d /opt/gradle gradle-5.1-bin.zip

---

[!NOTE] never use this command !!!
GRADLE_HOME=/opt/gradle/gradle-5.1
PATH=$PATH:$GRADLE_HOME/bin
export GRADLE_HOME
export PATH

### right way

- nano ~/.bashrc
- go to the bottom
- export PATH=$PATH:/opt/gradle/gradle-5.1/bin // !!! remove \ in front of $
- source ~/.bashrc //to maske it works

### maven config for java 11

https://winterbe.com/posts/2018/08/29/migrate-maven-projects-to-java-11-jigsaw/

```xml
<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-compiler-plugin</artifactId>
    <version>3.8.0</version>
    <configuration>
        <release>11</release>
    </configuration>
</plugin>
```

1. Find and load elastic beansstalk
   https://console.aws.amazon.com/elasticbeanstalk/home?region=us-east-1#/welcome
2.
