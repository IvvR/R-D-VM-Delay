# SSH

## copy files

from a remote machine to host
sudo scp ivan@192.168.1.115:/home/ivan/cover_sean.odt /home/ivan/dir/

to remote machine
rsync /path/to/local/file username@PCB:/path/to/remote/destination
sudo rsync /home/ivan/cover_letter2.txt ivan@192.168.1.115:/home/ivan/
