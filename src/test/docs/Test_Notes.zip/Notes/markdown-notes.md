
# My Markdown endeavor notes

Oh man how was I wrong. It was unbearable.

The link below just thing that works.
[Build an Amazing Markdown Editor Using Visual Studio Code and Pandoc](http://thisdavej.com/build-an-amazing-markdown-editor-using-visual-studio-code-and-pandoc/)

It's simple when it's done. No kidding, Dave Johnson @thisDaveJ  is a genius.
Press Ctrl+k and then p.  (You will be prompted with an option to choose html, docx, or pdf.)


## VS Code plugins for Markdown

- 'docs-markdown' of MS. Alt+M.
- markdownlint of David Ashton.  
- Docs article templates

Actually all of those tools are parts of MS Docs Authoring Pack, but 'Doc Preview" tool makes VS code really crazy. One of the processor core become loaded to 100% and the network traffic in both side (in/out) is like 180 kbit/s. 
Preview is on the top left ot Ctrl + Shift + V.